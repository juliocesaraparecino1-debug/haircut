create table if not exists users (id uuid primary key, name text not null, email text not null unique, phone text not null default '', password_hash text, master boolean not null default false, created_at timestamptz not null default now());
create table if not exists sessions (id text primary key, user_id uuid not null references users(id) on delete cascade, expires_at timestamptz not null, agent text not null default '', created_at timestamptz not null default now());
create table if not exists barbershops (id uuid primary key, name text not null, slug text not null unique, data jsonb not null default '{}', created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists barbershop_members (id uuid primary key, barbershop_id uuid not null references barbershops(id), user_id uuid not null references users(id), role text not null check(role in ('OWNER','ADMIN','PROFESSIONAL','CLIENT')), created_at timestamptz not null default now(), unique(barbershop_id,user_id));
do $$ declare t text; begin foreach t in array array['professionals','services','clients','business_hours','professional_hours','schedule_blocks','closed_dates','notifications','reviews','subscriptions','payments','commissions','public_page_settings','waitlist','support_tickets'] loop
execute format('create table if not exists %I (id uuid primary key, barbershop_id uuid not null references barbershops(id), data jsonb not null default ''{}'', created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(barbershop_id,id))',t);
execute format('create index if not exists %I on %I(barbershop_id)',t||'_tenant_idx',t);
end loop; end $$;
create unique index if not exists client_phone_unique on clients(barbershop_id,(data->>'phone')) where data->>'phone' <> '';
create table if not exists professional_services (barbershop_id uuid not null,professional_id uuid not null,service_id uuid not null,primary key(professional_id,service_id),foreign key(barbershop_id,professional_id) references professionals(barbershop_id,id),foreign key(barbershop_id,service_id) references services(barbershop_id,id));
create table if not exists appointments (id uuid primary key, barbershop_id uuid not null references barbershops(id),client_id uuid not null,professional_id uuid not null,date text not null check(date ~ '^\d{4}-\d{2}-\d{2}$'), start_minute int not null check(start_minute>=0),end_minute int not null check(end_minute<=1440 and end_minute>start_minute),status text not null check(status in ('pendente','confirmado','aguardando','em atendimento','concluído','cancelado','não compareceu')), data jsonb not null,token_hash text unique,created_at timestamptz not null default now(),updated_at timestamptz not null default now(),unique(barbershop_id,id),foreign key(barbershop_id,client_id) references clients(barbershop_id,id),foreign key(barbershop_id,professional_id) references professionals(barbershop_id,id));
create index if not exists appointments_schedule on appointments(barbershop_id,date,professional_id,start_minute);
create table if not exists appointment_services (barbershop_id uuid not null,appointment_id uuid not null, service_id uuid not null, price int not null, duration int not null, primary key(appointment_id,service_id),foreign key(barbershop_id,appointment_id) references appointments(barbershop_id,id) on delete cascade,foreign key(barbershop_id,service_id) references services(barbershop_id,id));
create table if not exists plans(id uuid primary key,name text not null unique,price int not null default 0,data jsonb not null default '{}',created_at timestamptz not null default now());
create table if not exists audit_logs(id uuid primary key,barbershop_id uuid references barbershops(id),user_id uuid references users(id),action text not null,entity_id uuid,data jsonb not null default '{}',created_at timestamptz not null default now());
create table if not exists rate_limits(key text primary key, count int not null default 1,expires_at timestamptz not null);
create or replace function haircut_uid() returns uuid language sql stable as $$ select coalesce(nullif(current_setting('request.jwt.claim.sub',true),''),nullif(current_setting('request.jwt.claims',true),'')::jsonb->>'sub')::uuid $$;
create or replace function haircut_member(shop uuid) returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from barbershop_members where barbershop_id=shop and user_id=haircut_uid() and role in ('OWNER','ADMIN')) $$;
create or replace function haircut_master() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from users where id=haircut_uid() and master) $$;
alter table users enable row level security;
drop policy if exists own_user on users;
create policy own_user on users for select using (id=haircut_uid());
alter table sessions enable row level security;
alter table rate_limits enable row level security;
alter table barbershops enable row level security;
drop policy if exists shop_read on barbershops;
create policy shop_read on barbershops for select using (haircut_member(id));
do $$ declare t text; begin foreach t in array array['barbershop_members','professionals','services','clients','business_hours','professional_hours','schedule_blocks','closed_dates','notifications','reviews','subscriptions','payments','commissions','public_page_settings','waitlist','support_tickets','appointments','appointment_services','professional_services','audit_logs'] loop
execute format('alter table %I enable row level security',t);
execute format('drop policy if exists tenant_read on %I',t);
execute format('create policy tenant_read on %I for select using (haircut_member(barbershop_id))',t);
end loop; end $$;
alter table plans enable row level security;
drop policy if exists plans_read on plans;
create policy plans_read on plans for select using (true);
-- Escritas via API do servidor. Nenhuma política de escrita para anon/authenticated.
-- Tokens, senhas, sessões e dados pessoais nunca têm acesso público direto.
create or replace function haircut_no_overlap() returns trigger language plpgsql set search_path=public as $$
declare gap int;
begin
 select coalesce((data->>'buffer')::int,0) into gap from barbershops where id=new.barbershop_id for update;
 if new.status not in ('cancelado','não compareceu') and exists(
 select 1 from appointments a where a.barbershop_id=new.barbershop_id and a.professional_id=new.professional_id and a.date=new.date and a.id<>new.id and a.status not in ('cancelado','não compareceu') and new.start_minute<a.end_minute+gap and new.end_minute+gap>a.start_minute
 ) then raise exception 'Conflito de horário' using errcode='23505'; end if;
 return new;
end $$;
drop trigger if exists appointments_no_overlap on appointments;
create trigger appointments_no_overlap before insert or update of professional_id,date,start_minute,end_minute,status on appointments for each row execute function haircut_no_overlap();
