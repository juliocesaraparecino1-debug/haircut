-- A role haircut_server foi autorizada e provisionada no projeto.
-- Sua senha não faz parte do código. NUNCA conceder esta role a anon/authenticated.
-- Role somente do backend, sem superuser, sem criação de roles/bancos e sem BYPASSRLS.
-- A API Next.js valida a sessão e o tenant em toda operação antes de usar esta conexão.
-- Execute este arquivo como administrador somente após criar a role de LOGIN.
do $$ declare t text;begin
if exists(select 1 from pg_roles where rolname='haircut_server') then
grant usage on schema public to haircut_server;
foreach t in array array['users','sessions','barbershops','barbershop_members','professionals','services','clients','business_hours','professional_hours','schedule_blocks','closed_dates','notifications','reviews','subscriptions','payments','commissions','public_page_settings','waitlist','support_tickets','professional_services','appointments','appointment_services','plans','audit_logs','rate_limits'] loop
execute format('grant select,insert,update,delete on public.%I to haircut_server',t);
execute format('drop policy if exists haircut_backend on public.%I',t);
execute format('create policy haircut_backend on public.%I for all to haircut_server using(true) with check(true)',t);
end loop;
end if;
end $$;
