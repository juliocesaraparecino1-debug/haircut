# Validação — 03/10/2026

- 113 verificações HTTP aprovadas em banco local isolado, sem criar clientes ou agendamentos no Supabase de produção. Detalhes em `qa-http-results.json`.
- 24 testes automatizados aprovados: disponibilidade, conflitos, isolamento de dados, origem das requisições, links, regras dos planos, renovação mensal e recuperação de clientes.
- TypeScript e compilação de produção aprovados. Lint sem erros; quatro avisos sobre navegação com recarregamento em fluxos específicos.
- Revisão no navegador: entrada, painel, configurações, valores dos planos, link personalizado e QR Code. Corrigida opção duplicada de comissões nas configurações.
- Login Google real concluído pelo Supabase, retornando ao HAIRCUT em `/primeiro-acesso`. Nenhuma barbearia fictícia criada nesse fluxo.
- Endereço de rede `http://192.168.3.96:3000/login` respondeu HTTP 200. Requer a mesma rede do computador e servidor ligado.
- Conferência somente de leitura confirmou zero clientes, agendamentos, serviços, profissionais, pagamentos e demais dados de teste no tenant original de produção.

## Atualização de identidade e primeiro acesso

- A página pública recebeu botão Voltar; o logo ou nome da barbearia leva ao início do agendamento.
- A marca HAIRCUT foi retirada do cabeçalho das páginas do cliente. A página usa somente o logo enviado pela própria barbearia ou, enquanto ele não existir, o nome dela.
- Logo e capa agora são enviados como arquivos PNG, JPG ou WebP, redimensionados e comprimidos no navegador antes de salvar. Campos de URL foram removidos.
- O primeiro acesso virou um tutorial animado em quatro etapas: dados da barbearia, identidade, profissional/serviço e horários, com resumo antes da criação.
- A trava `appointments_no_overlap` foi consultada no Supabase de produção e está ativa. Ela valida inserções e remarcações no próprio banco e rejeita sobreposições para o mesmo profissional. O teste de concorrência da suíte HTTP também confirmou que, entre duas reservas simultâneas para o mesmo horário, somente uma é aceita.

## Cobertura dos testes HTTP

Cadastro, validação de dados, duplicidade de conta, senha inválida, primeiro acesso e isolamento entre barbearias; nomes e links repetidos, renomeação e preservação de links antigos; CRUD de clientes, profissionais e serviços; horários, pausas, bloqueios e dias fechados; reserva pública, preço calculado pelo servidor, conflito simultâneo, remarcação, cancelamento, conclusão, pagamento, comissão, avaliação e proteção do histórico; lista de espera, acesso da equipe, notificações, suporte, permissões master, solicitação e ativação de planos, limite Básico, cancelamento/retomada, perfil, senha e encerramento de sessões.

## Pendências externas e limites da validação

Google permanece em modo de testes na plataforma Google, com a conta do proprietário incluída. A publicação pública e a apresentação completa da marca dependem dos endereços públicos do site, privacidade e termos. O usuário informou que ainda não possui domínio ou hospedagem.

Gateway de pagamento, SMS, mensagens automáticas de WhatsApp e entrega real de recuperação por e-mail não fazem parte dos testes aprovados. MFA não foi ativado na conta pessoal para teste. Os testes de autenticação por senha e de alteração de senha desta rodada usaram contas descartáveis no banco local. Os resultados cobrem os cenários registrados; não equivalem a uma garantia de ausência de qualquer erro em produção.
