# HAIRCUT — projeto de implementação

Fontes lidas antes de implementar: 1H a 6H e FUNCIONAMENTO DO SISTEMA.txt em Downloads. A pasta inicial não possuía código ou stack. Originais preservados em work/references na pasta superior.

## Rotas
Login /login; cadastro /cadastro; recuperação /recuperar-senha; verificação /verificar; nova senha /nova-senha; onboarding /primeiro-acesso. Painel /app com agenda, clientes/:id, profissionais, serviços, relatórios, perfil, configurações, horários, bloqueios, feriados, notificações, assinatura, segurança, comissões, página e link. Fluxo público /agendar/:slug e consulta /a/:token. Administração segregada /master e subrotas.

## Dados e autorização
PostgreSQL. PGlite em disco para execução local independente; PostgreSQL do Supabase via conexão privada para produção e Supabase Auth. Relações de barbearia, membros, clientes, serviços, profissionais, agenda, pagamentos e comissões. Cadastros auxiliares possuem metadados JSONB. Tenant verificado no servidor; políticas RLS para acesso via Supabase. Escritas de agenda e configuração são serializadas por bloqueio da linha da barbearia e revalidadas dentro da mesma transação. Dados do visitante são limitados ao agendamento identificado por hash de token aleatório.

## Sequência
1. Fundação, banco e autorização; 2. Design a partir das seis referências; 3. Cadastros e operação da agenda; 4. Fluxo público, remarcação e cancelamento; 5. Configuração, relatórios e master; 6. Testes críticos, lint, TypeScript, build e revisão visual.

## Dependências externas
Sem credenciais disponíveis inicialmente. Execução local é identificada como local; não representa Supabase provisionado. Google/SMS/e-mail remoto, cobrança recorrente e WhatsApp automatizado nunca são marcados como operantes sem configuração.
