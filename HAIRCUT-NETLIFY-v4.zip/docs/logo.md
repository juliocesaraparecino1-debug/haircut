# Logo transparente

Arquivo utilizado: `public/haircut-logo.png`.

Edição feita com a ferramenta integrada de imagens, usando `public/reference-login.png` como referência. O PNG final tem canal alfa; foi redimensionado para 1000 × 500 para uso no aplicativo.

Prompt aplicado: “Extract ONLY the HAIRCUT brand logo from the upper part: silver HAIR red CUT lettering, male haircut silhouette, clipper, red/silver circular accents and exact tagline SISTEMA DE AGENDAMENTO. Preserve the logo appearance and lettering faithfully. Remove ALL phone frame, screen, login UI, background texture and black backdrop, including background around logo. Output a tightly framed landscape PNG with genuine transparent alpha background (not checkerboard drawn in image). Preserve intentional dark details inside hair and letters. No new elements.”
