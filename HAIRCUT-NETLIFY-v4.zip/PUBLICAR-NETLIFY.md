# Publicar o HAIRCUT na Netlify

Este é um aplicativo Next.js com servidor e banco Supabase. O ZIP contém o código pronto para a Netlify compilar. Ele não contém `.env.local`, senhas, acessos master, dependências instaladas nem dados de teste.

## Forma recomendada

1. Extraia o ZIP e envie a pasta para um repositório privado no GitHub.
2. Na Netlify, escolha **Add new project > Import an existing project** e conecte esse repositório.
3. A Netlify detectará Next.js. O arquivo `netlify.toml` já define `npm run build` e `.next`.
4. Em **Project configuration > Environment variables**, cadastre os valores do seu `.env.local` para: `HAIRCUT_MODE`, `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `DATABASE_URL` e `DATABASE_CA_PATH`. Use `HAIRCUT_MODE=supabase` e `DATABASE_CA_PATH=certs/supabase-ca.crt`. Não envie o arquivo `.env.local` ao repositório.
5. Faça o primeiro deploy. A Netlify fornecerá um endereço como `https://nome-do-site.netlify.app`.
6. Cadastre esse endereço em `APP_URL`, `HAIRCUT_PUBLIC_URL` e `HAIRCUT_ALLOWED_ORIGINS`, sem barra no final, e faça um novo deploy.
7. No Supabase, em **Authentication > URL Configuration**, defina o Site URL com o endereço Netlify e adicione `https://nome-do-site.netlify.app/auth/callback` e `https://nome-do-site.netlify.app/auth/callback?next=/nova-senha` aos Redirect URLs.
8. No Google Auth Platform, complete a marca com os endereços públicos do site, da política de privacidade e dos termos antes de publicar o login Google para todos. O retorno OAuth do Google continua sendo o callback do Supabase já cadastrado.

Não use a área de arrastar arquivos estáticos da Netlify: ela não cria as funções de servidor necessárias para login, agenda e APIs. Importe o repositório ou execute o deploy com a CLI da Netlify dentro da pasta extraída.

Depois da publicação, teste cadastro, login Google, criação de barbearia, upload das imagens e uma reserva real antes de divulgar o link.
