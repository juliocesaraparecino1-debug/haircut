"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { api, Avatar, Badge, Field, Icons, Notice } from "./ui";
import { DateSelector } from "./booking";
import {
  type Appointment,
  type Snapshot,
  money,
  dayLabel,
  time,
} from "@/lib/types";
export function AppointmentDetail({
  a,
  data,
  onSaved,
}: {
  a: Appointment;
  data: Snapshot;
  onSaved: () => void;
}) {
  const c = data.entities.clients.find((x) => x.id === a.client_id),
    p = data.entities.professionals.find((x) => x.id === a.professional_id);
  const [mode, setMode] = useState(""),
    [date, setDate] = useState(a.date),
    [slots, setSlots] = useState<{ time: number }[]>([]),
    [selected, setSelected] = useState<number | null>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [discount, setDiscount] = useState(0),
    [extra, setExtra] = useState(0);
  useEffect(() => {
    if (mode !== "reschedule") return;
    let live = true;
    api<{ time: number }[]>(
      `/api/data?${new URLSearchParams({ slots: "1", date, services: a.data.serviceIds.join(","), professional: a.professional_id, ignore: a.id })}`,
    )
      .then((r) => {
        if (live) setSlots(r);
      })
      .catch((e) => {
        if (live) setError(e.message);
      });
    return () => {
      live = false;
    };
  }, [mode, date, a]);
  async function act(body: Record<string, unknown>) {
    setBusy(true);
    setError("");
    try {
      await api("/api/data", { action: "appointment", id: a.id, ...body });
      onSaved();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const final = ["concluído", "cancelado", "não compareceu"].includes(a.status);
  return (
    <div>
      <div className="detail-person">
        <Avatar name={c?.name} photo={c?.photo} size="big" />
        <div>
          <h2>{c?.name}</h2>
          <p>{String(c?.phone || "")}</p>
          <Badge status={a.status} />
        </div>
      </div>
      <dl className="details">
        <dt>Serviço</dt>
        <dd>{a.data.serviceNames.join(" + ")}</dd>
        <dt>Profissional</dt>
        <dd>{p?.name}</dd>
        <dt>Data</dt>
        <dd>{dayLabel(a.date, true)}</dd>
        <dt>Horário</dt>
        <dd>
          {time(a.start_minute)} — {time(a.end_minute)}
        </dd>
        <dt>Duração</dt>
        <dd>{a.data.duration} min</dd>
        <dt>Valor</dt>
        <dd>{money(a.data.total ?? a.data.price)}</dd>
        <dt>Origem</dt>
        <dd>{a.data.origin}</dd>
        <dt>Observações</dt>
        <dd>{a.data.notes || "Sem observações"}</dd>
      </dl>
      <div className="actions wrap">
        <Link className="secondary" href={`/app/clientes/${c?.id}`}>
          <Icons.UserRound size={16} />
          Ver cliente
        </Link>
        <a
          className="secondary"
          href={`https://wa.me/${String(c?.whatsapp || c?.phone || "")
            .replace(/\D/g, "")
            .replace(/^(?!55)/, "55")}`}
          target="_blank"
          rel="noreferrer"
        >
          <Icons.Phone size={16} />
          WhatsApp
        </a>
        {!final && (
          <>
            <button className="secondary" onClick={() => setMode("reschedule")}>
              Remarcar
            </button>
            <button className="secondary" onClick={() => setMode("notes")}>
              Editar observações
            </button>
            <button className="danger" onClick={() => setMode("cancel")}>
              Cancelar
            </button>
          </>
        )}
        {["pendente"].includes(a.status) && (
          <button
            className="primary"
            onClick={() => act({ status: "confirmado" })}
            disabled={busy} aria-busy={busy}
          >
            Confirmar
          </button>
        )}
        {a.status === "confirmado" && (
          <button
            className="secondary"
            onClick={() => act({ status: "aguardando" })}
            disabled={busy} aria-busy={busy}
          >
            Cliente chegou
          </button>
        )}
        {["confirmado", "aguardando"].includes(a.status) && (
          <button
            className="primary"
            onClick={() => act({ status: "em atendimento" })}
            disabled={busy} aria-busy={busy}
          >
            Iniciar atendimento
          </button>
        )}
        {a.status === "em atendimento" && (
          <button className="primary" onClick={() => setMode("finish")}>
            Finalizar atendimento
          </button>
        )}
        {["pendente", "confirmado", "aguardando"].includes(a.status) && (
          <button className="secondary" onClick={() => setMode("noshow")}>
            Não compareceu
          </button>
        )}
      </div>
      {mode === "reschedule" && (
        <section className="subpanel">
          <h3>Escolha um novo horário</h3>
          <DateSelector
            date={date}
            onChange={(d) => {
              setDate(d);
              setSelected(null);
            }}
          />
          <div className="times">
            {slots.map((s) => (
              <button
                key={s.time}
                className={s.time === selected ? "selected" : ""}
                onClick={() => setSelected(s.time)}
              >
                {time(s.time)}
              </button>
            ))}
          </div>
          {!slots.length && <p>Sem horários disponíveis nesta data.</p>}
          <button
            className="primary"
            disabled={selected === null || busy}
            onClick={() =>
              act({ operation: "reschedule", date, time: selected })
            }
          >
            Confirmar remarcação
          </button>
        </section>
      )}
      {mode === "notes" && (
        <form
          className="subpanel"
          onSubmit={(e) => {
            e.preventDefault();
            act({
              operation: "notes",
              notes: new FormData(e.currentTarget).get("notes"),
            });
          }}
        >
          <Field label="Observações">
            <textarea name="notes" defaultValue={a.data.notes} />
          </Field>
          <button className="primary" disabled={busy} aria-busy={busy}>
            Salvar
          </button>
        </form>
      )}
      {mode === "finish" && (
        <form
          className="subpanel form-grid"
          onSubmit={(e) => {
            e.preventDefault();
            act({
              status: "concluído",
              discount: Math.round(discount * 100),
              extra: Math.round(extra * 100),
              paymentMethod: new FormData(e.currentTarget).get("method"),
            });
          }}
        >
          <h3 className="span-2">Finalizar atendimento</h3>
          <p className="span-2">
            {a.data.serviceNames.join(" + ")} · {money(a.data.price)}
          </p>
          <Field label="Desconto (R$)">
            <input
              type="number"
              value={discount}
              onChange={(e) => setDiscount(Number(e.target.value))}
              min="0"
              max={a.data.price / 100}
              step="0.01"
            />
          </Field>
          <Field label="Adicional (R$)">
            <input
              type="number"
              value={extra}
              onChange={(e) => setExtra(Number(e.target.value))}
              min="0"
              step="0.01"
            />
          </Field>
          <Field label="Forma de pagamento">
            <select name="method">
              {["Pix", "dinheiro", "débito", "crédito", "outro"].map((x) => (
                <option key={x}>{x}</option>
              ))}
            </select>
          </Field>
          <strong>
            Total:{" "}
            {money(
              a.data.price -
                Math.round(discount * 100) +
                Math.round(extra * 100),
            )}
          </strong>
          <button className="primary span-2" disabled={busy} aria-busy={busy}>
            Finalizar atendimento
          </button>
        </form>
      )}
      {(mode === "cancel" || mode === "noshow") && (
        <form
          className="subpanel"
          onSubmit={(e) => {
            e.preventDefault();
            act({
              status: mode === "cancel" ? "cancelado" : "não compareceu",
              reason: new FormData(e.currentTarget).get("reason"),
            });
          }}
        >
          <h3>
            {mode === "cancel"
              ? "Deseja cancelar este agendamento?"
              : "Registrar que o cliente não compareceu?"}
          </h3>
          {mode === "cancel" && (
            <Field label="Motivo (opcional)">
              <textarea name="reason" />
            </Field>
          )}
          <div className="actions">
            <button
              className="secondary"
              type="button"
              onClick={() => setMode("")}
            >
              Voltar
            </button>
            <button className="danger" disabled={busy} aria-busy={busy}>
              Confirmar
            </button>
          </div>
        </form>
      )}
      <Notice text={error} error />
    </div>
  );
}
