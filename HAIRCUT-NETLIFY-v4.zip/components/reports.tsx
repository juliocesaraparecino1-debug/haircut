"use client";
import { useState } from "react";
import { useSearchParams } from "next/navigation";
import {
  type Snapshot,
  type Appointment,
  today,
  addDays,
  money,
  dayLabel,
} from "@/lib/types";
import { Field, Heading, Icons, Metric, Empty } from "./ui";
export function Reports({
  data,
  commission = false,
  occupancy = false,
}: {
  data: Snapshot;
  commission?: boolean;
  occupancy?: boolean;
}) {
  const daily = useSearchParams().get("periodo") === "hoje";
  const [period, setPeriod] = useState(daily ? "hoje" : "mês"),
    [from, setFrom] = useState(daily ? today() : today().slice(0, 7) + "-01"),
    [to, setTo] = useState(today()),
    [category, setCategory] = useState(
      occupancy ? "agendamentos" : "faturamento",
    );
  function change(v: string) {
    setPeriod(v);
    setTo(today());
    setFrom(
      v === "hoje"
        ? today()
        : v === "semana"
          ? addDays(today(), -6)
          : v === "mês"
            ? today().slice(0, 7) + "-01"
            : v === "ano"
              ? today().slice(0, 4) + "-01-01"
              : from,
    );
  }
  const a = data.appointments.filter((a) => a.date >= from && a.date <= to),
    done = a.filter((a) => a.status === "concluído"),
    total = done.reduce((n, a) => n + (a.data.total ?? a.data.price), 0);
  const c = data.entities.commissions.filter(
    (c) => String(c.date) >= from && String(c.date) <= to,
  );
  const label = (x: Appointment) =>
    category === "profissionais"
      ? data.entities.professionals.find((p) => p.id === x.professional_id)
          ?.name || "Profissional"
      : category === "serviços"
        ? x.data.serviceNames.join(" + ")
        : category === "clientes"
          ? data.entities.clients.find((p) => p.id === x.client_id)?.name ||
            "Cliente"
          : dayLabel(x.date);
  const groups = Object.entries(
    (category === "agendamentos" ? a : done).reduce<Record<string, number>>(
      (o, x) => {
        const k = label(x);
        o[k] =
          (o[k] || 0) +
          (category === "agendamentos" ? 1 : (x.data.total ?? x.data.price));
        return o;
      },
      {},
    ),
  ).sort((a, b) => b[1] - a[1]);
  const max = Math.max(1, ...groups.map((x) => x[1]));
  function csv() {
    const rows = [
      ["Data", "Cliente", "Profissional", "Serviços", "Status", "Valor"],
      ...a.map((x) => [
        x.date,
        data.entities.clients.find((c) => c.id === x.client_id)?.name || "",
        data.entities.professionals.find((p) => p.id === x.professional_id)
          ?.name || "",
        x.data.serviceNames.join(" + "),
        x.status,
        String((x.data.total ?? x.data.price) / 100),
      ]),
    ];
    const text = rows
      .map((r) =>
        r
          .map(
            (x) =>
              '"' +
              String(x)
                .replace(/^[=+@-]/, "'")
                .replaceAll('"', '""') +
              '"',
          )
          .join(";"),
      )
      .join("\r\n");
    const url = URL.createObjectURL(
      new Blob(["\uFEFF" + text], { type: "text/csv;charset=utf-8" }),
    );
    const el = document.createElement("a");
    el.href = url;
    el.download = "haircut-relatorio.csv";
    el.click();
    URL.revokeObjectURL(url);
  }
  return (
    <>
      <Heading
        title={
          commission
            ? "Comissões"
            : occupancy
              ? "Ocupação da agenda"
              : "Relatórios"
        }
        subtitle="Informações calculadas a partir dos atendimentos registrados."
      >
        <button className="secondary" onClick={csv}>
          Exportar CSV
        </button>
      </Heading>
      <div className="panel filters always">
        <Field label="Período">
          <select value={period} onChange={(e) => change(e.target.value)}>
            {["hoje", "semana", "mês", "ano", "personalizado"].map((p) => (
              <option key={p}>{p}</option>
            ))}
          </select>
        </Field>
        <Field label="De">
          <input
            type="date"
            value={from}
            onChange={(e) => {
              setFrom(e.target.value);
              setPeriod("personalizado");
            }}
          />
        </Field>
        <Field label="Até">
          <input
            type="date"
            value={to}
            onChange={(e) => {
              setTo(e.target.value);
              setPeriod("personalizado");
            }}
          />
        </Field>
      </div>
      <div className="metrics">
        <Metric
          label="Faturamento"
          value={money(total)}
          icon={Icons.Wallet}
          onClick={() => setCategory("faturamento")}
        />
        <Metric
          label="Atendimentos concluídos"
          value={done.length}
          icon={Icons.Check}
          tone="green"
          onClick={() => setCategory("agendamentos")}
        />
        <Metric
          label="Ticket médio"
          value={money(done.length ? total / done.length : 0)}
          icon={Icons.ChartNoAxesCombined}
          onClick={() => setCategory("clientes")}
        />
        <Metric
          label="Cancelamentos"
          value={a.filter((x) => x.status === "cancelado").length}
          icon={Icons.CalendarDays}
          tone="amber"
          onClick={() => setCategory("agendamentos")}
        />
      </div>
      {commission ? (
        <section className="panel">
          <h2>Comissão por profissional</h2>
          {data.entities.professionals.map((p) => {
            const rows = c.filter((x) => x.professionalId === p.id);
            return (
              <div className="report-row" key={p.id}>
                <strong>{p.name}</strong>
                <span>{rows.length} atendimentos</span>
                <span>
                  {money(rows.reduce((s, x) => s + Number(x.revenue), 0))}{" "}
                  faturados
                </span>
                <b>
                  {money(rows.reduce((s, x) => s + Number(x.amount), 0))} a
                  receber
                </b>
              </div>
            );
          })}
          <p className="muted">
            Percentual registrado na finalização. Pagamentos de comissão não são
            transferidos automaticamente.
          </p>
        </section>
      ) : (
        <section className="panel">
          <div className="tabs">
            {[
              "faturamento",
              "agendamentos",
              "clientes",
              "profissionais",
              "serviços",
            ].map((k) => (
              <button
                key={k}
                onClick={() => setCategory(k)}
                className={category === k ? "selected" : ""}
              >
                {k}
              </button>
            ))}
          </div>
          <h2>
            {category.charAt(0).toUpperCase() + category.slice(1)} no período
          </h2>
          {groups.length ? (
            <div
              className="chart"
              role="img"
              aria-label={`Gráfico de ${category} no período selecionado`}
            >
              {groups.slice(0, 25).map(([name, n]) => (
                <div className="bar-row" key={name}>
                  <span>{name}</span>
                  <div>
                    <i style={{ width: `${(n / max) * 100}%` }} />
                  </div>
                  <strong>{category === "agendamentos" ? n : money(n)}</strong>
                </div>
              ))}
            </div>
          ) : (
            <Empty
              title="Sem dados neste período"
              text="Os atendimentos realizados aparecerão aqui."
            />
          )}
          <div className="report-row">
            <span>Recebido: {money(total)}</span>
            <span>
              Pendente:{" "}
              {money(
                a
                  .filter(
                    (x) =>
                      !["concluído", "cancelado", "não compareceu"].includes(
                        x.status,
                      ),
                  )
                  .reduce((s, x) => s + x.data.price, 0),
              )}
            </span>
          </div>
        </section>
      )}
    </>
  );
}
