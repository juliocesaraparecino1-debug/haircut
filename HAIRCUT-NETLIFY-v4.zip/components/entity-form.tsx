"use client";
import { useState } from "react";
import {
  type Entity,
  type EntityName,
  type Snapshot,
  minute,
  time,
  today,
} from "@/lib/types";
import { api, Field, Notice, Icons } from "./ui";
export function EntityForm({
  table,
  record,
  snapshot,
  onSaved,
  onDelete,
}: {
  table: EntityName;
  record?: Entity;
  snapshot: Snapshot;
  onSaved: () => void;
  onDelete?: (id: string) => void;
}) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [serviceIds, setServiceIds] = useState<string[]>(
      (record?.serviceIds as string[]) || [],
    ),
    [professionalIds,setProfessionalIds] = useState<string[]>(snapshot.entities.professionals.filter(p=>((p.serviceIds||[]) as string[]).includes(record?.id||'')).map(p=>p.id));
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const form = new FormData(e.currentTarget);
    const data: Record<string, unknown> = {
      ...record,
      ...Object.fromEntries(form),
    };
    delete data.id;
    delete data.created_at;
    delete data.updated_at;
    if (["clients", "services", "professionals"].includes(table))
      data.active = form.get("active") === "on";
    if (table === "clients") data.favorite = form.get("favorite") === "on";
    if (table === "services") {
      data.price = Math.round(Number(data.price) * 100);
      data.duration = Number(data.duration);
      data.professionalIds = professionalIds;
    }
    if (table === "professionals") {
      data.commission = Number(data.commission);
      data.serviceIds = serviceIds;
    }
    if (table === "schedule_blocks") {
      data.start = minute(String(data.start));
      data.end = minute(String(data.end));
    }
    try {
      await api("/api/data", { action: "save", table, id: record?.id, data });
      onSaved();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const input = (
    name: string,
    label: string,
    type = "text",
    required = false,
    def: unknown = "",
  ) => (
    <Field label={label}>
      <input
        name={name}
        type={type}
        defaultValue={String(record?.[name] ?? def)}
        required={required}
        step={type === "number" ? "0.01" : undefined}
        min={type === "number" ? "0" : undefined}
      />
    </Field>
  );
  return (
    <form onSubmit={submit} className="form-grid">
      {input(
        "name",
        table === "schedule_blocks"
          ? "Motivo"
          : table === "closed_dates"
            ? "Descrição"
            : "Nome",
        "text",
        true,
      )}
      {table === "clients" && (
        <>
          {input("phone", "Telefone com DDD", "tel", true)}
          {input("whatsapp", "WhatsApp", "tel")}
          {input("email", "E-mail", "email")}
          {input("birthday", "Aniversário", "date")}
          <Field label="Observações internas">
            <textarea name="notes" defaultValue={String(record?.notes || "")} />
          </Field>
          <label className="check">
            <input
              type="checkbox"
              name="favorite"
              defaultChecked={Boolean(record?.favorite)}
            />
            Cliente favorito
          </label>
        </>
      )}
      {table === "services" && (
        <>
          <Field label="Preço (R$)">
            <input
              name="price"
              type="number"
              min="0"
              step="0.01"
              defaultValue={Number(record?.price || 0) / 100}
              required
            />
          </Field>
          {input("duration", "Duração (minutos)", "number", true, 30)}
          {input("category", "Categoria")}
          <Field label="Descrição">
            <textarea
              name="description"
              defaultValue={String(record?.description || "")}
            />
          </Field>
          <div className="span-2"><h3>Profissionais responsáveis</h3>{snapshot.entities.professionals.map(p=><label className="check" key={p.id}><input type="checkbox" checked={professionalIds.includes(p.id)} onChange={()=>setProfessionalIds(professionalIds.includes(p.id)?professionalIds.filter(id=>id!==p.id):[...professionalIds,p.id])}/>{p.name}</label>)}</div>
        </>
      )}
      {table === "professionals" && (
        <>
          {input("phone", "Telefone", "tel")}
          {input("email", "E-mail", "email")}
          {input("specialty", "Especialidade", "text", false, "Barbeiro")}
          {input("photo", "URL da foto", "text")}
          {input("commission", "Comissão (%)", "number", false, 0)}
          <Field label="Descrição">
            <textarea
              name="description"
              defaultValue={String(record?.description || "")}
            />
          </Field>
          <div className="span-2">
            <h3>Serviços realizados</h3>
            {snapshot.entities.services.map((s) => (
              <label className="check" key={s.id}>
                <input
                  type="checkbox"
                  checked={serviceIds.includes(s.id)}
                  onChange={() =>
                    setServiceIds(
                      serviceIds.includes(s.id)
                        ? serviceIds.filter((x) => x !== s.id)
                        : [...serviceIds, s.id],
                    )
                  }
                />
                {s.name}
              </label>
            ))}
          </div>
          {input("userId", "ID do membro vinculado (opcional)")}
        </>
      )}
      {["closed_dates", "schedule_blocks"].includes(table) &&
        input("date", "Data", "date", true, today())}
      {table === "schedule_blocks" && (
        <>
          <Field label="Profissional">
            <select
              name="professionalId"
              defaultValue={String(record?.professionalId || "")}
            >
              <option value="">Todos os profissionais</option>
              {snapshot.entities.professionals.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Início">
            <input
              name="start"
              type="time"
              defaultValue={time(Number(record?.start || 720))}
              required
            />
          </Field>
          <Field label="Fim">
            <input
              name="end"
              type="time"
              defaultValue={time(Number(record?.end || 780))}
              required
            />
          </Field>
        </>
      )}
      {table === "support_tickets" && (
        <Field label="Como podemos ajudar?">
          <textarea name="message" minLength={5} required />
        </Field>
      )}
      {["clients", "services", "professionals"].includes(table) && (
        <label className="check">
          <input
            type="checkbox"
            name="active"
            defaultChecked={record?.active !== false}
          />
          Cadastro ativo
        </label>
      )}
      <div className="span-2">
        <Notice text={error} error />
        <div className="actions">
          {record && onDelete && (
            <button
              type="button"
              className="danger"
              onClick={() => onDelete(record.id)}
            >
              <Icons.Trash2 size={17} />
              Excluir
            </button>
          )}
          <button className="primary" disabled={busy} aria-busy={busy}>
            {busy ? "Salvando…" : "Salvar alterações"}
            <Icons.Check size={18} />
          </button>
        </div>
      </div>
    </form>
  );
}
