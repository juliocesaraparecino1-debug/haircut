"use client";
import { useEffect, useState } from "react";
import {
  addDays,
  dayLabel,
  money,
  time,
  today,
  type PublicData,
  type Snapshot,
} from "@/lib/types";
import { api, Avatar, Empty, Field, Icons, Notice } from "./ui";
type Slot = {
  time: number;
  professionalId: string;
  duration: number;
  price: number;
};
export function DateSelector({
  date,
  onChange,
}: {
  date: string;
  onChange: (v: string) => void;
}) {
  return (
    <>
      <div className="days">
        {Array.from({ length: 7 }, (_, i) => addDays(today(), i)).map(
          (d, i) => (
            <button
              key={d}
              type="button"
              className={date === d ? "selected" : ""}
              onClick={() => onChange(d)}
            >
              <span>
                {i === 0
                  ? "HOJE"
                  : i === 1
                    ? "AMANHÃ"
                    : new Date(d + "T12:00:00Z")
                        .toLocaleDateString("pt-BR", { weekday: "short" })
                        .replace(".", "")
                        .toUpperCase()}
              </span>
              <strong>{Number(d.slice(-2))}</strong>
            </button>
          ),
        )}
      </div>
      <Field label="Ver outras datas">
        <input
          type="date"
          value={date}
          min={today()}
          onChange={(e) => onChange(e.target.value)}
          required
        />
      </Field>
    </>
  );
}
export function Booking({
  data,
  internal,
  onDone,
  initialClient,
  backRef,
  externalBack,
}: {
  data: PublicData | Snapshot;
  internal?: boolean;
  onDone: (r: { id: string; token: string }) => void;
  initialClient?: string;
  backRef?: { current: () => void };
  externalBack?: () => void;
}) {
  const services =
      "entities" in data
        ? data.entities.services.filter((x) => x.active !== false)
        : data.services,
    professionals =
      "entities" in data
        ? data.entities.professionals.filter((x) => x.active !== false)
        : data.professionals;
  const clients = "entities" in data ? data.entities.clients : [];
  const [stage, setStage] = useState(0),
    [ids, setIds] = useState<string[]>([]),
    [professional, setProfessional] = useState(""),
    [date, setDate] = useState(today()),
    [slot, setSlot] = useState<Slot | null>(null),
    [slots, setSlots] = useState<Slot[]>([]),
    [clientId, setClientId] = useState(initialClient || ""),
    [search, setSearch] = useState(""),
    [client, setClient] = useState({
      name: "",
      phone: "",
      whatsapp: "",
      email: "",
      notes: "",
      birthday: "",
    }),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [slotsLoading, setSlotsLoading] = useState(false),
    [wait, setWait] = useState(false),
    [period, setPeriod] = useState("qualquer"),
    [notes, setNotes] = useState("");
  const steps = internal
    ? ["Cliente", "Serviço", "Profissional", "Data", "Horário", "Confirmação"]
    : ["Serviço", "Profissional", "Data", "Horário", "Dados", "Confirmação"];
  const step = steps[stage];
  useEffect(() => {
    if (backRef)
      backRef.current = stage > 0
        ? () => { setError(""); setStage(current => Math.max(0, current - 1)); }
        : (externalBack || (() => {}));
  }, [backRef, externalBack, stage]);
  const price = services
      .filter((x) => ids.includes(x.id))
      .reduce((s, x) => s + Number(x.price), 0),
    duration = services
      .filter((x) => ids.includes(x.id))
      .reduce((s, x) => s + Number(x.duration), 0);
  useEffect(() => {
    if (!ids.length) return;
    let current = true;
    setSlotsLoading(true);
    setError("");
    const q = new URLSearchParams({
      slots: "1",
      date,
      services: ids.join(","),
      professional,
      ...(!internal ? { slug: data.shop.slug } : {}),
    });
    api<Slot[]>(`${internal ? "/api/data" : "/api/public"}?${q}`)
      .then((r) => {
        if (current) setSlots(r);
      })
      .catch((e) => {
        if (current) setError(e.message);
      })
      .finally(() => {
        if (current) setSlotsLoading(false);
      });
    return () => {
      current = false;
    };
  }, [ids, professional, date, internal, data.shop.slug]);
  function selectServices(id: string) {
    setIds(ids.includes(id) ? ids.filter((x) => x !== id) : [...ids, id]);
    setSlot(null);
    setProfessional("");
  }
  async function next() {
    setError("");
    if (step === "Serviço" && !ids.length) {
      setError("Selecione pelo menos um serviço.");
      return;
    }
    if (
      (step === "Cliente" || step === "Dados") &&
      !clientId &&
      (!client.name.trim() || (internal ? client.phone : client.whatsapp).replace(/\D/g, "").length < 10)
    ) {
      setError(`Informe nome e ${internal ? "telefone" : "WhatsApp"} com DDD.`);
      return;
    }
    if (step === "Horário" && !slot) {
      setError("Selecione um horário disponível.");
      return;
    }
    if (stage < 5) {
      setStage(stage + 1);
      return;
    }
    setBusy(true);
    try {
      const result = await api<{ id: string; token: string }>(
        internal ? "/api/data" : "/api/public",
        {
          action: "book",
          slug: data.shop.slug,
          serviceIds: ids,
          professionalId: slot?.professionalId,
          date,
          time: slot?.time,
          clientId: clientId || undefined,
          client: clientId ? undefined : internal ? client : { ...client, phone: client.whatsapp, whatsapp: client.whatsapp, email: "" },
          notes,
        },
      );
      onDone(result);
    } catch (e) {
      setError((e as Error).message);
      setSlot(null);
      setStage(steps.indexOf("Horário"));
    } finally {
      setBusy(false);
    }
  }
  async function waitlist(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const r = await api<{ message: string }>("/api/public", {
        action: "waitlist",
        slug: data.shop.slug,
        name: client.name,
        phone: internal ? client.phone : client.whatsapp,
        date,
        professionalId: professional,
        period,
      });
      setError(r.message);
      setWait(false);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="booking">
      <ol className="steps">
        {steps.map((s, i) => (
          <li
            key={s}
            className={i === stage ? "active" : i < stage ? "done" : ""}
          >
            <span>{i < stage ? <Icons.Check size={15} /> : i + 1}</span>
            <small>{s}</small>
          </li>
        ))}
      </ol>
      <h2>
        {step === "Confirmação"
          ? "Confira seu agendamento"
          : step === "Cliente" || step === "Dados"
            ? "Quem vai ser atendido?"
            : `Escolha ${step === "Data" ? "uma data" : step === "Horário" ? "um horário" : step === "Serviço" ? "o serviço" : "o profissional"}`}
      </h2>
      {(step === "Cliente" || step === "Dados") && (
        <>
          <p className="muted">
            {internal
              ? "Encontre um cliente ou cadastre um novo."
              : "Sem precisar criar conta."}
          </p>
          {internal && (
            <>
              <label className="input-icon">
                <Icons.Search />
                <input
                  aria-label="Pesquisar cliente"
                  placeholder="Buscar nome ou telefone"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </label>
              <div className="client-picker">
                {clients
                  .filter(
                    (x) =>
                      x.active !== false &&
                      `${x.name} ${x.phone}`
                        .toLowerCase()
                        .includes(search.toLowerCase()),
                  )
                  .slice(0, 8)
                  .map((c) => (
                    <button
                      key={c.id}
                      className={clientId === c.id ? "selected" : ""}
                      onClick={() => setClientId(c.id)}
                    >
                      <Avatar name={c.name} />
                      <span>
                        {c.name}
                        <small>{String(c.phone)}</small>
                      </span>
                      {clientId === c.id && <Icons.Check />}
                    </button>
                  ))}
              </div>
              <button className="secondary" onClick={() => setClientId("")}>
                <Icons.Plus size={16} />
                Adicionar novo cliente
              </button>
            </>
          )}
          {!clientId && (
            <div className="form-grid">
              {[
                ["name", "Nome completo"],
                ...(internal
                  ? [
                      ["phone", "Telefone com DDD"],
                      ["whatsapp", "WhatsApp (opcional)"],
                      ["email", "E-mail (opcional)"],
                      ["birthday", "Aniversário"],
                      ["notes", "Observações internas"],
                    ]
                  : [["whatsapp", "WhatsApp com DDD"]]),
              ].map(([key, label]) => (
                <Field key={key} label={label}>
                  <input
                    value={client[key as keyof typeof client]}
                    type={
                      key === "email"
                        ? "email"
                        : key === "birthday"
                          ? "date"
                          : key === "phone" || key === "whatsapp"
                            ? "tel"
                            : "text"
                    }
                    onChange={(e) =>
                      setClient({ ...client, [key]: e.target.value })
                    }
                    required={key === "name" || key === "phone" || (!internal && key === "whatsapp")}
                  />
                </Field>
              ))}
            </div>
          )}
        </>
      )}
      {step === "Serviço" && (
        <div className="choice-grid">
          {services.map((s) => (
            <button
              className={`choice ${ids.includes(s.id) ? "selected" : ""}`}
              key={s.id}
              onClick={() => selectServices(s.id)}
            >
              <Icons.Scissors size={27} />
              <strong>{s.name}</strong>
              <small>
                <Icons.Clock size={14} />
                {String(s.duration)} min
              </small>
              <b>{money(Number(s.price))}</b>
              {s.description ? <small>{String(s.description)}</small> : null}
            </button>
          ))}
          {!services.length && (
            <Empty
              title="Nenhum serviço disponível"
              text="Entre em contato com a barbearia."
            />
          )}
        </div>
      )}
      {step === "Profissional" && (
        <>
          <button
            className={`any-professional ${!professional ? "selected" : ""}`}
            onClick={() => {
              setProfessional("");
              setSlot(null);
            }}
          >
            <Icons.Users />
            Qualquer profissional disponível{!professional && <Icons.Check />}
          </button>
          <div className="choice-grid">
            {professionals
              .filter((p) =>
                ids.every((id) =>
                  ((p.serviceIds || []) as string[]).includes(id),
                ),
              )
              .map((p) => (
                <button
                  key={p.id}
                  className={`choice ${professional === p.id ? "selected" : ""}`}
                  onClick={() => {
                    setProfessional(p.id);
                    setSlot(null);
                  }}
                >
                  <Avatar name={p.name} photo={p.photo} size="big" />
                  <strong>{p.name}</strong>
                  <small>{String(p.specialty || "Barbeiro")}</small>
                </button>
              ))}
          </div>
        </>
      )}
      {step === "Data" && (
        <DateSelector
          date={date}
          onChange={(d) => {
            setDate(d);
            setSlot(null);
          }}
        />
      )}
      {step === "Horário" && (
        <>
          <p className="muted">
            {dayLabel(date, true)} · {duration} min
          </p>
          {slotsLoading ? (
            <div className="skeleton" />
          ) : (
            <div className="times">
              {slots
                .filter(
                  (s, i, arr) => arr.findIndex((x) => x.time === s.time) === i,
                )
                .map((s) => (
                  <button
                    className={slot?.time === s.time ? "selected" : ""}
                    key={s.time}
                    onClick={() => setSlot(s)}
                  >
                    {time(s.time)}
                  </button>
                ))}
            </div>
          )}
          {!slotsLoading && !slots.length && (
            <Empty
              title="Sem horários disponíveis"
              text="Escolha outro dia ou profissional."
            >
              {!internal && "waitlistEnabled" in data && data.waitlistEnabled && (
                <button className="secondary" onClick={() => setWait(true)}>
                  Entrar na lista de espera
                </button>
              )}
            </Empty>
          )}
          {wait && (
            <form onSubmit={waitlist} className="panel">
              <h3>Lista de espera</h3>
              <Field label="Nome">
                <input
                  value={client.name}
                  onChange={(e) =>
                    setClient({ ...client, name: e.target.value })
                  }
                  required
                />
              </Field>
              <Field label="Telefone">
                <input
                  value={client.phone}
                  onChange={(e) =>
                    setClient({ ...client, phone: e.target.value })
                  }
                  required
                  minLength={10}
                />
              </Field>
              <Field label="Período">
                <select
                  value={period}
                  onChange={(e) => setPeriod(e.target.value)}
                >
                  <option>qualquer</option>
                  <option>manhã</option>
                  <option>tarde</option>
                </select>
              </Field>
              <button className="primary" disabled={busy} aria-busy={busy}>
                Entrar na lista
              </button>
            </form>
          )}
        </>
      )}
      {step === "Confirmação" && (
        <div className="panel summary">
          <h3>{data.shop.name}</h3>
          <dl>
            <dt>Cliente</dt>
            <dd>
              {clients.find((c) => c.id === clientId)?.name || client.name}
            </dd>
            <dt>Serviços</dt>
            <dd>
              {services
                .filter((s) => ids.includes(s.id))
                .map((s) => s.name)
                .join(" + ")}
            </dd>
            <dt>Profissional</dt>
            <dd>
              {professionals.find((p) => p.id === slot?.professionalId)?.name}
            </dd>
            <dt>Data</dt>
            <dd>{dayLabel(date, true)}</dd>
            <dt>Horário</dt>
            <dd>{slot && time(slot.time)}</dd>
            <dt>Duração</dt>
            <dd>{duration} minutos</dd>
            <dt>Total</dt>
            <dd className="price">{money(price)}</dd>
          </dl>
          {internal && (
            <Field label="Observações do agendamento">
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </Field>
          )}
        </div>
      )}
      <Notice text={error} error />
      <div className="booking-footer">
        {stage > 0 && (
          <button
            className="secondary"
            onClick={() => setStage(stage - 1)}
            disabled={busy} aria-busy={busy}
          >
            <Icons.ArrowLeft size={17} />
            Voltar
          </button>
        )}
        <button
          className="primary"
          onClick={next}
          disabled={busy || slotsLoading}
        >
          {busy
            ? "Confirmando…"
            : stage === 5
              ? "Confirmar agendamento"
              : "Continuar"}
          <Icons.ChevronRight />
        </button>
      </div>
      <p className="secure">
        <Icons.Shield size={16} />
        {internal
          ? "Disponibilidade validada em tempo real"
          : "Sem precisar criar conta"}
      </p>
    </div>
  );
}
