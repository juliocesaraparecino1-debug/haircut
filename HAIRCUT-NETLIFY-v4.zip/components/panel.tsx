"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";
import {
  type Appointment,
  type Entity,
  type EntityName,
  type Snapshot,
  money,
  today,
  dayLabel,
  time,
  addDays,
} from "@/lib/types";
import {
  api,
  Avatar,
  Badge,
  Empty,
  Heading,
  Icons,
  Logo,
  Metric,
  Modal,
  Notice,
} from "./ui";
import { Booking } from "./booking";
import { EntityForm } from "./entity-form";
import { AppointmentDetail } from "./appointment-detail";
import { Reports } from "./reports";
import { hasPro } from "@/lib/plans";
import { PlanUpgrade, SubscriptionPage } from "./subscription";
import { RetentionPage } from "./retention";
import { SettingsPage, HoursPage, SecurityPage, LinkPage } from "./settings";
const hours = (minutes: number) =>
  `${new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 }).format(Math.max(0, minutes) / 60)} h`;
const nav = [
  ["inicio", "Início", Icons.Home, "/app"],
  ["agenda", "Agenda", Icons.CalendarDays, "/app/agenda"],
  ["clientes", "Clientes", Icons.Users, "/app/clientes"],
  ["perfil", "Perfil", Icons.UserRound, "/app/perfil"],
] as const;
const menu = [
  [
    "editar-perfil",
    "Editar perfil",
    "Altere seus dados pessoais",
    Icons.UserRound,
  ],
  [
    "barbearia",
    "Dados da barbearia",
    "Nome, endereço e informações",
    Icons.Store,
  ],
  [
    "horarios",
    "Horários de atendimento",
    "Configure seus dias e horários",
    Icons.Clock,
  ],
  [
    "profissionais",
    "Profissionais",
    "Equipe, serviços e comissões",
    Icons.Users,
  ],
  ["servicos", "Serviços", "Seu catálogo de atendimentos", Icons.Scissors],
  ["notificacoes", "Notificações", "Escolha o que deseja receber", Icons.Bell],
  ["assinatura", "Assinatura", "Gerencie seu plano e recursos", Icons.Crown],
  [
    "seguranca",
    "Segurança",
    "Senha e verificação em duas etapas",
    Icons.Shield,
  ],
] as const;
type Dialog =
  | { kind: "booking"; clientId?: string }
  | { kind: "appointment"; id: string }
  | { kind: "entity"; table: EntityName; record?: Entity }
  | { kind: "delete"; table: EntityName; id: string }
  | null;
export function Panel() {
  const pathname = usePathname();
  const [, , routeSection, recordId] = pathname.split("/");
  const section = routeSection || "inicio";
  const params = useSearchParams();
  const [data, setData] = useState<Snapshot | null>(null),
    [error, setError] = useState(""),
    [toast, setToast] = useState(""),
    [dialog, setDialog] = useState<Dialog>(null),
    [search, setSearch] = useState(""),
    [date, setDate] = useState(today()),
    [status, setStatus] = useState(params.get("status") || ""),
    [clientTab, setClientTab] = useState("Todos"),
    [filters, setFilters] = useState(false),
    [pro, setPro] = useState(""),
    [service, setService] = useState(""),
    [origin, setOrigin] = useState(""),
    [hour, setHour] = useState(""),
    [busy, setBusy] = useState(false);
  const load = useCallback(async () => {
    try {
      const d = await api<Snapshot>("/api/data");
      setData(d);
      setError("");
    } catch (e) {
      setError((e as Error).message);
    }
  }, []);
  useEffect(() => {
    load();
    const id = setInterval(() => {
      if (document.visibilityState === "visible") load();
    }, 30000);
    return () => clearInterval(id);
  }, [load]);
  useEffect(() => {
    setSearch("");
    setDialog(null);
    setStatus(params.get("status") || "");
  }, [section, recordId, params]);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 4500);
    return () => clearTimeout(t);
  }, [toast]);
  async function saved() {
    await load();
    setDialog(null);
    setToast("Salvo com sucesso.");
  }
  const openNew = (table: EntityName, record?: Entity) =>
    setDialog({ kind: "entity", table, record });
  async function remove() {
    if (dialog?.kind !== "delete") return;
    setBusy(true);
    try {
      await api("/api/data", {
        action: "delete",
        table: dialog.table,
        id: dialog.id,
      });
      await saved();
    } catch (e) {
      setToast((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  if (!data)
    return (
      <main className="loading">
        <Logo />
        <Notice text={error} error />
        {error ? (
          <button className="primary" onClick={load}>
            Tentar novamente
          </button>
        ) : (
          <>
            <div className="skeleton" />
            <div className="skeleton" />
          </>
        )}
      </main>
    );
  const admin = ["OWNER", "ADMIN"].includes(data.role),
    all = data.appointments,
    day = all.filter((a) => a.date === (section === "agenda" ? date : today())),
    done = day.filter((a) => a.status === "concluído"),
    revenue = done.reduce((sum, a) => sum + (a.data.total ?? a.data.price), 0),
    confirmed = day.filter((a) => a.status === "confirmado").length,
    pending = day.filter((a) => a.status === "pendente").length;
  const navigate = (path: string) => {
    if (path === window.location.pathname + window.location.search) return;
    window.history.pushState(null, "", path);
    window.scrollTo({ top: 0, behavior: "instant" });
  };
  const goto = (path: string) => navigate("/app/" + path);
  const appointments = day
    .filter((a) => {
      const c = data.entities.clients.find((c) => c.id === a.client_id),
        p = data.entities.professionals.find((p) => p.id === a.professional_id);
      return (
        (!status || a.status === status) &&
        (!pro || a.professional_id === pro) &&
        (!service || a.data.serviceIds.includes(service)) &&
        (!origin || a.data.origin === origin) &&
        (!hour || time(a.start_minute) >= hour) &&
        `${c?.name} ${c?.phone} ${p?.name} ${a.data.serviceNames.join(" ")}`
          .toLowerCase()
          .includes(search.toLowerCase())
      );
    })
    .sort((a, b) => a.start_minute - b.start_minute);
  const activeDay = section === "agenda" ? date : today(),
    weekday = new Date(activeDay + "T12:00:00Z").getUTCDay(),
    business = data.entities.business_hours.find((h) => h.weekday === weekday);
  const activePros = data.entities.professionals.filter(
    (p) => p.active !== false,
  );
  const capacity =
    business && !business.closed
      ? activePros.reduce((sum, p) => {
          const own = data.entities.professional_hours.find(
            (h) => h.professionalId === p.id && h.weekday === weekday,
          );
          if (own?.closed) return sum;
          const start = Math.max(
              Number(business.start),
              Number(own?.start ?? business.start),
            ),
            end = Math.min(
              Number(business.end),
              Number(own?.end ?? business.end),
            );
          const intervals = [
            ...((business.breaks as { start: number; end: number }[]) || []),
            ...((own?.breaks as { start: number; end: number }[]) || []),
            ...data.entities.schedule_blocks
              .filter(
                (b) =>
                  b.date === activeDay &&
                  (!b.professionalId || b.professionalId === p.id),
              )
              .map((b) => ({ start: Number(b.start), end: Number(b.end) })),
          ];
          let available = 0;
          for (let i = start; i < end; i++)
            if (!intervals.some((b) => i >= b.start && i < b.end)) available++;
          return sum + available;
        }, 0)
      : 0;
  const occupied = day
      .filter((a) => !["cancelado", "não compareceu"].includes(a.status))
      .reduce((s, a) => s + a.data.duration, 0),
    closed = data.entities.closed_dates.some((x) => x.date === activeDay),
    minutes = closed ? 0 : capacity,
    occupancy = minutes
      ? Math.min(100, Math.round((occupied / minutes) * 100))
      : 0;
  function appointmentRow(a: Appointment) {
    const c = data!.entities.clients.find((x) => x.id === a.client_id),
      p = data!.entities.professionals.find((x) => x.id === a.professional_id);
    return (
      <button
        className="appointment-row"
        key={a.id}
        onClick={() => setDialog({ kind: "appointment", id: a.id })}
      >
        <span className="time-box">{time(a.start_minute)}</span>
        <Avatar name={c?.name} photo={c?.photo} />
        <span className="appointment-person">
          <strong>{c?.name || "Cliente"}</strong>
          <span>{a.data.serviceNames.join(" + ")}</span>
          {section === "agenda" && (
            <small>
              <Icons.Scissors size={13} />
              com {p?.name}
            </small>
          )}
        </span>
        <Badge status={a.status} />
        <Icons.ChevronRight size={18} />
      </button>
    );
  }
  function metrics() {
    return (
      <div className="metrics">
        <Metric
          label={section === "agenda" ? "Neste dia" : "Agendamentos hoje"}
          value={day.length}
          icon={Icons.CalendarDays}
          onClick={() => {
            goto("agenda");
            setStatus("");
          }}
        />
        <Metric
          label="Confirmados"
          value={confirmed}
          tone="green"
          icon={Icons.Check}
          detail={`${day.length ? Math.round((confirmed / day.length) * 100) : 0}% dos agendamentos`}
          onClick={() => goto("agenda?status=confirmado")}
        />
        <Metric
          label="Pendentes"
          value={pending}
          tone="amber"
          icon={Icons.Clock}
          detail="Aguardando confirmação"
          onClick={() => goto("agenda?status=pendente")}
        />
        <Metric
          label={section === "agenda" ? "Tempo livre" : "Faturamento do dia"}
          value={
            section === "agenda"
              ? hours(minutes - occupied)
              : money(revenue)
          }
          icon={section === "agenda" ? Icons.Zap : Icons.Wallet}
          onClick={() =>
            goto(section === "agenda" ? "ocupacao" : "relatorios?periodo=hoje")
          }
        />
      </div>
    );
  }
  const entityTable: EntityName | undefined =
    section === "profissionais"
      ? "professionals"
      : section === "servicos"
        ? "services"
        : section === "bloqueios"
          ? "schedule_blocks"
          : section === "feriados"
            ? "closed_dates"
            : undefined;
  let content: React.ReactNode;
  if (section === "inicio")
    content = (
      <>
        <Heading
          title={`Olá, ${data.user.name.split(" ")[0]}`}
          subtitle="Aqui está o resumo do seu dia."
        />
        {metrics()}
        <div className="dashboard-grid">
          <section className="panel upcoming">
            <div className="section-heading">
              <h2>
                <Icons.CalendarDays />
                Próximos horários
              </h2>
              <Link href="/app/agenda">
                Ver todos <Icons.ChevronRight size={17} />
              </Link>
            </div>
            {day
              .filter(
                (a) =>
                  !["cancelado", "concluído", "não compareceu"].includes(
                    a.status,
                  ),
              )
              .sort((a, b) => a.start_minute - b.start_minute)
              .slice(0, 5)
              .map(appointmentRow)}
            {!day.length && (
              <Empty
                title="Sua agenda está livre"
                text="Crie um atendimento ou compartilhe seu link de agendamento."
              />
            )}
          </section>
          <section className="quick-section">
            <h2>
              <Icons.Zap className="red-text" />
              Ações rápidas
            </h2>
            <div className="quick-grid">
              {[
                [
                  Icons.CalendarDays,
                  "Novo agendamento",
                  () => setDialog({ kind: "booking" }),
                ],
                [Icons.CalendarDays, "Agenda", () => goto("agenda")],
                [Icons.Users, "Clientes", () => goto("clientes")],
                [Icons.Scissors, "Barbeiros", () => goto("profissionais")],
              ].map(([Icon, label, fn], i) => {
                const I = Icon as typeof Icons.Home;
                return (
                  <button
                    className={i === 0 ? "accent" : ""}
                    key={String(label)}
                    onClick={fn as () => void}
                    disabled={i === 0 && !admin}
                  >
                    <I size={30} />
                    <span>{String(label)}</span>
                  </button>
                );
              })}
            </div>
            <button
              className="panel occupancy"
              onClick={() => goto("ocupacao")}
            >
              <span
                className="ring"
                style={{
                  background: `conic-gradient(var(--red) ${occupancy}%,#29292b 0)`,
                }}
              >
                <b>{occupancy}%</b>
              </span>
              <span>
                <strong>Taxa de ocupação</strong>
                <small>Hoje</small>
                <small>
                  {hours(occupied)} de {hours(minutes)} preenchidas
                </small>
              </span>
              <Icons.ChevronRight />
            </button>
          </section>
        </div>
      </>
    );
  else if (section === "agenda")
    content = (
      <>
        <Heading
          title="Agendamento"
          subtitle="Gerencie seus horários e atendimentos."
        >
          <div className="actions">
            <button
              className="icon"
              aria-label="Pesquisar agenda"
              onClick={() => document.getElementById("agenda-search")?.focus()}
            >
              <Icons.Search />
            </button>
            <button
              className="icon"
              aria-label="Filtros da agenda"
              onClick={() => setFilters(!filters)}
            >
              <Icons.SlidersHorizontal />
            </button>
          </div>
        </Heading>
        <div className="day-navigation">
          <button
            className="icon"
            aria-label="Semana anterior"
            onClick={() => setDate(addDays(date, -7))}
          >
            <Icons.ArrowLeft />
          </button>
          <div className="days">
            {Array.from({ length: 7 }, (_, i) => addDays(date, i - 3)).map(
              (d) => (
                <button
                  key={d}
                  className={date === d ? "selected" : ""}
                  onClick={() => setDate(d)}
                >
                  <span>
                    {new Date(d + "T12:00:00Z")
                      .toLocaleDateString("pt-BR", { weekday: "short" })
                      .replace(".", "")}
                  </span>
                  <strong>{d.slice(-2)}</strong>
                </button>
              ),
            )}
          </div>
          <button
            className="icon"
            aria-label="Próxima semana"
            onClick={() => setDate(addDays(date, 7))}
          >
            <Icons.ChevronRight />
          </button>
        </div>
        {metrics()}
        <div className="toolbar">
          <label className="input-icon">
            <Icons.Search />
            <input
              id="agenda-search"
              placeholder="Cliente, telefone, profissional ou serviço"
              aria-label="Buscar agendamento"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </label>
          {admin && (
            <button
              className="primary"
              onClick={() => setDialog({ kind: "booking" })}
            >
              <Icons.Plus />
              Novo agendamento
            </button>
          )}
        </div>
        {filters && (
          <div className="panel filters">
            <label>
              Profissional
              <select value={pro} onChange={(e) => setPro(e.target.value)}>
                <option value="">Todos</option>
                {data.entities.professionals.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Serviço
              <select
                value={service}
                onChange={(e) => setService(e.target.value)}
              >
                <option value="">Todos</option>
                {data.entities.services.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Status
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value)}
              >
                <option value="">Todos</option>
                {[
                  "confirmado",
                  "pendente",
                  "aguardando",
                  "em atendimento",
                  "concluído",
                  "cancelado",
                  "não compareceu",
                ].map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </label>
            <label>
              Origem
              <select
                value={origin}
                onChange={(e) => setOrigin(e.target.value)}
              >
                <option value="">Todas</option>
                <option>interno</option>
                <option>público</option>
              </select>
            </label>
            <label>
              A partir de
              <input
                type="time"
                value={hour}
                onChange={(e) => setHour(e.target.value)}
              />
            </label>
            <label>
              Data
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
            </label>
            <button className="primary" onClick={() => setFilters(false)}>
              Aplicar filtros
            </button>
            <button
              className="secondary"
              onClick={() => {
                setPro("");
                setService("");
                setStatus("");
                setOrigin("");
                setHour("");
              }}
            >
              Limpar
            </button>
          </div>
        )}
        <div className="section-heading">
          <h2>{dayLabel(date, true)}</h2>
          <small>{appointments.length} agendamentos</small>
        </div>
        <section className="timeline">
          {appointments.map(appointmentRow)}
          {!appointments.length && (
            <Empty
              title="Nenhum agendamento encontrado"
              text="Escolha outra data ou ajuste os filtros."
            />
          )}
        </section>
      </>
    );
  else if (section === "clientes" && recordId) {
    const c = data.entities.clients.find((x) => x.id === recordId);
    const history = all.filter((a) => a.client_id === recordId),
      visits = history.filter((a) => a.status === "concluído"),
      spent = visits.reduce((s, a) => s + (a.data.total ?? a.data.price), 0);
    content = c ? (
      <>
        <Heading
          title="Perfil do cliente"
          subtitle="Relacionamento e histórico de atendimentos."
        />
        <section className="panel">
          <div className="detail-person">
            <Avatar name={c.name} photo={c.photo} size="big" />
            <div>
              <h2>
                {c.name}{" "}
                {Boolean(c.favorite) && (
                  <Icons.Star className="amber-text" size={20} />
                )}
              </h2>
              <p>
                {String(c.phone)} · {String(c.email || "Sem e-mail")}
              </p>
              <small>
                Cadastrado em{" "}
                {new Date(c.created_at).toLocaleDateString("pt-BR")} ·{" "}
                {c.active === false ? "Inativo" : "Ativo"}
              </small>
            </div>
          </div>
          <div className="stats-strip">
            <span>
              <strong>{visits.length}</strong>visitas
            </span>
            <span>
              <strong>{money(spent)}</strong>valor gasto
            </span>
            <span>
              <strong>
                {money(visits.length ? spent / visits.length : 0)}
              </strong>
              ticket médio
            </span>
          </div>
          <p>
            <b>Observações internas</b>
            <br />
            {String(c.notes || "Sem observações.")}
          </p>
          <div className="actions wrap">
            {admin && (
              <>
                <button
                  className="primary"
                  onClick={() => setDialog({ kind: "booking", clientId: c.id })}
                >
                  Novo agendamento
                </button>
                <button
                  className="secondary"
                  onClick={() => openNew("clients", c)}
                >
                  <Icons.Pencil size={16} />
                  Editar
                </button>
                <button
                  className="secondary"
                  onClick={async () => {
                    try {
                      await api("/api/data", {
                        action: "save",
                        table: "clients",
                        id: c.id,
                        data: { ...c, favorite: !c.favorite },
                      });
                      await load();
                    } catch (e) {
                      setToast((e as Error).message);
                    }
                  }}
                >
                  {c.favorite ? "Desfavoritar" : "Favoritar"}
                </button>
                <button
                  className="secondary"
                  onClick={async () => {
                    try {
                      await api("/api/data", {
                        action: "save",
                        table: "clients",
                        id: c.id,
                        data: { ...c, active: c.active === false },
                      });
                      await load();
                    } catch (e) {
                      setToast((e as Error).message);
                    }
                  }}
                >
                  {c.active === false ? "Ativar" : "Inativar"}
                </button>
              </>
            )}
            <a
              className="secondary"
              target="_blank"
              rel="noreferrer"
              href={`https://wa.me/55${String(c.whatsapp || c.phone).replace(/\D/g, "")}`}
            >
              WhatsApp
            </a>
          </div>
        </section>
        <h2>Histórico completo</h2>
        <div className="panel">
          {history.map(appointmentRow)}
          {!history.length && <Empty title="Sem histórico" />}
        </div>
      </>
    ) : (
      <Empty title="Cliente não encontrado" />
    );
  } else if (section === "clientes") {
    const clients = data.entities.clients.filter(
      (c) =>
        (clientTab === "Todos" ||
          (clientTab === "Favoritos" && c.favorite) ||
          (clientTab === "Ativos" && c.active !== false) ||
          (clientTab === "Inativos" && c.active === false)) &&
        `${c.name} ${c.phone} ${c.email}`
          .toLowerCase()
          .includes(search.toLowerCase()),
    );
    content = (
      <>
        <Heading
          title="Clientes"
          subtitle="Gerencie seus clientes e histórico de atendimentos."
        />
        <div className="toolbar">
          <label className="input-icon">
            <Icons.Search />
            <input
              aria-label="Buscar cliente"
              placeholder="Buscar cliente por nome, telefone ou e-mail…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </label>
          {admin && (
            <button className="primary" onClick={() => openNew("clients")}>
              <Icons.Plus />
              Novo
            </button>
          )}
        </div>
        <div className="tabs">
          {["Todos", "Ativos", "Inativos", "Favoritos"].map((t) => (
            <button
              className={t === clientTab ? "selected" : ""}
              key={t}
              onClick={() => setClientTab(t)}
            >
              {t} (
              {
                data.entities.clients.filter(
                  (c) =>
                    t === "Todos" ||
                    (t === "Ativos" && c.active !== false) ||
                    (t === "Inativos" && c.active === false) ||
                    (t === "Favoritos" && c.favorite),
                ).length
              }
              )
            </button>
          ))}
        </div>
        <div className="client-list">
          {clients.slice(0, 100).map((c) => {
            const history = all.filter(
                (a) => a.client_id === c.id && a.status === "concluído",
              ),
              last = history[0];
            return (
              <Link
                href={`/app/clientes/${c.id}`}
                className="client-card"
                key={c.id}
              >
                <div className="avatar-wrap">
                  <Avatar name={c.name} photo={c.photo} />
                  {Boolean(c.favorite) && (
                    <Icons.Star size={15} className="favorite" />
                  )}
                </div>
                <div className="client-info">
                  <strong>{c.name}</strong>
                  <span>
                    <Icons.Phone size={14} />
                    {String(c.phone)}
                  </span>
                  <small>
                    <Icons.Mail size={14} />
                    {String(c.email || "Sem e-mail")}
                  </small>
                </div>
                <div className="visit-count">
                  <b>{history.length}</b>
                  <small>visitas</small>
                </div>
                <div className="last-visit">
                  <small>Último atendimento</small>
                  <b>{last ? dayLabel(last.date) : "Ainda não realizado"}</b>
                  <small>{last?.data.serviceNames.join(" + ") || "—"}</small>
                </div>
                <Icons.ChevronRight size={16} />
              </Link>
            );
          })}
          {!clients.length && (
            <Empty
              title="Nenhum cliente encontrado"
              text="Cadastre um cliente para começar."
            />
          )}
          {clients.length > 100 && (
            <p>Mostrando 100 resultados. Use a busca para refinar.</p>
          )}
        </div>
      </>
    );
  } else if (entityTable) {
    const titles: Record<string, string> = {
      profissionais: "Profissionais",
      servicos: "Serviços",
      bloqueios: "Bloqueios de agenda",
      feriados: "Feriados e dias fechados",
    };
    content = (
      <>
        <Heading
          title={titles[section]}
          subtitle="Organize o atendimento da sua barbearia."
        >
          {admin && (
            <button className="primary" onClick={() => openNew(entityTable)}>
              <Icons.Plus />
              Adicionar
            </button>
          )}
        </Heading>
        <div className="entity-grid">
          {data.entities[entityTable].map((r) => (
            <article className="panel entity-card" key={r.id}>
              {entityTable === "professionals" ? (
                <Avatar name={r.name} photo={r.photo} size="big" />
              ) : (
                <Icons.Scissors className="red-text" size={25} />
              )}
              <h2>{r.name}</h2>
              {entityTable === "services" && (
                <>
                  <strong className="price">{money(Number(r.price))}</strong>
                  <p>
                    {String(r.duration)} min · {String(r.category || "Serviço")}
                  </p>
                  <small>{String(r.description || "")}</small>
                </>
              )}
              {entityTable === "professionals" && (
                <>
                  <p>{String(r.specialty)}</p>
                  <p>
                    {
                      all.filter(
                        (a) => a.professional_id === r.id && a.date === today(),
                      ).length
                    }{" "}
                    agendamentos hoje
                  </p>
                  <small>Comissão: {String(r.commission || 0)}%</small>
                </>
              )}
              {r.date ? (
                <p>
                  {dayLabel(String(r.date))}{" "}
                  {r.start !== undefined
                    ? `${time(Number(r.start))} — ${time(Number(r.end))}`
                    : ""}
                </p>
              ) : null}
              {["professionals", "services"].includes(entityTable) && (
                <span
                  className={`badge ${r.active === false ? "gray" : "green"}`}
                >
                  {r.active === false ? "Inativo" : "Ativo"}
                </span>
              )}
              {admin && (
                <div className="actions">
                  <button
                    className="secondary"
                    onClick={() => openNew(entityTable, r)}
                  >
                    <Icons.Pencil size={16} />
                    Editar
                  </button>
                  {entityTable === "professionals" && (
                    <Link
                      href={`/app/horarios?professional=${r.id}`}
                      className="secondary"
                    >
                      Horários
                    </Link>
                  )}
                </div>
              )}
            </article>
          ))}
          {!data.entities[entityTable].length && (
            <Empty title="Nenhum registro cadastrado" />
          )}
        </div>
      </>
    );
  } else if (section === "perfil") {
    const month = all.filter((a) => a.date.startsWith(today().slice(0, 7))),
      monthly = month
        .filter((a) => a.status === "concluído")
        .reduce((s, a) => s + (a.data.total ?? a.data.price), 0),
      reviews = data.entities.reviews;
    content = (
      <>
        <Heading title="Perfil" subtitle="Gerencie sua conta e preferências." />
        <section className="panel profile-card">
          <Avatar name={data.user.name} size="huge" />
          <div>
            <h2>{data.user.name}</h2>
            <p className="red-text">
              {admin ? "Administrador" : "Profissional"}
            </p>
            <p>
              <Icons.Store size={16} />
              {data.shop.name}
            </p>
            <div className="contact-grid">
              <span>
                <Icons.Mail />
                {data.user.email}
              </span>
              <span>
                <Icons.Phone />
                {data.user.phone || "Telefone não informado"}
              </span>
            </div>
          </div>
          <Link href="/app/assinatura" className="plan-badge">
            <Icons.Crown />
            Plano {String(data.entities.subscriptions[0]?.name || "FREE")}
          </Link>
        </section>
        <div className="metrics">
          <Metric
            label="Agendamentos no mês"
            value={month.length}
            icon={Icons.CalendarDays}
            onClick={() => goto("agenda")}
          />
          <Metric
            label="Clientes cadastrados"
            value={data.entities.clients.length}
            icon={Icons.Users}
            onClick={() => goto("clientes")}
          />
          <Metric
            label="Faturamento do mês"
            value={money(monthly)}
            icon={Icons.ChartNoAxesCombined}
            onClick={() => goto("relatorios")}
          />
          <Metric
            label="Avaliação média"
            value={
              reviews.length
                ? (
                    reviews.reduce((s, x) => s + Number(x.rating), 0) /
                    reviews.length
                  ).toFixed(1)
                : "—"
            }
            icon={Icons.Star}
            onClick={() => goto("avaliacoes")}
          />
        </div>
        <h2>Conta</h2>
        <div className="account-menu">
          {menu
            .filter(
              (x) => admin || ["editar-perfil", "seguranca"].includes(x[0]),
            )
            .map(([route, label, sub, Icon]) => (
              <Link key={route} href={"/app/" + route}>
                <Icon />
                <span>
                  <strong>{label}</strong>
                  <small>{sub}</small>
                </span>
                <Icons.ChevronRight size={19} />
              </Link>
            ))}
          <button
            className="logout"
            onClick={async () => {
              await api("/api/auth", { action: "logout" });
              window.location.assign("/login");
            }}
          >
            <Icons.LogOut />
            <span>
              <strong>Sair da conta</strong>
              <small>Encerrar sessão neste dispositivo</small>
            </span>
            <Icons.ChevronRight />
          </button>
        </div>
        {data.shop.data.goal ? (
          <section className="panel">
            <h2>Meta mensal</h2>
            <p>
              {money(monthly)} / {money(Number(data.shop.data.goal))}
            </p>
            <progress max={Number(data.shop.data.goal)} value={monthly} />
          </section>
        ) : null}
      </>
    );
  } else if (!admin && !["seguranca", "editar-perfil"].includes(section))
    content = (
      <Empty
        title="Acesso restrito"
        text="Esta área está disponível para o administrador da barbearia."
      />
    );
  else if (["relatorios","comissoes","ocupacao","espera","reativar","equipe"].includes(section) && !hasPro(data.subscription)) content=<PlanUpgrade/>;
  else if(section === "assinatura") content=<SubscriptionPage data={data} onSaved={load}/>;
  else if(section === "reativar") content=<RetentionPage data={data}/>;
  else if (
    section === "relatorios" ||
    section === "comissoes" ||
    section === "ocupacao"
  )
    content = (
      <>
        {section === "ocupacao" && (
          <section className="panel">
            <h2>Hoje: {occupancy}% de ocupação</h2>
            <p>
              {hours(occupied)} ocupadas · {hours(minutes - occupied)} livres · {activePros.length} {activePros.length === 1 ? "profissional" : "profissionais"}
            </p>
            <progress max={100} value={occupancy} />
          </section>
        )}
        <Reports
          data={data}
          commission={section === "comissoes"}
          occupancy={section === "ocupacao"}
        />
      </>
    );
  else if (section === "horarios")
    content = (
      <HoursPage
        data={data}
        onSaved={load}
        professional={params.get("professional") || undefined}
      />
    );
  else if (section === "seguranca") content = <SecurityPage />;
  else if (section === "link") content = <LinkPage data={data} />;
  else
    content = (
      <SettingsPage
        data={data}
        section={section}
        onSaved={load}
        onNew={openNew}
      />
    );
  return (
    <div className="app-shell" onClickCapture={(event) => {
      if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      const link = (event.target as HTMLElement).closest<HTMLAnchorElement>("a[href]");
      if (!link || link.target || link.hasAttribute("download")) return;
      const url = new URL(link.href, window.location.origin);
      if (url.origin !== window.location.origin || (url.pathname !== "/app" && !url.pathname.startsWith("/app/"))) return;
      // All dashboard screens share this mounted shell and its authenticated data.
      // Native history integrates with Next's pathname/search hooks and Back/Forward.
      event.preventDefault();
      navigate(url.pathname + url.search + url.hash);
    }}>
      <aside className="desktop-sidebar">
        <Link href="/app">
          <Logo />
        </Link>
        <div className="shop-caption">
          <small>SUA BARBEARIA</small>
          <strong>{data.shop.name}</strong>
        </div>
        <nav>
          {nav.map(([key, label, Icon, url]) => (
            <Link
              className={section === key ? "active" : ""}
              key={key}
              href={url}
            >
              <Icon />
              {label}
            </Link>
          ))}
        </nav>
        {admin && (
          <div className="side-secondary">
            <Link href="/app/relatorios">
              <Icons.ChartNoAxesCombined />
              Relatórios
            </Link>
            <Link href="/app/link">
              <Icons.Link2 />
              Link de agendamento
            </Link>
            <Link href="/app/configuracoes">
              <Icons.Settings />
              Configurações
            </Link>
          </div>
        )}
        <div className="side-footer">
          <span className="online-dot" />
          {data.mode}
          <small>HAIRCUT · Gestão de barbearias</small>
        </div>
      </aside>
      <div className="app-content">
        <header className="app-header">
          <Link className="mobile-logo" href="/app">
            <Logo />
          </Link>
          <span className="desktop-breadcrumb">
            {data.shop.name} <span>/</span>{" "}
            {nav.find((x) => x[0] === section)?.[1] || "Gestão"}
          </span>
          <div className="header-actions">
            <Link
              className="icon notification-button"
              href="/app/notificacoes"
              aria-label="Notificações"
            >
              <Icons.Bell />
              {data.entities.notifications.some((x) => !x.read) && <i />}
            </Link>
            <Link href="/app/perfil" aria-label="Meu perfil">
              <Avatar name={data.user.name} />
            </Link>
          </div>
        </header>
        <main className="workspace screen-enter" key={section + (recordId || "")}>{content}</main>
        <footer className="bottom-nav">
          {nav.map(([key, label, Icon, url]) => (
            <Link
              className={section === key ? "active" : ""}
              key={key}
              href={url}
            >
              <Icon />
              <span>{label}</span>
            </Link>
          ))}
        </footer>
      </div>
      {dialog?.kind === "booking" && (
        <Modal title="Novo agendamento" wide onClose={() => setDialog(null)}>
          <Booking
            data={data}
            internal
            initialClient={dialog.clientId}
            onDone={async () => {
              await saved();
              goto("agenda");
            }}
          />
        </Modal>
      )}
      {dialog?.kind === "appointment" &&
        all.find((a) => a.id === dialog.id) && (
          <Modal
            title="Detalhes do agendamento"
            onClose={() => setDialog(null)}
          >
            <AppointmentDetail
              a={all.find((a) => a.id === dialog.id)!}
              data={data}
              onSaved={saved}
            />
          </Modal>
        )}
      {dialog?.kind === "entity" && (
        <Modal
          title={dialog.record ? "Editar cadastro" : "Novo cadastro"}
          onClose={() => setDialog(null)}
        >
          <EntityForm
            table={dialog.table}
            record={dialog.record}
            snapshot={data}
            onSaved={saved}
            onDelete={(id) =>
              setDialog({ kind: "delete", table: dialog.table, id })
            }
          />
        </Modal>
      )}
      {dialog?.kind === "delete" && (
        <Modal title="Excluir registro?" onClose={() => setDialog(null)}>
          <p>
            Esta ação é definitiva. Cadastros com histórico devem ser
            inativados.
          </p>
          <div className="actions">
            <button className="secondary" onClick={() => setDialog(null)}>
              Voltar
            </button>
            <button className="danger" disabled={busy} aria-busy={busy} onClick={remove}>
              Confirmar exclusão
            </button>
          </div>
        </Modal>
      )}
      {toast && (
        <div role="status" className="toast">
          {toast}
          <button onClick={() => setToast("")} aria-label="Fechar mensagem">
            <Icons.X size={18} />
          </button>
        </div>
      )}
    </div>
  );
}
