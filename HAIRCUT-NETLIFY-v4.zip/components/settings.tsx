"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import QRCode from "qrcode";
import {
  type Snapshot,
  type Entity,
  type EntityName,
  time,
  minute,
} from "@/lib/types";
import { api, Empty, Field, Heading, Icons, Notice } from "./ui";
import { ImageUpload } from "./image-upload";
export function SettingsPage({
  data,
  section,
  onSaved,
  onNew,
}: {
  data: Snapshot;
  section: string;
  onSaved: () => Promise<void>;
  onNew: (table: EntityName, record?: Entity) => void;
}) {
  const [message, setMessage] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  async function run(url: string, body: unknown) {
    setBusy(true);
    setError("");
    try {
      const r = await api<{ message?: string; userId?: string }>(url, body);
      setMessage(
        (r.message || "Salvo com sucesso.") +
          (r.userId ? ` ID do membro: ${r.userId}` : ""),
      );
      await onSaved();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const title: Record<string, string> = {
    configuracoes: "Configurações adicionais",
    barbearia: "Minha barbearia",
    pagina: "Personalizar página",
    notificacoes: "Notificações",
    assinatura: "Meu plano",
    "editar-perfil": "Editar perfil",
    avaliacoes: "Avaliações",
    espera: "Lista de espera",
    equipe: "Acesso da equipe",
    suporte: "Suporte",
  };
  let body: React.ReactNode;
  if (section === "barbearia" || section === "pagina")
    body = (
      <form
        className="panel form-grid"
        onSubmit={(e) => {
          e.preventDefault();
          const f = Object.fromEntries(new FormData(e.currentTarget));
          run("/api/data", {
            action: "shop",
            name: f.name,
            data: {
              ...f,
              notice: Number(f.notice),
              buffer: Number(f.buffer),
              goal: Math.round(Number(f.goal) * 100),
            },
          });
        }}
      >
        {[
          ["name", "Nome da barbearia", data.shop.name],
          ["phone", "Telefone", data.shop.data.phone],
          ["whatsapp", "WhatsApp", data.shop.data.whatsapp],
          ["address", "Endereço", data.shop.data.address],
          ["instagram", "Instagram", data.shop.data.instagram],
        ].map(([n, l, v]) => (
          <Field key={String(n)} label={String(l)}>
            <input
              name={String(n)}
              defaultValue={String(v || "")}
              required={n === "name"}
              type="text"
            />
          </Field>
        ))}
        <ImageUpload name="logo" label="Logo da barbearia" kind="logo" value={String(data.shop.data.logo || "")} />
        <ImageUpload name="banner" label="Foto de capa" kind="banner" value={String(data.shop.data.banner || "")} />
        <Field label="Descrição">
          <textarea
            name="description"
            defaultValue={String(data.shop.data.description || "")}
          />
        </Field>
        <Field label="Cor principal">
          <input
            name="color"
            type="color"
            defaultValue={String(data.shop.data.color || "#ff1426")}
          />
        </Field>
        <Field label="Antecedência mínima (min)">
          <input
            name="notice"
            type="number"
            min="0"
            max="10080"
            defaultValue={Number(data.shop.data.notice || 0)}
          />
        </Field>
        <Field label="Intervalo entre atendimentos (min)">
          <input
            name="buffer"
            type="number"
            min="0"
            max="120"
            defaultValue={Number(data.shop.data.buffer || 0)}
          />
        </Field>
        <Field label="Meta mensal (R$)">
          <input
            name="goal"
            type="number"
            min="0"
            step="0.01"
            defaultValue={Number(data.shop.data.goal || 0) / 100}
          />
        </Field>
        <p className="muted span-2">
          Fuso horário: Brasília (America/Sao_Paulo). As imagens são ajustadas automaticamente para carregar rápido.
        </p>
        <div className="actions span-2">
          <Link
            className="secondary"
            href={`/agendar/${data.shop.slug}`}
            target="_blank"
          >
            Visualizar página
            <Icons.ExternalLink size={15} />
          </Link>
          <button className="primary" disabled={busy} aria-busy={busy}>
            Salvar alterações
          </button>
        </div>
      </form>
    );
  else if (section === "editar-perfil")
    body = (
      <form
        className="panel"
        onSubmit={(e) => {
          e.preventDefault();
          run("/api/auth", {
            action: "profile",
            ...Object.fromEntries(new FormData(e.currentTarget)),
          });
        }}
      >
        <Field label="Nome">
          <input name="name" defaultValue={data.user.name} required />
        </Field>
        <Field label="Telefone">
          <input name="phone" defaultValue={data.user.phone} />
        </Field>
        <Field label="E-mail da conta">
          <input value={data.user.email} readOnly />
        </Field>
        <button className="primary" disabled={busy} aria-busy={busy}>
          Salvar alterações
        </button>
      </form>
    );
  else if (section === "notificacoes") {
    const prefs = data.entities.public_page_settings[0];
    body = (
      <>
        <section className="panel">
          <h2>Central de notificações</h2>
          {data.entities.notifications.map((n) => (
            <div className="notification-row" key={n.id}>
              <Icons.Bell className={!n.read ? "red-text" : ""} />
              <div>
                <strong>{n.name}</strong>
                <small>{new Date(n.created_at).toLocaleString("pt-BR")}</small>
              </div>
              {!n.read && (
                <button
                  className="secondary"
                  disabled={busy} aria-busy={busy}
                  onClick={() =>
                    run("/api/data", {
                      action: "save",
                      table: "notifications",
                      id: n.id,
                      data: {
                        name: n.name,
                        read: true,
                        appointmentId: n.appointmentId,
                      },
                    })
                  }
                >
                  Marcar lida
                </button>
              )}
            </div>
          ))}
          {!data.entities.notifications.length && <Empty title="Tudo em dia" />}
        </section>
        <form
          className="panel"
          onSubmit={(e) => {
            e.preventDefault();
            const f = new FormData(e.currentTarget);
            run("/api/data", {
              action: "save",
              table: "public_page_settings",
              id: prefs?.id,
              data: {
                name: "Preferências de notificação",
                events: f.getAll("events"),
                reminders: f.getAll("reminders").map(Number),
              },
            });
          }}
        >
          <h2>Preferências</h2>
          {[
            "novo agendamento",
            "cancelamento",
            "remarcação",
            "confirmação",
            "atendimento",
            "avaliação",
          ].map((x) => (
            <label className="check" key={x}>
              <input
                type="checkbox"
                name="events"
                value={x}
                defaultChecked={
                  !prefs || ((prefs.events || []) as string[]).includes(x)
                }
              />
              {x}
            </label>
          ))}
          <h3>Lembretes ao cliente</h3>
          {[1440, 120, 60, 30].map((n) => (
            <label className="check" key={n}>
              <input
                type="checkbox"
                name="reminders"
                value={n}
                defaultChecked={((prefs?.reminders || []) as number[]).includes(
                  n,
                )}
              />
              {n === 1440
                ? "24 horas"
                : n === 120
                  ? "2 horas"
                  : n === 60
                    ? "1 hora"
                    : "30 minutos"}{" "}
              antes
            </label>
          ))}
          <Notice text="Preferências são salvas. O envio automático por WhatsApp/e-mail depende da configuração de um provedor e do serviço de lembretes." />
          <button className="primary" disabled={busy} aria-busy={busy}>
            Salvar preferências
          </button>
        </form>
      </>
    );
  } else if (section === "avaliacoes")
    body = (
      <section className="panel">
        {data.entities.reviews.map((r) => (
          <article className="review" key={r.id}>
            <span className="amber-text">
              {"★".repeat(Number(r.rating))}
              {"☆".repeat(5 - Number(r.rating))}
            </span>
            <p>{String(r.comment || "Sem comentário")}</p>
            <small>{new Date(r.created_at).toLocaleDateString("pt-BR")}</small>
          </article>
        ))}
        {!data.entities.reviews.length && (
          <Empty
            title="Nenhuma avaliação ainda"
            text="O cliente poderá avaliar pelo link do agendamento após concluir o atendimento."
          />
        )}
      </section>
    );
  else if (section === "espera")
    body = (
      <section className="panel">
        {data.entities.waitlist.map((r) => (
          <div className="report-row" key={r.id}>
            <strong>{r.name}</strong>
            <span>
              {String(r.date)} · {String(r.period)}
            </span>
            <a
              className="secondary"
              href={`https://wa.me/55${String(r.phone).replace(/\D/g, "")}`}
              target="_blank"
              rel="noreferrer"
            >
              WhatsApp
            </a>
          </div>
        ))}
        {!data.entities.waitlist.length && (
          <Empty title="Nenhum cliente na lista de espera" />
        )}
      </section>
    );
  else if (section === "equipe")
    body = (
      <form
        className="panel"
        onSubmit={(e) => {
          e.preventDefault();
          run("/api/data", {
            action: "member",
            ...Object.fromEntries(new FormData(e.currentTarget)),
          });
        }}
      >
        <h2>Adicionar membro</h2>
        <p className="muted">
          O profissional deve criar uma conta e aguardar nesta etapa, sem
          cadastrar uma nova barbearia. Depois, vincule o ID recebido no
          cadastro do profissional.
        </p>
        <Field label="E-mail da conta">
          <input name="email" type="email" required />
        </Field>
        <Field label="Acesso">
          <select name="role">
            <option value="PROFESSIONAL">
              Profissional — somente seus atendimentos
            </option>
            <option value="ADMIN">Administrador — gestão completa</option>
          </select>
        </Field>
        <button className="primary" disabled={busy} aria-busy={busy}>
          Adicionar membro
        </button>
      </form>
    );
  else if (section === "suporte")
    body = (
      <>
        <button className="primary" onClick={() => onNew("support_tickets")}>
          <Icons.Plus />
          Abrir ticket
        </button>
        <section className="panel">
          {data.entities.support_tickets.map((t) => (
            <div className="report-row" key={t.id}>
              <strong>{t.name}</strong>
              <span>{String(t.status)}</span>
              <p>{String(t.message)}</p>
            </div>
          ))}
          {!data.entities.support_tickets.length && (
            <Empty
              title="Nenhum ticket aberto"
              text="As solicitações ficam disponíveis para o administrador HAIRCUT nesta instalação."
            />
          )}
        </section>
      </>
    );
  else
    body = (
      <div className="account-menu">
        {[
          ["barbearia", "Dados da barbearia"],
          ["profissionais", "Profissionais"],
          ["servicos", "Serviços"],
          ["equipe", "Acesso da equipe"],
          ["horarios", "Horários e pausas"],
          ["bloqueios", "Bloquear agenda"],
          ["feriados", "Feriados e dias fechados"],
          ["pagina", "Personalizar página pública"],
          ["link", "Link e QR Code"],
          ["espera", "Lista de espera"],
          ["relatorios", "Relatórios"],
          ["comissoes", "Comissões · Pro"],
          ["reativar", "Clientes a recuperar · Pro"],
          ["avaliacoes", "Avaliações"],
          ["notificacoes", "Notificações"],
          ["assinatura", "Assinatura"],
          ["seguranca", "Segurança"],
          ["suporte", "Suporte"],
        ].map(([p, l]) => (
          <Link key={p} href={"/app/" + p}>
            <Icons.Settings />
            <span>
              <strong>{l}</strong>
            </span>
            <Icons.ChevronRight />
          </Link>
        ))}
        {data.user.master && (
          <Link href="/master">
            <Icons.Shield />
            <span>Administração HAIRCUT</span>
            <Icons.ChevronRight />
          </Link>
        )}
      </div>
    );
  return (
    <>
      <Heading
        title={title[section] || "Configurações"}
        subtitle="Tudo do seu jeito, em um só lugar."
      />
      <Notice text={error} error />
      <Notice text={message} />
      {body}
    </>
  );
}
export function HoursPage({
  data,
  onSaved,
  professional,
}: {
  data: Snapshot;
  onSaved: () => Promise<void>;
  professional?: string;
}) {
  const [pro, setPro] = useState(professional || ""),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false);
  const names = [
    "Domingo",
    "Segunda",
    "Terça",
    "Quarta",
    "Quinta",
    "Sexta",
    "Sábado",
  ];
  async function submit(
    e: React.FormEvent<HTMLFormElement>,
    weekday: number,
    existing?: Entity,
  ) {
    e.preventDefault();
    setBusy(true);
    const f = Object.fromEntries(new FormData(e.currentTarget));
    try {
      await api("/api/data", {
        action: "save",
        table: pro ? "professional_hours" : "business_hours",
        id: existing?.id,
        data: {
          weekday,
          professionalId: pro || undefined,
          start: minute(String(f.start)),
          end: minute(String(f.end)),
          closed: f.closed === "on",
          breaks:
            f.breakStart && f.breakEnd
              ? [
                  {
                    start: minute(String(f.breakStart)),
                    end: minute(String(f.breakEnd)),
                  },
                ]
              : [],
        },
      });
      await onSaved();
      setMessage("Horário salvo.");
    } catch (e) {
      setMessage((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <Heading
        title="Horários de atendimento"
        subtitle="Configure a semana, folgas e intervalos."
      />
      <Field label="Agenda">
        <select value={pro} onChange={(e) => setPro(e.target.value)}>
          <option value="">Horário da barbearia</option>
          {data.entities.professionals.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name}
            </option>
          ))}
        </select>
      </Field>
      <Notice text={message} />
      {pro && (
        <p className="muted">
          Sem horário próprio, o profissional segue o horário da barbearia. A
          disponibilidade usa a interseção dos dois horários.
        </p>
      )}
      <div className="hours-list">
        {names.map((name, weekday) => {
          const record = (
            pro
              ? data.entities.professional_hours
              : data.entities.business_hours
          ).find(
            (h) => h.weekday === weekday && (!pro || h.professionalId === pro),
          );
          const b = (
            record?.breaks as { start: number; end: number }[] | undefined
          )?.[0];
          return (
            <form
              className="panel hours-row"
              key={`${pro}-${weekday}-${record?.updated_at}`}
              onSubmit={(e) => submit(e, weekday, record)}
            >
              <strong>{name}</strong>
              <label className="check">
                <input
                  name="closed"
                  type="checkbox"
                  defaultChecked={Boolean(record?.closed)}
                />
                Fechado / folga
              </label>
              <Field label="Início">
                <input
                  name="start"
                  type="time"
                  defaultValue={time(Number(record?.start ?? 540))}
                  required
                />
              </Field>
              <Field label="Fim">
                <input
                  name="end"
                  type="time"
                  defaultValue={time(Number(record?.end ?? 1140))}
                  required
                />
              </Field>
              <Field label="Pausa: início">
                <input
                  name="breakStart"
                  type="time"
                  defaultValue={b ? time(b.start) : ""}
                />
              </Field>
              <Field label="Pausa: fim">
                <input
                  name="breakEnd"
                  type="time"
                  defaultValue={b ? time(b.end) : ""}
                />
              </Field>
              <button className="secondary" disabled={busy} aria-busy={busy}>
                Salvar
              </button>
            </form>
          );
        })}
      </div>
    </>
  );
}
export function LinkPage({ data }: { data: Snapshot }) {
  const [url, setUrl] = useState(""),
    [qr, setQr] = useState(""),
    [message, setMessage] = useState("");
  useEffect(() => {
    const u = data.publicBookingUrl || window.location.origin + "/agendar/" + data.shop.slug;
    setUrl(u);
    QRCode.toDataURL(u, {
      width: 260,
      margin: 2,
      errorCorrectionLevel: "M",
    }).then(setQr);
  }, [data.shop.slug, data.publicBookingUrl]);
  async function copy() {
    try {
      await navigator.clipboard.writeText(url);
      setMessage("Link copiado!");
    } catch {
      setMessage("Selecione e copie o link acima.");
    }
  }
  return (
    <>
      <Heading
        title="Link de agendamento"
        subtitle="Sua barbearia disponível a qualquer hora."
      />
      <section className="panel share-panel">
        {qr && (
          <img
            width={220}
            height={220}
            src={qr}
            alt="QR Code da página pública de agendamento"
          />
        )}
        <h2>{data.shop.name}</h2>
        <p>O endereço é criado a partir do nome da barbearia. Ao alterar o nome, os links anteriores continuam funcionando.</p>
        <input
          readOnly
          value={url}
          aria-label="Link público"
          onFocus={(e) => e.target.select()}
        />
        <div className="actions wrap">
          <button className="primary" onClick={copy}>
            <Icons.Copy size={17} />
            Copiar link
          </button>
          <button
            className="secondary"
            onClick={async () => {
              try {
                if (navigator.share)
                  await navigator.share({ title: data.shop.name, url });
                else await copy();
              } catch {
                setMessage("Compartilhamento cancelado.");
              }
            }}
          >
            <Icons.Share2 size={17} />
            Compartilhar
          </button>
          <a
            className="secondary"
            href={`https://wa.me/?text=${encodeURIComponent("Agende seu horário: " + url)}`}
            target="_blank"
            rel="noreferrer"
          >
            WhatsApp
          </a>
          <button
            className="secondary"
            onClick={async () => {
              await copy();
              setMessage("Cole o link na bio ou nos stories do Instagram.");
            }}
          >
            Instagram
          </button>
          <a className="secondary" href={qr} download="haircut-qrcode.png">
            Baixar QR Code
          </a>
          <Link
            className="secondary"
            href={"/agendar/" + data.shop.slug}
            target="_blank"
          >
            Visualizar página
          </Link>
        </div>
        <Notice text={message} />
      </section>
    </>
  );
}
export function SecurityPage() {
  const [message, setMessage] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [sessions, setSessions] = useState<
      { id: string; agent: string; created_at: string }[]
    >([]),
    [remote, setRemote] = useState(false),
    [mfa, setMfa] = useState<{
      id: string;
      totp: { qr_code: string; secret: string };
    } | null>(null);
  useEffect(() => {
    api<{ remote?: boolean; sessions: typeof sessions }>("/api/data?sessions=1")
      .then((r) => {
        setSessions(r.sessions);
        setRemote(Boolean(r.remote));
      })
      .catch((e) => setError(e.message));
  }, []);
  async function password(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.currentTarget));
    if (f.password !== f.confirm) {
      setError("As senhas precisam ser iguais.");
      return;
    }
    setBusy(true);
    try {
      await api("/api/auth", { ...f, action: "password" });
      setMessage("Senha alterada com sucesso.");
      setError("");
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <Heading title="Segurança" subtitle="Proteja o acesso à sua barbearia." />
      <Notice text={error} error />
      <Notice text={message} />
      <form className="panel form-grid" onSubmit={password}>
        <h2 className="span-2">Alterar senha</h2>
        <Field label="Senha atual">
          <input
            name="current"
            type="password"
            autoComplete="current-password"
            required={!remote}
          />
        </Field>
        <Field label="Nova senha">
          <input
            name="password"
            type="password"
            minLength={10}
            maxLength={128}
            autoComplete="new-password"
            required
          />
        </Field>
        <Field label="Confirmar nova senha">
          <input
            name="confirm"
            type="password"
            minLength={10}
            autoComplete="new-password"
            required
          />
        </Field>
        <button className="primary" disabled={busy} aria-busy={busy}>
          Salvar nova senha
        </button>
      </form>
      <section className="panel">
        <h2>Verificação em duas etapas</h2>
        <p className="muted">
          Use um aplicativo autenticador com Supabase Auth.
        </p>
        <button
          className="secondary"
          onClick={async () => {
            try {
              setMfa(await api("/api/auth", { action: "mfa-enroll" }));
            } catch (e) {
              setError((e as Error).message);
            }
          }}
        >
          Configurar duas etapas
        </button>
        {mfa && (
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                await api("/api/auth", {
                  action: "mfa-verify",
                  factorId: mfa.id,
                  code: new FormData(e.currentTarget).get("code"),
                });
                setMessage("Duas etapas ativadas.");
                setMfa(null);
              } catch (e) {
                setError((e as Error).message);
              }
            }}
          >
            <p>
              Adicione a chave ao autenticador: <code>{mfa.totp.secret}</code>
            </p>
            <Field label="Código do autenticador">
              <input
                name="code"
                inputMode="numeric"
                pattern="[0-9]{6}"
                required
              />
            </Field>
            <button className="primary">Verificar e ativar</button>
          </form>
        )}
      </section>
      <section className="panel">
        <h2>Dispositivos conectados</h2>
        {sessions.map((s) => (
          <div className="report-row" key={s.id}>
            <span>{s.agent}</span>
            <small>{new Date(s.created_at).toLocaleString("pt-BR")}</small>
          </div>
        ))}
        {remote && (
          <p className="muted">
            Supabase administra as sessões. Você pode encerrar todas abaixo.
          </p>
        )}
        <button
          className="danger"
          onClick={async () => {
            try {
              await api("/api/auth", { action: "logout", all: true });
              window.location.assign("/login");
            } catch (e) {
              setError((e as Error).message);
            }
          }}
        >
          Encerrar todas as sessões
        </button>
      </section>
      <section className="panel">
        <h2>Login com Google</h2>
        <p>A integração depende do provedor Google configurado no Supabase.</p>
        <button
          className="secondary"
          onClick={async () => {
            try {
              const r = await api<{ redirect: string }>("/api/auth", {
                action: "google",
              });
              window.location.assign(r.redirect);
            } catch (e) {
              setError((e as Error).message);
            }
          }}
        >
          Continuar com Google
        </button>
      </section>
    </>
  );
}
