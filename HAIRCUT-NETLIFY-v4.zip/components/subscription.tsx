"use client";
import { useState } from "react";
import Link from "next/link";
import { PLANS, activeSubscription, type PlanId } from "@/lib/plans";
import { money, type Snapshot } from "@/lib/types";
import { api, Heading, Icons, Notice } from "./ui";

export function PlanUpgrade() {
  return <section className="panel upgrade-panel"><Icons.Crown size={40}/><h2>Mais possibilidades com o Pro</h2><p>Relatórios completos, comissões, lista de espera, profissionais ilimitados e clientes a recuperar por {money(PLANS.pro.price)}/mês.</p><Link className="primary" href="/app/assinatura">Conhecer os planos</Link></section>;
}
export function SubscriptionPage({data,onSaved}:{data:Snapshot;onSaved:()=>Promise<void>}) {
  const [busy,setBusy]=useState(false), [message,setMessage]=useState(""), [error,setError]=useState("");
  const sub=data.subscription, active=activeSubscription(sub);
  async function change(operation:string,planId?:PlanId) {
    setBusy(true);setError("");setMessage("");
    try { const result=await api<{message:string}>("/api/data",{action:"subscription",operation,planId});await onSaved();setMessage(result.message); }
    catch(e){setError((e as Error).message);}finally{setBusy(false);}
  }
  return <>
    <Heading title="Planos e assinatura" subtitle="Escolha o plano para a sua barbearia."/>
    <Notice text={error} error/><Notice text={message}/>
    <section className="panel subscription"><Icons.Crown size={36}/><h2>{active ? `Plano ${PLANS[sub.planId].name}` : "Prepare sua barbearia"}</h2>
      <p>{active ? `Acesso liberado até ${new Date(sub.currentPeriodEnd!).toLocaleDateString("pt-BR")}.` : "O acesso básico de preparação permite configurar sua agenda e até 3 profissionais."}</p>
      {active && <strong className="price">{money(sub.price)}<small>/mês</small></strong>}
      {sub.requestedPlan && <p>Solicitação: <strong>{PLANS[sub.requestedPlan].name}</strong> · aguardando ativação.</p>}
      {sub.cancelAtPeriodEnd && <Notice text="Renovação cancelada. Você mantém o acesso até o fim do período atual."/>}
      <p>Pagamentos online em breve. Nenhuma cobrança automática está habilitada.</p>
      {active && <button className="secondary" disabled={busy} aria-busy={busy} onClick={()=>change(sub.cancelAtPeriodEnd?"resume":"cancel")}>{sub.cancelAtPeriodEnd?"Manter assinatura":"Cancelar renovação"}</button>}
      {!active && sub.requestedPlan && <button className="secondary" disabled={busy} onClick={()=>change("cancel")}>Cancelar solicitação</button>}
    </section>
    <div className="entity-grid plan-grid">{Object.values(PLANS).map(plan=><section className={`panel plan-card ${plan.id === "pro"?"plan-pro":""}`} key={plan.id}>
      {plan.id === "pro" && <span className="badge red">Para crescer</span>}<h2>{plan.name}</h2><strong className="price">{money(plan.price)}<small>/mês</small></strong>
      <ul>{plan.features.map(feature=><li key={feature}><Icons.Check size={16}/>{feature}</li>)}</ul>
      <button className={plan.id === "pro"?"primary full":"secondary full"} disabled={busy || sub.requestedPlan === plan.id || (active && sub.planId===plan.id && !sub.cancelAtPeriodEnd)} aria-busy={busy} onClick={()=>change("select",plan.id)}>{sub.requestedPlan===plan.id?"Solicitado":active && sub.planId===plan.id?"Plano atual":`Escolher ${plan.name}`}</button>
    </section>)}</div>
  </>;
}
