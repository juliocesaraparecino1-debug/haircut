"use client";
import { useEffect, useRef, type ReactNode } from "react";
import {
  X,
  Scissors,
  ChevronRight,
  CalendarDays,
  Clock,
  Check,
  Users,
  Wallet,
  Plus,
  Home,
  UserRound,
  Bell,
  Settings,
  Search,
  SlidersHorizontal,
  Star,
  ArrowUpRight,
  LogOut,
  Shield,
  Crown,
  Store,
  Link2,
  ChartNoAxesCombined,
  Phone,
  Mail,
  MapPin,
  Copy,
  Share2,
  ExternalLink,
  Trash2,
  Pencil,
  CheckCircle2,
  ArrowLeft,
  Zap,
} from "lucide-react";
import type { Status } from "@/lib/types";
import { statusColors } from "@/lib/types";
export const Icons = {
  X,
  Scissors,
  ChevronRight,
  CalendarDays,
  Clock,
  Check,
  Users,
  Wallet,
  Plus,
  Home,
  UserRound,
  Bell,
  Settings,
  Search,
  SlidersHorizontal,
  Star,
  ArrowUpRight,
  LogOut,
  Shield,
  Crown,
  Store,
  Link2,
  ChartNoAxesCombined,
  Phone,
  Mail,
  MapPin,
  Copy,
  Share2,
  ExternalLink,
  Trash2,
  Pencil,
  CheckCircle2,
  ArrowLeft,
  Zap,
};
export async function api<T = Record<string, unknown>>(
  url: string,
  data?: unknown,
): Promise<T> {
  const r = await fetch(
    url,
    data
      ? {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        }
      : { cache: "no-store" },
  );
  const result = await r.json();
  if (!r.ok) {
    if (r.status === 401 && url.startsWith("/api/data"))
      window.location.assign("/login");
    throw new Error(result.error || "Não foi possível concluir.");
  }
  return result;
}
export function Logo({ large = false }: { large?: boolean }) {
  return (
    <div
      className={`logo ${large ? "large" : ""}`}
      role="img"
      aria-label="HAIRCUT — Sistema de agendamento"
    />
  );
}
export function Avatar({
  name,
  photo,
  size = "",
}: {
  name?: string;
  photo?: unknown;
  size?: string;
}) {
  return (
    <span
      className={`avatar ${size}`}
      style={
        typeof photo === "string" && photo.startsWith("ref:")
          ? {
              backgroundImage: "url(/reference-clients.png)",
              backgroundSize: "560px auto",
              backgroundPosition: `-63px -${321 + Number(photo.slice(4)) * 76}px`,
            }
          : undefined
      }
    >
      {typeof photo === "string" && (/^https?:\/\//.test(photo) || photo.startsWith("data:image/")) ? (
        <img src={photo} alt="" loading="lazy" />
      ) : typeof photo === "string" && photo.startsWith("ref:") ? null : (
        name
          ?.split(" ")
          .map((x) => x[0])
          .slice(0, 2)
          .join("") || "HC"
      )}
    </span>
  );
}
export function Badge({ status }: { status: Status }) {
  return (
    <span className={`badge ${statusColors[status]}`}>
      {status === "confirmado" || status === "concluído" ? (
        <Check size={13} />
      ) : (
        <Clock size={13} />
      )}{" "}
      {status}
    </span>
  );
}
export function Empty({
  title = "Nenhum registro por aqui",
  text = "Os novos registros aparecerão nesta área.",
  children,
}: {
  title?: string;
  text?: string;
  children?: ReactNode;
}) {
  return (
    <div className="empty">
      <Scissors size={30} />
      <h3>{title}</h3>
      <p>{text}</p>
      {children}
    </div>
  );
}
export function Modal({
  title,
  onClose,
  children,
  wide = false,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  wide?: boolean;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const d = ref.current;
    d?.showModal();
    return () => d?.close();
  }, []);
  return (
    <dialog
      ref={ref}
      className={wide ? "wide" : ""}
      onCancel={onClose}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      aria-labelledby="dialog-title"
    >
      <header>
        <h2 id="dialog-title">{title}</h2>
        <button className="icon" aria-label="Fechar" onClick={onClose}>
          <X />
        </button>
      </header>
      {children}
    </dialog>
  );
}
export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="field">
      <span>{label}</span>
      {children}
    </label>
  );
}
export function Notice({
  text,
  error = false,
}: {
  text: string;
  error?: boolean;
}) {
  return text ? (
    <div
      role={error ? "alert" : "status"}
      className={`notice ${error ? "error" : ""}`}
    >
      {text}
    </div>
  ) : null;
}
export function Heading({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children?: ReactNode;
}) {
  return (
    <div className="page-heading">
      <div>
        <h1>{title}</h1>
        {subtitle && <p>{subtitle}</p>}
      </div>
      {children}
    </div>
  );
}
export function Metric({
  label,
  value,
  icon: Icon,
  tone = "red",
  onClick,
  detail,
}: {
  label: string;
  value: ReactNode;
  icon: typeof CalendarDays;
  tone?: string;
  onClick: () => void;
  detail?: string;
}) {
  return (
    <button className={`metric ${tone}`} onClick={onClick}>
      <span className="metric-icon">
        <Icon size={24} />
      </span>
      <span className="metric-text">
        <span className="muted">{label}</span>
        <strong>{value}</strong>
        {detail && <small>{detail}</small>}
      </span>
      <ChevronRight className="metric-chevron" size={15} />
    </button>
  );
}
