"use client";
import { useState } from "react";
import { api, Field, Logo, Notice } from "./ui";
export function MFAScreen() {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  return (
    <main className="auth-page">
      <section className="auth-card">
        <Logo large />
        <h1>Verificação em duas etapas</h1>
        <p>Digite o código do seu aplicativo autenticador.</p>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            try {
              const r = await api<{ redirect: string }>("/api/auth", {
                action: "mfa-login",
                code: new FormData(e.currentTarget).get("code"),
              });
              window.location.assign(r.redirect);
            } catch (e) {
              setError((e as Error).message);
            } finally {
              setBusy(false);
            }
          }}
        >
          <Field label="Código de 6 dígitos">
            <input
              name="code"
              inputMode="numeric"
              pattern="[0-9]{6}"
              autoComplete="one-time-code"
              required
            />
          </Field>
          <Notice text={error} error />
          <button className="primary full" disabled={busy} aria-busy={busy}>
            Verificar e entrar
          </button>
        </form>
      </section>
    </main>
  );
}
