"use client";
import { useState } from "react";

async function resizeImage(file: File, kind: "logo" | "banner") {
  if (!file.type.startsWith("image/")) throw new Error("Escolha uma imagem válida.");
  if (file.size > 12 * 1024 * 1024) throw new Error("A imagem deve ter no máximo 12 MB.");
  const bitmap = await createImageBitmap(file);
  const limit = kind === "logo" ? 600 : 1600;
  const scale = Math.min(1, limit / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  canvas.getContext("2d")!.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  const type = kind === "logo" ? "image/png" : "image/webp";
  const result = canvas.toDataURL(type, kind === "logo" ? undefined : 0.84);
  if (result.length > 2_500_000) throw new Error("A imagem ficou muito grande. Escolha outra com menos detalhes.");
  return result;
}

export function ImageUpload({ name, label, kind, value = "", onChange }: {
  name: string; label: string; kind: "logo" | "banner"; value?: string;
  onChange?: (value: string) => void;
}) {
  const [image, setImage] = useState(value), [error, setError] = useState("");
  async function choose(file?: File) {
    if (!file) return;
    setError("");
    try { const next = await resizeImage(file, kind); setImage(next); onChange?.(next); }
    catch (e) { setError((e as Error).message); }
  }
  return <div className="image-upload">
    <label>{label}</label>
    <input type="hidden" name={name} value={image} />
    <label className="upload-drop">
      {image ? <img src={image} alt={`Prévia de ${label.toLowerCase()}`} /> : <span>{kind === "logo" ? "Sua marca em PNG, JPG ou WebP" : "Uma foto horizontal da barbearia"}</span>}
      <strong>{image ? "Trocar imagem" : "Escolher imagem"}</strong>
      <input type="file" accept="image/png,image/jpeg,image/webp" onChange={e => choose(e.target.files?.[0])} />
    </label>
    {image && <button type="button" className="text-button" onClick={() => { setImage(""); onChange?.(""); }}>Remover</button>}
    {error && <small className="field-error">{error}</small>}
  </div>;
}
