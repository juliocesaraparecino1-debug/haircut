"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Eye, EyeOff, Mail, LockKeyhole, ArrowRight, ArrowLeft, Building2, Image as ImageIcon, Scissors, Clock3 } from "lucide-react";
import { api, Field, Logo, Notice } from "./ui";
import { ImageUpload } from "./image-upload";
export function AuthScreen({ screen }: { screen: string }) {
  const router=useRouter(),params=useSearchParams();
  const [error, setError] = useState(""),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false),
    [show, setShow] = useState(false);
  const signup = screen === "cadastro",
    recover = screen === "recuperar-senha",
    verify = screen === "verificar",
    reset = screen === "nova-senha";
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    setBusy(true);
    const d = Object.fromEntries(new FormData(e.currentTarget));
    if ((signup || reset) && d.password !== d.confirm) {
      setError("As senhas precisam ser iguais.");
      setBusy(false);
      return;
    }
    try {
      const r = await api<{ redirect?: string; message?: string }>(
        "/api/auth",
        {
          ...d,
          terms: d.terms === "on",
          recovery: d.recovery === "on",
          action: signup
            ? "signup"
            : recover
              ? "recover"
              : verify
                ? "verify"
                : reset
                  ? "password"
                  : "login",
        },
      );
      setMessage(r.message || "");
      if (r.redirect) { router.push(r.redirect); router.refresh(); }
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function google() {
    setBusy(true);
    try {
      const r = await api<{ redirect: string }>("/api/auth", {
        action: "google",
      });
      window.location.assign(r.redirect);
    } catch (e) {
      setError((e as Error).message);
      setBusy(false);
    }
  }
  return (
    <main className="auth-page">
      <section className="auth-card">
        <Logo large />
        {screen !== "login" && (
          <>
            <h1>
              {signup
                ? "Criar conta"
                : recover
                  ? "Recuperar acesso"
                  : verify
                    ? "Verifique sua conta"
                    : "Criar nova senha"}
            </h1>
            <p className="muted">
              {signup
                ? "Sua barbearia começa uma nova fase."
                : recover
                  ? "Enviaremos as instruções para seu e-mail."
                  : verify
                    ? "Abra o link enviado por e-mail ou informe o código."
                    : "Use uma senha segura com pelo menos 10 caracteres."}
            </p>
          </>
        )}
        <form onSubmit={submit}>
          {signup && (
            <>
              <Field label="Seu nome">
                <input name="name" autoComplete="name" required />
              </Field>
              <Field label="Telefone">
                <input name="phone" autoComplete="tel" type="tel" required />
              </Field>
            </>
          )}
          {!reset && (
            <label className="input-icon">
              <Mail />
              <span className="sr-only">
                {signup || verify ? "E-mail" : "E-mail ou telefone"}
              </span>
              <input
                name={signup || verify ? "email" : "identifier"}
                placeholder={signup || verify ? "E-mail" : "E-mail ou telefone"}
                autoComplete="username"
                type={signup || verify ? "email" : "text"}
                required
              />
            </label>
          )}
          {verify ? (
            <>
              <Field label="Código">
                <input
                  name="code"
                  inputMode="numeric"
                  pattern="[0-9]{6,8}"
                  required
                />
              </Field>
              <label className="check">
                <input type="checkbox" name="recovery" defaultChecked={params.get("recovery")==="1"} /> Este código é para
                recuperar a senha
              </label>
            </>
          ) : (
            !recover && (
              <>
                <label className="input-icon">
                  <LockKeyhole />
                  <span className="sr-only">Senha</span>
                  <input
                    name="password"
                    type={show ? "text" : "password"}
                    placeholder={reset ? "Nova senha" : "Senha"}
                    autoComplete={
                      signup || reset ? "new-password" : "current-password"
                    }
                    minLength={signup || reset ? 10 : 1}
                    maxLength={128}
                    required
                  />
                  <button
                    type="button"
                    className="icon"
                    aria-label={show ? "Ocultar senha" : "Mostrar senha"}
                    onClick={() => setShow(!show)}
                  >
                    {show ? <Eye /> : <EyeOff />}
                  </button>
                </label>
                {(signup || reset) && (
                  <Field label="Confirmar senha">
                    <input
                      name="confirm"
                      type={show ? "text" : "password"}
                      required
                      minLength={10}
                    />
                  </Field>
                )}
              </>
            )
          )}
          {screen === "login" && (
            <Link className="forgot" href="/recuperar-senha">
              Esqueceu a senha?
            </Link>
          )}
          {signup && (
            <>
              <details className="terms">
                <summary>Termos de uso e privacidade</summary>
                <p>
                  Seus dados são usados para gerenciar a conta e os agendamentos
                  da barbearia. Não cadastre dados sensíveis nas observações. O
                  responsável pelo estabelecimento deve informar sua política de
                  retenção e os canais de atendimento antes de disponibilizar o
                  serviço comercialmente. Esta instalação é de desenvolvimento
                  até ser configurada para produção.
                </p>
              </details>
              <label className="check">
                <input type="checkbox" name="terms" required /> Li e aceito os
                termos e a política de privacidade.
              </label>
            </>
          )}
          <Notice text={error || (params.get("error")==="callback" ? "Não foi possível concluir a autenticação. O link pode ter expirado; tente entrar novamente." : "")} error />
          <Notice text={message} />
          <button className="primary full" disabled={busy} aria-busy={busy}>
            {busy
              ? "Aguarde…"
              : signup
                ? "Criar conta"
                : recover
                  ? "Enviar recuperação"
                  : verify
                    ? "Verificar código"
                    : reset
                      ? "Salvar nova senha"
                      : "Entrar"}
            <ArrowRight />
          </button>
        </form>
        {screen === "login" ? (
          <>
            <div className="divider">ou</div>
            <button className="google full" onClick={google} disabled={busy} aria-busy={busy}>
              <span className="google-g">G</span>Continuar com Google
            </button>
            <p className="auth-footer">
              Ainda não tem uma conta? <Link href="/cadastro">Criar conta</Link>
            </p>
          </>
        ) : (
          <p className="auth-footer">
            <Link href={verify ? "/recuperar-senha" : "/login"}>
              {verify
                ? "Reenviar código / alterar e-mail"
                : "Voltar para entrar"}
            </Link>
          </p>
        )}
        <small className="auth-caption">
          HAIRCUT · Seu tempo. Seu negócio.
        </small>
      </section>
    </main>
  );
}
export function Onboarding() {
  const router=useRouter();
  const [step, setStep] = useState(0),
    [form, setForm] = useState({name:"",phone:"",address:"",logo:"",professional:"",service:"",price:"40",duration:"30",start:"09:00",end:"19:00"}),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const set=(key:string,value:string)=>setForm(current=>({...current,[key]:value}));
  function next() {
    const required: Record<number, string[]> = {0:["name","phone","address"],2:["professional","service","price","duration"],3:["start","end"]};
    if((required[step] || []).some(key=>!form[key as keyof typeof form].trim())) { setError("Preencha as informações desta etapa para continuar."); return; }
    setError(""); setStep(value=>Math.min(3,value+1));
  }
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    const minutes = (v: string) =>
      String(v)
        .split(":")
        .reduce((n, x, i) => n + Number(x) * (i === 0 ? 60 : 1), 0);
    try {
      await api("/api/data", {
        ...form,
        action: "onboard",
        price: Math.round(Number(form.price) * 100),
        duration: Number(form.duration),
        start: minutes(form.start),
        end: minutes(form.end),
      });
      router.push("/app");router.refresh();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <main className="setup-page">
      <Logo />
      <div className="setup-intro"><span>CONFIGURAÇÃO GUIADA</span><h1>Vamos abrir sua agenda</h1><p className="muted">Em quatro passos rápidos, tudo fica pronto para receber clientes.</p></div>
      <div className="setup-progress" aria-label={`Etapa ${step+1} de 4`}><i style={{width:`${(step+1)*25}%`}} /></div>
      <div className="setup-dots">{[0,1,2,3].map((n)=><button type="button" key={n} className={n===step?"active":n<step?"done":""} onClick={()=>n<step&&setStep(n)} aria-label={`Etapa ${n+1}`}><span>{n+1}</span></button>)}</div>
      <form className="panel setup-card" onSubmit={submit}>
        <div key={step} className="setup-slide">
          {step===0 && <><div className="setup-step-title"><Building2/><div><h2>Sua barbearia</h2><p>Esses dados aparecem para seus clientes.</p></div></div>
            <div className="form-grid"><Field label="Nome da barbearia"><input value={form.name} onChange={e=>set("name",e.target.value)} placeholder="Ex.: Barbearia Central" autoFocus /></Field><Field label="Telefone / WhatsApp"><input value={form.phone} onChange={e=>set("phone",e.target.value)} placeholder="(11) 99999-9999" /></Field><Field label="Endereço"><input value={form.address} onChange={e=>set("address",e.target.value)} placeholder="Rua, número e bairro" /></Field></div></>}
          {step===1 && <><div className="setup-step-title"><ImageIcon/><div><h2>Sua identidade</h2><p>O logo aparecerá na página que o cliente acessa. Você também poderá trocar depois.</p></div></div><ImageUpload name="logo" label="Logo da barbearia (opcional)" kind="logo" value={form.logo} onChange={value=>set("logo",value)} /></>}
          {step===2 && <><div className="setup-step-title"><Scissors/><div><h2>Primeiro serviço</h2><p>Cadastre o primeiro barbeiro e o serviço mais procurado.</p></div></div><div className="form-grid"><Field label="Nome do profissional"><input value={form.professional} onChange={e=>set("professional",e.target.value)} placeholder="Ex.: Carlos" autoFocus /></Field><Field label="Serviço"><input value={form.service} onChange={e=>set("service",e.target.value)} placeholder="Ex.: Corte masculino" /></Field><Field label="Preço (R$)"><input value={form.price} onChange={e=>set("price",e.target.value)} type="number" min="0" step="0.01" /></Field><Field label="Duração (minutos)"><input value={form.duration} onChange={e=>set("duration",e.target.value)} type="number" min="5" max="720" /></Field></div></>}
          {step===3 && <><div className="setup-step-title"><Clock3/><div><h2>Horário de funcionamento</h2><p>Começaremos de segunda a sábado. Depois você poderá ajustar dias, pausas e folgas.</p></div></div><div className="form-grid"><Field label="Abre às"><input value={form.start} onChange={e=>set("start",e.target.value)} type="time" /></Field><Field label="Fecha às"><input value={form.end} onChange={e=>set("end",e.target.value)} type="time" /></Field></div><div className="setup-summary"><strong>Tudo pronto para começar</strong><span>{form.name}</span><span>{form.professional} · {form.service}</span><span>{form.start} às {form.end}</span></div></>}
        </div>
        <Notice text={error} error />
        <div className="setup-actions">
          <button type="button" className="secondary" disabled={step===0||busy} onClick={()=>{setError("");setStep(s=>s-1)}}><ArrowLeft/> Voltar</button>
          {step<3 ? <button type="button" className="primary" onClick={next}>Continuar <ArrowRight/></button> : <button className="primary" disabled={busy} aria-busy={busy}>{busy ? "Preparando…" : "Entrar no painel"}<ArrowRight/></button>}
        </div>
      </form>
    </main>
  );
}
