"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  type PublicData,
  type Appointment,
  type Shop,
  type Entity,
  time,
  dayLabel,
  money,
} from "@/lib/types";
import {
  api,
  Avatar,
  Badge,
  Empty,
  Field,
  Heading,
  Icons,
  Modal,
  Notice,
} from "./ui";
import { Booking, DateSelector } from "./booking";
function ShopBanner({ data }: { data: PublicData }) {
  return (
    <section
      className="public-shop panel"
      style={
        typeof data.shop.data.banner === "string" &&
        (/^https?:\/\//.test(data.shop.data.banner) || data.shop.data.banner.startsWith("data:image/"))
          ? {
              backgroundImage: `linear-gradient(90deg,#0b0b0bee,#0b0b0b80),url("${data.shop.data.banner.replaceAll('"', "%22")}")`,
            }
          : undefined
      }
    >
      <Avatar name={data.shop.name} photo={data.shop.data.logo} size="big" />
      <div>
        <h2>{data.shop.name}</h2>
        <p>
          <Icons.Star className="amber-text" size={18} />
          {data.rating
            ? `${data.rating.toFixed(1)} (${data.reviewCount} avaliações)`
            : "Seja um dos primeiros clientes"}
        </p>
        <small>
          {String(
            data.shop.data.description ||
              "Agende seu horário em poucos passos.",
          )}
        </small>
      </div>
    </section>
  );
}
export function PublicBooking({ slug }: { slug: string }) {
  const router = useRouter();
  const backRef = useRef<() => void>(() => router.back());
  const [data, setData] = useState<PublicData | null>(null),
    [error, setError] = useState("");
  useEffect(() => {
    api<PublicData>("/api/public?" + new URLSearchParams({ slug }))
      .then(setData)
      .catch((e) => setError(e.message));
  }, [slug]);
  return (
    <main
      className="public-page"
      style={
        data?.shop.data.color
          ? ({ "--red": String(data.shop.data.color) } as React.CSSProperties)
          : undefined
      }
    >
      <header className="public-brand-header">
        <button className="public-back" type="button" onClick={() => backRef.current()} aria-label="Voltar">
          <Icons.ArrowLeft size={20} /> Voltar
        </button>
        <span>AGENDAMENTO ONLINE</span>
      </header>
      <Heading
        title="Agendamento"
        subtitle="Escolha seu serviço, profissional e horário."
      />
      <Notice text={error} error />
      {data ? (
        <>
          <ShopBanner data={data} />
          <Booking
            data={data}
            backRef={backRef}
            externalBack={() => router.back()}
            onDone={(r) => window.location.assign("/a/" + r.token)}
          />
          <div className="public-information">
            <section className="panel">
              <h3>
                <Icons.Clock />
                Horário de atendimento
              </h3>
              {data.business_hours
                .filter((h) => !h.closed)
                .sort((a, b) => Number(a.weekday) - Number(b.weekday))
                .map((h) => (
                  <small key={h.id}>
                    {
                      ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"][
                        Number(h.weekday)
                      ]
                    }{" "}
                    · {time(Number(h.start))} às {time(Number(h.end))}
                  </small>
                ))}
            </section>
            <a
              className="panel"
              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(String(data.shop.data.address || data.shop.name))}`}
              target="_blank"
              rel="noreferrer"
            >
              <h3>
                <Icons.MapPin />
                Endereço
              </h3>
              <p>{String(data.shop.data.address || "Consulte a barbearia")}</p>
              <small>
                Como chegar <Icons.ExternalLink size={14} />
              </small>
            </a>
          </div>
        </>
      ) : (
        !error && <div className="skeleton" />
      )}
      <footer className="public-footer">
        Tecnologia HAIRCUT · Sistema de agendamento
      </footer>
    </main>
  );
}
type Detail = {
  appointment: Appointment;
  shop: Shop;
  professional: Entity;
  client: { name: string };
  reviewed: boolean;
};
export function PublicAppointment({ token }: { token: string }) {
  const router = useRouter();
  const [data, setData] = useState<Detail | null>(null),
    [error, setError] = useState(""),
    [message, setMessage] = useState(""),
    [mode, setMode] = useState(""),
    [date, setDate] = useState(""),
    [slots, setSlots] = useState<{ time: number }[]>([]),
    [selected, setSelected] = useState<number | null>(null),
    [rating, setRating] = useState(5),
    [busy, setBusy] = useState(false);
  async function load() {
    try {
      const r = await api<Detail>(
        "/api/public?" + new URLSearchParams({ token }),
      );
      setData(r);
      setDate(r.appointment.date);
    } catch (e) {
      setError((e as Error).message);
    }
  }
  useEffect(() => {
    let live = true;
    api<Detail>("/api/public?" + new URLSearchParams({ token }))
      .then((r) => {
        if (live) {
          setData(r);
          setDate(r.appointment.date);
        }
      })
      .catch((e) => {
        if (live) setError(e.message);
      });
    return () => {
      live = false;
    };
  }, [token]);
  useEffect(() => {
    if (mode !== "reschedule" || !date) return;
    let live = true;
    api<{ time: number }[]>(
      "/api/public?" + new URLSearchParams({ token, slots: "1", date }),
    )
      .then((r) => {
        if (live) setSlots(r);
      })
      .catch((e) => {
        if (live) setError(e.message);
      });
    return () => {
      live = false;
    };
  }, [mode, date, token]);
  async function act(body: Record<string, unknown>) {
    setBusy(true);
    setError("");
    try {
      const r = await api<{ message: string }>("/api/public", {
        token,
        ...body,
      });
      setMessage(r.message);
      setMode("");
      await load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  function calendar() {
    if (!data) return;
    const a = data.appointment;
    const stamp = (n: number) =>
      new Date(`${a.date}T${time(n)}:00-03:00`)
        .toISOString()
        .replace(/[-:]/g, "")
        .replace(".000", "");
    const escape = (s: string) =>
      s
        .replaceAll("\\", "\\\\")
        .replaceAll("\n", "\\n")
        .replaceAll(",", "\\,")
        .replaceAll(";", "\\;");
    const file = [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "PRODID:-//HAIRCUT//Agenda//PT-BR",
      "BEGIN:VEVENT",
      `UID:${a.id}@haircut`,
      `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, "").replace(".000", "")}`,
      `DTSTART:${stamp(a.start_minute)}`,
      `DTEND:${stamp(a.end_minute)}`,
      `SUMMARY:${escape(data.shop.name + " - " + a.data.serviceNames.join(" + "))}`,
      `LOCATION:${escape(String(data.shop.data.address || ""))}`,
      "END:VEVENT",
      "END:VCALENDAR",
    ].join("\r\n");
    const url = URL.createObjectURL(
      new Blob([file], { type: "text/calendar;charset=utf-8" }),
    );
    const link = document.createElement("a");
    link.href = url;
    link.download = "haircut-agendamento.ics";
    link.click();
    URL.revokeObjectURL(url);
  }
  if (!data)
    return (
      <main className="public-page">
        <Notice text={error} error />
        {!error && <div className="skeleton" />}
      </main>
    );
  const a = data.appointment,
    canChange = ["confirmado", "pendente", "aguardando"].includes(a.status);
  return (
    <main className="public-page appointment-public">
      <header className="public-brand-header">
        <button className="public-back" type="button" onClick={() => router.back()}><Icons.ArrowLeft size={20} /> Voltar</button>
        <Link className="shop-brand" href={`/agendar/${data.shop.slug}`}>
          {typeof data.shop.data.logo === "string" && data.shop.data.logo ? <img src={data.shop.data.logo} alt={`Logo ${data.shop.name}`} /> : <strong>{data.shop.name}</strong>}
        </Link>
      </header>
      <div className="success-heading">
        <Icons.CheckCircle2 size={50} />
        <h1>
          {a.status === "confirmado"
            ? "Agendamento confirmado"
            : "Seu agendamento"}
        </h1>
        <p>Olá, {data.client.name}. Confira os detalhes abaixo.</p>
        <Badge status={a.status} />
      </div>
      <Notice text={error} error />
      <Notice text={message} />
      <section className="panel">
        <h2>{data.shop.name}</h2>
        <div className="detail-person">
          <Avatar
            name={data.professional?.name}
            photo={data.professional?.photo}
          />
          <div>
            <strong>{data.professional?.name}</strong>
            <p>{a.data.serviceNames.join(" + ")}</p>
          </div>
        </div>
        <dl className="details">
          <dt>Data</dt>
          <dd>{dayLabel(a.date, true)}</dd>
          <dt>Horário</dt>
          <dd>{time(a.start_minute)}</dd>
          <dt>Duração</dt>
          <dd>{a.data.duration} min</dd>
          <dt>Valor</dt>
          <dd>{money(a.data.total ?? a.data.price)}</dd>
          <dt>Endereço</dt>
          <dd>{String(data.shop.data.address || "Consulte a barbearia")}</dd>
        </dl>
        <div className="actions wrap">
          {canChange && (
            <button className="primary" onClick={calendar}>
              <Icons.CalendarDays size={17} />
              Adicionar ao calendário
            </button>
          )}
          <a
            className="secondary"
            target="_blank"
            rel="noreferrer"
            href={`https://wa.me/${String(
              data.shop.data.whatsapp || data.shop.data.phone || "",
            )
              .replace(/\D/g, "")
              .replace(/^(?!55)/, "55")}`}
          >
            WhatsApp da barbearia
          </a>
          <a
            className="secondary"
            target="_blank"
            rel="noreferrer"
            href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(String(data.shop.data.address || data.shop.name))}`}
          >
            Como chegar
          </a>
          {canChange && (
            <>
              <button
                className="secondary"
                onClick={() => setMode("reschedule")}
              >
                Remarcar
              </button>
              <button className="danger" onClick={() => setMode("cancel")}>
                Cancelar
              </button>
            </>
          )}
        </div>
      </section>
      {a.status === "concluído" && !data.reviewed && (
        <form
          className="panel"
          onSubmit={(e) => {
            e.preventDefault();
            act({
              action: "review",
              rating,
              comment: new FormData(e.currentTarget).get("comment"),
            });
          }}
        >
          <h2>Como foi seu atendimento?</h2>
          <div className="rating">
            {[1, 2, 3, 4, 5].map((n) => (
              <button
                type="button"
                key={n}
                aria-label={`${n} estrelas`}
                aria-pressed={rating === n}
                onClick={() => setRating(n)}
              >
                <Icons.Star fill={n <= rating ? "currentColor" : "none"} />
              </button>
            ))}
          </div>
          <Field label="Conte como foi sua experiência">
            <textarea name="comment" maxLength={2000} />
          </Field>
          <button className="primary" disabled={busy} aria-busy={busy}>
            Enviar avaliação
          </button>
        </form>
      )}
      {data.reviewed && (
        <Notice text="Obrigado! Sua avaliação foi registrada." />
      )}
      {mode === "cancel" && (
        <Modal title="Cancelar agendamento" onClose={() => setMode("")}>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              act({
                action: "cancel",
                reason: new FormData(e.currentTarget).get("reason"),
              });
            }}
          >
            <p>Deseja realmente cancelar este horário?</p>
            <Field label="Motivo (opcional)">
              <select name="reason">
                <option value="">Prefiro não informar</option>
                {[
                  "Não poderei comparecer",
                  "Mudança de horário",
                  "Agendei errado",
                  "Outro",
                ].map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </Field>
            <div className="actions">
              <button
                type="button"
                className="secondary"
                onClick={() => setMode("")}
              >
                Manter agendamento
              </button>
              <button className="danger" disabled={busy} aria-busy={busy}>
                Confirmar cancelamento
              </button>
            </div>
            <Notice text={error} error />
          </form>
        </Modal>
      )}
      {mode === "reschedule" && (
        <Modal title="Remarcar agendamento" onClose={() => setMode("")}>
          <DateSelector
            date={date}
            onChange={(d) => {
              setDate(d);
              setSelected(null);
            }}
          />
          <div className="times">
            {slots.map((s) => (
              <button
                key={s.time}
                className={selected === s.time ? "selected" : ""}
                onClick={() => setSelected(s.time)}
              >
                {time(s.time)}
              </button>
            ))}
          </div>
          {!slots.length && <Empty title="Sem horários nesta data" />}
          <button
            className="primary full"
            disabled={selected === null || busy}
            onClick={() => act({ action: "reschedule", date, time: selected })}
          >
            Confirmar remarcação
          </button>
          <Notice text={error} error />
        </Modal>
      )}
      <p className="secure">
        <Icons.Shield size={16} />
        Guarde este link. Ele dá acesso ao seu agendamento.
      </p>
      <footer className="public-footer">
        HAIRCUT · Sistema de agendamento
      </footer>
    </main>
  );
}
