"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { api, Empty, Field, Heading, Icons, Logo, Notice } from "./ui";
import { money } from "@/lib/types";
import { PLANS, activeSubscription, type Subscription } from "@/lib/plans";
type Row = {
  id: string;
  name: string;
  email?: string;
  created_at: string;
  appointments?: number;
  shop_name?: string;
  barbershop_id?: string;
  price?: number;
  data: Record<string, unknown>;
};
type MasterData = {
  shops: Row[];
  users: Row[];
  subscriptions: Row[];
  plans: Row[];
  tickets: Row[];
  appointments: number;
};
export function Master({ section }: { section: string }) {
  const [data, setData] = useState<MasterData | null>(null),
    [error, setError] = useState(""),
    [message, setMessage] = useState("");
  async function load() {
    try {
      setData(await api("/api/master"));
    } catch (e) {
      setError((e as Error).message);
    }
  }
  useEffect(() => {
    load();
  }, []);
  async function save(body: unknown) {
    try {
      const result=await api<{message:string}>("/api/master", body);
      setMessage(result.message || "Atualizado.");
      setError("");
      await load();
    } catch (e) {
      setError((e as Error).message);
    }
  }
  const active =
      data?.subscriptions.filter((s) => activeSubscription(s.data as Partial<Subscription>)) || [],
    mrr = active.reduce((s, x) => s + Number(x.data.price || 0), 0);
  const rows =
    section === "barbearias"
      ? data?.shops
      : section === "usuarios"
        ? data?.users
        : section === "assinaturas"
          ? data?.subscriptions
          : section === "suporte"
            ? data?.tickets
            : section === "planos"
              ? data?.plans
              : [];
  return (
    <main className="master-page">
      <header>
        <Logo />
        <span>
          <Icons.Shield />
          ADMINISTRAÇÃO HAIRCUT
        </span>
        <Link className="secondary" href="/app">
          Meu painel
        </Link>
      </header>
      <nav className="tabs">
        {[
          ["inicio", "Visão geral"],
          ["barbearias", "Barbearias"],
          ["usuarios", "Usuários"],
          ["assinaturas", "Assinaturas"],
          ["planos", "Planos"],
          ["metricas", "Métricas"],
          ["suporte", "Suporte"],
        ].map(([s, l]) => (
          <Link
            key={s}
            className={section === s ? "selected" : ""}
            href={"/master/" + s}
          >
            {l}
          </Link>
        ))}
      </nav>
      <Heading
        title={
          section === "inicio"
            ? "Visão geral"
            : section.charAt(0).toUpperCase() + section.slice(1)
        }
      />
      <Notice text={error} error />
      <Notice text={message} />
      {data && (
        <>
          {["inicio", "metricas"].includes(section) ? (
            <div className="metrics">
              {[
                ["Barbearias", data.shops.length],
                ["Assinantes ativos", active.length],
                ["Usuários", data.users.length],
                ["Agendamentos", data.appointments],
                ["Básico", active.filter((s) => s.data.planId === "basico").length],
                ["Pro", active.filter((s) => s.data.planId === "pro").length],
                ["Valor mensal contratado", money(mrr)],
                ["Pagamentos recebidos", "Gateway não conectado"],
                [
                  "Cancelamentos",
                  data.subscriptions.filter(
                    (s) => s.data.cancelAtPeriodEnd || s.data.status === "canceled",
                  ).length,
                ],
                [
                  "Novos cadastros no mês",
                  data.shops.filter(
                    (s) =>
                      s.created_at.slice(0, 7) ===
                      new Date().toISOString().slice(0, 7),
                  ).length,
                ],
              ].map(([l, v]) => (
                <section className="panel" key={String(l)}>
                  <p>{l}</p>
                  <strong className="big-number">{v}</strong>
                </section>
              ))}
            </div>
          ) : section === "planos" ? (<div className="entity-grid">{Object.values(PLANS).map(plan=><section className="panel" key={plan.id}><h2>{plan.name}</h2><strong className="price">{money(plan.price)}<small>/mês</small></strong><ul>{plan.features.map(feature=><li key={feature}>{feature}</li>)}</ul></section>)}</div>) : (
            <section className="panel">
              {rows?.map((r) => (
                <details className="master-row" key={r.id}>
                  <summary>
                    <strong>
                      {r.name ||
                        r.shop_name ||
                        String(r.data?.name || "Registro")}
                    </strong>
                    <span>{r.email || (r.data?.status as string) || ""}</span>
                    <Icons.ChevronRight size={17} />
                  </summary>
                  <dl className="details">
                    <dt>Cadastro</dt>
                    <dd>
                      {new Date(r.created_at).toLocaleDateString("pt-BR")}
                    </dd>
                    {r.appointments !== undefined && (
                      <>
                        <dt>Agendamentos</dt>
                        <dd>{r.appointments}</dd>
                      </>
                    )}
                    {r.price !== undefined && (
                      <>
                        <dt>Preço</dt>
                        <dd>{money(r.price)}</dd>
                      </>
                    )}
                    {Object.entries(r.data || {})
                      .filter(([k]) => !["password", "secret"].includes(k))
                      .map(([k, v]) => (
                        <div className="dl-row" key={k}>
                          <dt>{k}</dt>
                          <dd>
                            {typeof v === "object"
                              ? JSON.stringify(v)
                              : String(v)}
                          </dd>
                        </div>
                      ))}
                  </dl>
                  {section === "suporte" && (
                    <Field label="Status">
                      <select
                        value={String(r.data.status)}
                        onChange={(e) =>
                          save({
                            action: "ticket",
                            id: r.id,
                            status: e.target.value,
                          })
                        }
                      >
                        <option>aberto</option>
                        <option>em andamento</option>
                        <option>resolvido</option>
                      </select>
                    </Field>
                  )}
                  {(section === "assinaturas" || section === "barbearias") && <form className="form-grid" onSubmit={event=>{
                    event.preventDefault(); const values=Object.fromEntries(new FormData(event.currentTarget));
                    save({action:"activate-subscription",barbershopId:section==="barbearias"?r.id:r.barbershop_id,planId:values.planId});
                  }}>
                    <Field label="Plano para liberar"><select name="planId" defaultValue={String(r.data?.requestedPlan || r.data?.planId || "basico")}>{Object.values(PLANS).map(plan=><option key={plan.id} value={plan.id}>{plan.name} · {money(plan.price)}/mês</option>)}</select></Field>
                    <p>Liberação manual de um mês, sem registrar cobrança ou pagamento. Se o mesmo plano ainda estiver ativo, acrescenta um mês ao período atual.</p>
                    <button className="primary">Liberar um mês sem cobrança</button>
                  </form>}
                </details>
              ))}
              {!rows?.length && <Empty title="Sem registros" />}
            </section>
          )}

        </>
      )}
    </main>
  );
}
