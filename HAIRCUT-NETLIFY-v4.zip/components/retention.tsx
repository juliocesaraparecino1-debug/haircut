"use client";
import { useState } from "react";
import { type Snapshot, today, dayLabel } from "@/lib/types";
import { clientsToRecover } from "@/lib/retention";
import { Empty, Field, Heading, Icons } from "./ui";
export function RetentionPage({data}:{data:Snapshot}) {
  const [days,setDays]=useState(30);
  const rows=clientsToRecover(data.entities.clients,data.appointments,today(),days);
  return <><Heading title="Clientes a recuperar" subtitle="Encontre quem está há mais tempo sem voltar e convide para um novo atendimento."/>
    <Field label="Tempo desde o último atendimento"><select value={days} onChange={e=>setDays(Number(e.target.value))}><option value={30}>30 dias ou mais</option><option value={60}>60 dias ou mais</option><option value={90}>90 dias ou mais</option></select></Field>
    <section className="panel"><p>{rows.length} cliente(s) sem reserva futura. A mensagem só é enviada quando você confirmar no WhatsApp.</p>
    {rows.map(row=>{let phone=String(row.client.whatsapp || row.client.phone || "").replace(/\D/g,"");if(phone.length===10||phone.length===11)phone="55"+phone;const message=`Olá, ${row.client.name}! Aqui é da ${data.shop.name}. Que tal reservar seu próximo horário? ${data.publicBookingUrl}`;
      return <article className="report-row" key={row.client.id}><strong>{row.client.name}</strong><span>{row.days} dias sem voltar · último atendimento em {dayLabel(row.lastVisit)}</span><a className="secondary" href={`https://wa.me/${phone}?text=${encodeURIComponent(message)}`} target="_blank" rel="noreferrer"><Icons.Phone size={16}/>Convidar pelo WhatsApp</a></article>;
    })}
    {!rows.length && <Empty title="Nenhum cliente para recuperar neste período" text="A lista considera atendimentos concluídos e exclui clientes com reservas futuras."/>}</section></>;
}
