import type { Appointment, Entity } from "./types";
export function clientsToRecover(clients:Entity[],appointments:Appointment[],today:string,minimumDays=30) {
  const now=new Date(today+"T12:00:00Z").getTime();
  return clients.filter(client=>client.active!==false).flatMap(client=>{
    const visits=appointments.filter(a=>a.client_id===client.id && a.status==="concluído").sort((a,b)=>b.date.localeCompare(a.date));
    const upcoming=appointments.some(a=>a.client_id===client.id && a.date>=today && ["confirmado","pendente","aguardando","em atendimento"].includes(a.status));
    if(!visits.length || upcoming) return [];
    const days=Math.floor((now-new Date(visits[0].date+"T12:00:00Z").getTime())/86400000);
    return days>=minimumDays?[{client,lastVisit:visits[0].date,days,visits:visits.length}]:[];
  }).sort((a,b)=>b.days-a.days);
}
