import { cookies, headers } from "next/headers";
import { createServerClient } from "@supabase/ssr";
import {
  createHash,
  randomBytes,
  scryptSync,
  timingSafeEqual,
} from "node:crypto";
import { query, remote, transaction, type DB } from "./db";
import type { Role, Shop, User } from "./types";
export class AppError extends Error {
  constructor(
    message: string,
    public status = 400,
  ) {
    super(message);
  }
}
export const hash = (s: string) => createHash("sha256").update(s).digest("hex");
export function passwordHash(password: string) {
  const salt = randomBytes(16).toString("hex");
  return salt + ":" + scryptSync(password, salt, 64).toString("hex");
}
export function passwordMatches(password: string, value: string) {
  const [salt, key] = value.split(":");
  if (!salt || !key) return false;
  const a = scryptSync(password, salt, 64),
    b = Buffer.from(key, "hex");
  return a.length === b.length && timingSafeEqual(a, b);
}
export async function supabase() {
  const jar = await cookies();
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll: () => jar.getAll(),
        setAll: (values) => {
          try {
            for (const { name, value, options } of values)
              jar.set(name, value, options);
          } catch {
            /* Server Components are read-only; proxy refreshes cookies. */
          }
        },
      },
    },
  );
}
export async function sessionUser(): Promise<User | null> {
  if (remote()) {
    const s = await supabase();
    const {
      data: { user },
    } = await s.auth.getUser();
    if (!user) return null;
    const assurance = await s.auth.mfa.getAuthenticatorAssuranceLevel();
    if (
      assurance.error ||
      (assurance.data?.nextLevel === "aal2" &&
        assurance.data.currentLevel !== "aal2")
    )
      return null;
    const existing = (
      await query<User>(
        "select id,name,email,phone,master from users where id=$1",
        [user.id],
      )
    ).rows[0];
    if (existing) return existing;
    const u = {
      id: user.id,
      name: String(
        user.user_metadata.name || user.email?.split("@")[0] || "Usuário",
      ),
      email: user.email || "",
      phone: user.phone || String(user.user_metadata.phone || ""),
      master: false,
    };
    await query(
      "insert into users(id,name,email,phone) values($1,$2,$3,$4) on conflict(id) do nothing",
      [u.id, u.name, u.email, u.phone],
    );
    return u;
  }
  const raw = (await cookies()).get("haircut_session")?.value;
  if (!raw) return null;
  return (
    (
      await query<User>(
        "select u.id,u.name,u.email,u.phone,u.master from sessions s join users u on u.id=s.user_id where s.id=$1 and s.expires_at>now()",
        [hash(raw)],
      )
    ).rows[0] || null
  );
}
export async function createSession(userId: string) {
  const token = randomBytes(32).toString("base64url");
  await query(
    "insert into sessions(id,user_id,expires_at,agent) values($1,$2,now()+interval '7 days',$3)",
    [
      hash(token),
      userId,
      (await headers()).get("user-agent")?.slice(0, 200) || "Navegador",
    ],
  );
  (await cookies()).set("haircut_session", token, {
    httpOnly: true,
    secure: process.env.APP_URL?.startsWith("https://") || false,
    sameSite: "lax",
    path: "/",
    maxAge: 604800,
  });
}
export async function context() {
  const user = await sessionUser();
  if (!user) throw new AppError("Entre na sua conta para continuar.", 401);
  const result = (
    await query<Shop & { role: Role }>(
      "select b.*,m.role from barbershop_members m join barbershops b on b.id=m.barbershop_id where m.user_id=$1 order by m.created_at limit 1",
      [user.id],
    )
  ).rows[0];
  if (!result) throw new AppError("Conclua o primeiro acesso.", 428);
  return { user, shop: result, role: result.role };
}
export function admin(role: Role) {
  if (!["OWNER", "ADMIN", "MASTER"].includes(role))
    throw new AppError("Esta ação exige acesso de administrador.", 403);
}
export async function tenantTx<T>(id: string, fn: (db: DB) => Promise<T>) {
  return transaction(async (db) => {
    await db.query("select id from barbershops where id=$1 for update", [id]);
    return fn(db);
  });
}
export async function rateLimit(key: string, max = 30) {
  const r = await query<{ count: number }>(
    "insert into rate_limits(key,count,expires_at) values($1,1,now()+interval '10 minutes') on conflict(key) do update set count=case when rate_limits.expires_at<now() then 1 else rate_limits.count+1 end, expires_at=case when rate_limits.expires_at<now() then now()+interval '10 minutes' else rate_limits.expires_at end returning count",
    [hash(key)],
  );
  if (r.rows[0].count > max)
    throw new AppError("Muitas tentativas. Aguarde alguns minutos.", 429);
}
export function checkOrigin(req: Request) {
  const origin = req.headers.get("origin");
  const url = new URL(req.url);
  const allowed = process.env.APP_URL
    ? new URL(process.env.APP_URL).origin
    : url.origin;
  const extraOrigins = (process.env.HAIRCUT_ALLOWED_ORIGINS || "")
    .split(",").map(value => value.trim()).filter(Boolean);
  if (origin && origin !== allowed && origin !== url.origin && !extraOrigins.includes(origin))
    throw new AppError("Origem não permitida.", 403);
}
export function siteOrigin(req: Request) {
  const canonical = process.env.HAIRCUT_PUBLIC_URL || process.env.APP_URL || new URL(req.url).origin;
  const allowed = [canonical, process.env.APP_URL, ...(process.env.HAIRCUT_ALLOWED_ORIGINS || "").split(",")].filter(Boolean).map(value => new URL(value!.trim()).origin);
  const incoming = req.headers.get("origin") || `${new URL(req.url).protocol}//${req.headers.get("host") || new URL(req.url).host}`;
  return allowed.includes(incoming) ? incoming : new URL(canonical).origin;
}
