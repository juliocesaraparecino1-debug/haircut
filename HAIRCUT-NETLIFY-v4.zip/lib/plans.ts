export const PLANS = {
  basico: { id: "basico", name: "Básico", price: 5990, professionalLimit: 3, features: ["Até 3 profissionais ativos", "Agendamentos e clientes ilimitados", "Link com o nome da barbearia e QR Code", "Agenda, serviços e histórico de clientes", "Resumo de faturamento diário"] },
  pro: { id: "pro", name: "Pro", price: 8990, professionalLimit: null, features: ["Tudo do Básico", "Profissionais ativos ilimitados", "Relatórios detalhados e exportação CSV", "Cálculo e acompanhamento de comissões", "Lista de espera por profissional", "Clientes a recuperar com contato pelo WhatsApp"] },
} as const;
export type PlanId = keyof typeof PLANS;
export type Subscription = {
  id?: string; planId: PlanId; name: string; price: number;
  status: "pending_activation" | "active" | "canceled";
  requestedPlan?: PlanId; currentPeriodStart?: string; currentPeriodEnd?: string;
  cancelAtPeriodEnd?: boolean; activationSource?: "manual" | "gateway";
  paymentStatus?: "not_collected" | "paid"; gatewayCustomerId?: string; gatewaySubscriptionId?: string;
};
export function defaultSubscription(): Subscription {
  return { planId: "basico", name: PLANS.basico.name, price: PLANS.basico.price, status: "pending_activation", paymentStatus: "not_collected" };
}
export function activeSubscription(subscription: Partial<Subscription> | undefined, now = new Date()) {
  return subscription?.status === "active" && Boolean(subscription.currentPeriodEnd) && new Date(subscription.currentPeriodEnd!).getTime() > now.getTime();
}
export function hasPro(subscription: Partial<Subscription> | undefined, now = new Date()) {
  return activeSubscription(subscription, now) && subscription?.planId === "pro";
}
export function nextMonthlyDate(start: Date) {
  const end = new Date(start);
  const day = end.getUTCDate();
  end.setUTCDate(1);
  end.setUTCMonth(end.getUTCMonth() + 1);
  const last = new Date(Date.UTC(end.getUTCFullYear(), end.getUTCMonth() + 1, 0)).getUTCDate();
  end.setUTCDate(Math.min(day, last));
  return end;
}
