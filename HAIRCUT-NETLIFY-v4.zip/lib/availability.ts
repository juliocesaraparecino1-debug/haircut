import type { Appointment, Entity, Shop } from "./types";
export type Schedule = {
  shop: Shop;
  professionals: Entity[];
  services: Entity[];
  business_hours: Entity[];
  professional_hours: Entity[];
  schedule_blocks: Entity[];
  closed_dates: Entity[];
  appointments: Appointment[];
};
export function overlaps(a: number, b: number, c: number, d: number) {
  return a < d && b > c;
}
export function availableSlots(
  s: Schedule,
  date: string,
  serviceIds: string[],
  professionalId?: string,
  ignoreId?: string,
  now = new Date(),
) {
  const parsedDate = new Date(date + "T12:00:00Z");
  if (
    !/^\d{4}-\d{2}-\d{2}$/.test(date) ||
    Number.isNaN(parsedDate.getTime()) ||
    parsedDate.toISOString().slice(0, 10) !== date
  )
    return [];
  const selected = s.services.filter(
    (x) => serviceIds.includes(x.id) && x.active !== false,
  );
  if (!selected.length || selected.length !== new Set(serviceIds).size)
    return [];
  const duration = selected.reduce((sum, x) => sum + Number(x.duration), 0),
    buffer = Number(s.shop.data.buffer || 0),
    notice = Number(s.shop.data.notice || 0);
  if (
    duration <= 0 ||
    duration > 720 ||
    s.closed_dates.some((x) => x.date === date)
  )
    return [];
  const weekday = new Date(date + "T12:00:00Z").getUTCDay();
  const business = s.business_hours.find((x) => Number(x.weekday) === weekday);
  if (!business || business.closed) return [];
  const result: {
    time: number;
    professionalId: string;
    duration: number;
    price: number;
  }[] = [];
  for (const pro of s.professionals.filter(
    (x) => x.active !== false && (!professionalId || professionalId === x.id),
  )) {
    const allowed = (pro.serviceIds as string[] | undefined) || [];
    if (!serviceIds.every((id) => allowed.includes(id))) continue;
    const own = s.professional_hours.find(
      (x) => x.professionalId === pro.id && Number(x.weekday) === weekday,
    );
    if (own?.closed) continue;
    const begin = Math.max(
      Number(business.start),
      Number(own?.start ?? business.start),
    );
    const end = Math.min(
      Number(business.end),
      Number(own?.end ?? business.end),
    );
    for (
      let at = Math.ceil(begin / 15) * 15;
      at + duration + buffer <= end;
      at += 15
    ) {
      // Brasilia fixed UTC-03; supported shop timezone is deliberately restricted.
      const stamp = new Date(
        `${date}T${String(Math.floor(at / 60)).padStart(2, "0")}:${String(at % 60).padStart(2, "0")}:00-03:00`,
      ).getTime();
      if (stamp < now.getTime() + notice * 60000) continue;
      const breaks = [
        ...((business.breaks as { start: number; end: number }[]) || []),
        ...((own?.breaks as { start: number; end: number }[]) || []),
      ];
      if (
        breaks.some((b) => overlaps(at, at + duration + buffer, b.start, b.end))
      )
        continue;
      if (
        s.schedule_blocks.some(
          (b) =>
            b.date === date &&
            (!b.professionalId || b.professionalId === pro.id) &&
            overlaps(
              at,
              at + duration + buffer,
              Number(b.start),
              Number(b.end),
            ),
        )
      )
        continue;
      if (
        s.appointments.some(
          (a) =>
            a.id !== ignoreId &&
            a.date === date &&
            a.professional_id === pro.id &&
            !["cancelado", "não compareceu"].includes(a.status) &&
            overlaps(
              at,
              at + duration + buffer,
              a.start_minute,
              a.end_minute + buffer,
            ),
        )
      )
        continue;
      result.push({
        time: at,
        professionalId: pro.id,
        duration,
        price: selected.reduce((sum, x) => sum + Number(x.price), 0),
      });
    }
  }
  return result.sort(
    (a, b) =>
      a.time - b.time || a.professionalId.localeCompare(b.professionalId),
  );
}
