import type { DB } from "./db";
export function slugFromName(name: string) {
  return name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").slice(0,72).replace(/-+$/g,"") || "barbearia";
}
export async function availableShopSlug(db: DB, name: string, exceptId?: string) {
  // Serialize reservation across remote transactions, including an empty database.
  if(process.env.HAIRCUT_MODE === "supabase") await db.query("select pg_advisory_xact_lock(73481942)");
  const shops=(await db.query<{slug:string;aliases:string[]|null}>("select slug,data->'slugAliases' as aliases from barbershops where ($1::uuid is null or id<>$1)",[exceptId || null])).rows;
  const occupied=new Set(shops.flatMap(shop=>[shop.slug,...(shop.aliases || [])]));
  const base=slugFromName(name);
  let slug=base, index=2;
  while(occupied.has(slug)) slug=`${base}-${index++}`;
  return slug;
}
