import { randomUUID, randomBytes } from "node:crypto";
import { query, type DB } from "./db";
import { AppError, hash } from "./auth";
import {
  entities,
  type Entity,
  type EntityName,
  type Appointment,
  type Shop,
  type PublicData,
  type Role,
} from "./types";
import { availableSlots, type Schedule } from "./availability";
import { bookingSchema } from "./validation";
import { subscriptionFor } from "./billing";
import { hasPro } from "./plans";
export async function records(
  db: DB,
  table: EntityName,
  tenant: string,
): Promise<Entity[]> {
  const rows = (
    await db.query<{
      id: string;
      data: Record<string, unknown>;
      created_at: string;
      updated_at: string;
    }>(
      `select id,data,created_at,updated_at from ${table} where barbershop_id=$1 order by created_at desc limit 5000`,
      [tenant],
    )
  ).rows;
  return rows.map((r) => ({
    ...r.data,
    id: r.id,
    created_at: String(r.created_at),
    updated_at: String(r.updated_at),
  }));
}
export async function save(
  db: DB,
  table: EntityName,
  tenant: string,
  data: Record<string, unknown>,
  id?: string,
) {
  const key = id || randomUUID();
  if (id) {
    const result = await db.query(
      `update ${table} set data=$1,updated_at=now() where id=$2 and barbershop_id=$3 returning id`,
      [JSON.stringify(data), key, tenant],
    );
    if (!result.rows.length)
      throw new AppError("Registro não encontrado.", 404);
  } else
    await db.query(
      `insert into ${table}(id,barbershop_id,data) values($1,$2,$3)`,
      [key, tenant, JSON.stringify(data)],
    );
  return key;
}
export async function audit(
  db: DB,
  tenant: string,
  userId: string | null,
  action: string,
  entityId: string,
) {
  await db.query(
    "insert into audit_logs(id,barbershop_id,user_id,action,entity_id) values($1,$2,$3,$4,$5)",
    [randomUUID(), tenant, userId, action, entityId],
  );
}
export async function notify(
  db: DB,
  tenant: string,
  text: string,
  appointmentId?: string,
) {
  await save(db, "notifications", tenant, {
    name: text,
    read: false,
    appointmentId,
  });
}
export async function schedule(db: DB, shop: Shop): Promise<Schedule> {
  const [
    professionals,
    services,
    business_hours,
    professional_hours,
    schedule_blocks,
    closed_dates,
    appts,
  ] = await Promise.all([
    records(db, "professionals", shop.id),
    records(db, "services", shop.id),
    records(db, "business_hours", shop.id),
    records(db, "professional_hours", shop.id),
    records(db, "schedule_blocks", shop.id),
    records(db, "closed_dates", shop.id),
    db.query<Appointment>(
      "select * from appointments where barbershop_id=$1 order by date,start_minute",
      [shop.id],
    ),
  ]);
  return {
    shop,
    professionals,
    services,
    business_hours,
    professional_hours,
    schedule_blocks,
    closed_dates,
    appointments: appts.rows,
  };
}
export async function publicShop(slug: string): Promise<Shop> {
  const row = (
    await query<Shop>("select * from barbershops where slug=$1 or coalesce(data->'slugAliases','[]'::jsonb) ? $1 order by (slug=$1) desc limit 1", [slug])
  ).rows[0];
  if (!row) throw new AppError("Barbearia não encontrada.", 404);
  return row;
}
export async function publicData(db: DB, shop: Shop): Promise<PublicData> {
  const [p, s, b, r] = await Promise.all([
    records(db, "professionals", shop.id),
    records(db, "services", shop.id),
    records(db, "business_hours", shop.id),
    records(db, "reviews", shop.id),
  ]);
  return {
    waitlistEnabled: hasPro(await subscriptionFor(db,shop.id)),
    shop: {
      ...shop,
      data: Object.fromEntries(
        Object.entries(shop.data).filter(([k]) =>
          [
            "description",
            "phone",
            "whatsapp",
            "address",
            "instagram",
            "logo",
            "banner",
            "color",
          ].includes(k),
        ),
      ),
    },
    professionals: p
      .filter((x) => x.active !== false)
      .map((x) => ({
        id: x.id,
        created_at: x.created_at,
        name: x.name,
        specialty: x.specialty,
        photo: x.photo,
        serviceIds: x.serviceIds,
      })),
    services: s.filter((x) => x.active !== false),
    business_hours: b,
    rating: r.length
      ? r.reduce((n, x) => n + Number(x.rating), 0) / r.length
      : null,
    reviewCount: r.length,
  };
}
export async function snapshotEntities(db: DB, tenant: string) {
  // One database round trip instead of a separate query for every dashboard section.
  // Table names come exclusively from the static application allowlist.
  const result = await db.query<{ kind: EntityName; id: string; data: Record<string, unknown>; created_at: string; updated_at: string }>(
    entities.map((table) => `(select '${table}' as kind,id,data,created_at,updated_at from ${table} where barbershop_id=$1 order by created_at desc limit 5000)`).join(" union all "),
    [tenant],
  );
  const snapshot = Object.fromEntries(entities.map((table) => [table, []])) as unknown as Record<EntityName, Entity[]>;
  for (const row of result.rows) snapshot[row.kind].push({ ...row.data, id: row.id, created_at: String(row.created_at), updated_at: String(row.updated_at) });
  return snapshot;
}
export async function book(
  db: DB,
  shop: Shop,
  input: unknown,
  origin: "público" | "interno",
  userId: string | null,
) {
  const b = bookingSchema.parse(input);
  const s = await schedule(db, shop);
  const slot = availableSlots(
    s,
    b.date,
    b.serviceIds,
    b.professionalId || undefined,
  ).find((x) => x.time === b.time);
  if (!slot)
    throw new AppError(
      "Este horário não está mais disponível. Escolha outro.",
      409,
    );
  let clientId = b.clientId;
  if (origin === "público") clientId = undefined;
  if (clientId) {
    const c = (
      await db.query(
        "select id from clients where id=$1 and barbershop_id=$2 and coalesce((data->>'active')::boolean,true)",
        [clientId, shop.id],
      )
    ).rows[0];
    if (!c) throw new AppError("Cliente inválido.", 400);
  } else {
    if (!b.client) throw new AppError("Informe os dados do cliente.");
    const existing = (
      await db.query<{ id: string }>(
        "select id from clients where barbershop_id=$1 and data->>'phone'=$2 and coalesce((data->>'active')::boolean,true)",
        [shop.id, b.client.phone],
      )
    ).rows[0];
    if(!existing && (await db.query("select id from clients where barbershop_id=$1 and data->>'phone'=$2",[shop.id,b.client.phone])).rows.length) throw new AppError("Entre em contato com a barbearia para atualizar seu cadastro.",409);
    clientId = existing?.id || (await save(db, "clients", shop.id, b.client));
  }
  const token = randomBytes(32).toString("base64url"),
    id = randomUUID();
  const selected = s.services.filter((x) => b.serviceIds.includes(x.id));
  const data = {
    serviceIds: b.serviceIds,
    serviceNames: selected.map((x) => x.name),
    duration: slot.duration,
    price: slot.price,
    notes: b.notes,
    origin,
  };
  await db.query(
    "insert into appointments(id,barbershop_id,client_id,professional_id,date,start_minute,end_minute,status,data,token_hash) values($1,$2,$3,$4,$5,$6,$7,'confirmado',$8,$9)",
    [
      id,
      shop.id,
      clientId,
      slot.professionalId,
      b.date,
      slot.time,
      slot.time + slot.duration,
      JSON.stringify(data),
      hash(token),
    ],
  );
  for (const service of selected)
    await db.query(
      "insert into appointment_services(barbershop_id,appointment_id,service_id,price,duration) values($1,$2,$3,$4,$5)",
      [shop.id, id, service.id, service.price, service.duration],
    );
  await notify(db, shop.id, "Novo agendamento confirmado", id);
  await audit(db, shop.id, userId, "agendamento.criado", id);
  return { id, token };
}
export async function appointment(db: DB, tenant: string, id: string) {
  const a = (
    await db.query<Appointment>(
      "select * from appointments where id=$1 and barbershop_id=$2",
      [id, tenant],
    )
  ).rows[0];
  if (!a) throw new AppError("Agendamento não encontrado.", 404);
  return a;
}
export function checkProfessional(
  role: Role,
  pro: Entity | undefined,
  userId: string,
) {
  if (role === "PROFESSIONAL" && pro?.userId !== userId)
    throw new AppError("Este atendimento pertence a outro profissional.", 403);
  if (role === "CLIENT") throw new AppError("Acesso não permitido.", 403);
}
export async function reschedule(
  db: DB,
  shop: Shop,
  a: Appointment,
  date: string,
  start: number,
  userId: string | null,
) {
  if (["concluído", "cancelado", "não compareceu"].includes(a.status))
    throw new AppError("Este agendamento não pode ser remarcado.");
  const s = await schedule(db, shop);
  const slot = availableSlots(
    s,
    date,
    a.data.serviceIds,
    a.professional_id,
    a.id,
  ).find((x) => x.time === start);
  if (!slot) throw new AppError("Horário indisponível.", 409);
  await db.query(
    "update appointments set date=$1,start_minute=$2,end_minute=$3,status='confirmado',updated_at=now() where id=$4 and barbershop_id=$5",
    [date, start, start + slot.duration, a.id, shop.id],
  );
  await notify(db, shop.id, "Agendamento remarcado", a.id);
  await audit(db, shop.id, userId, "agendamento.remarcado", a.id);
}
