export type Role = "OWNER" | "ADMIN" | "PROFESSIONAL" | "CLIENT" | "MASTER";
export type Status =
  | "pendente"
  | "confirmado"
  | "aguardando"
  | "em atendimento"
  | "concluído"
  | "cancelado"
  | "não compareceu";
export type Entity = {
  id: string;
  created_at: string;
  updated_at?: string;
  name?: string;
  [key: string]: unknown;
};
export type Shop = {
  id: string;
  name: string;
  slug: string;
  data: Record<string, unknown>;
  created_at: string;
};
export type User = {
  id: string;
  name: string;
  email: string;
  phone: string;
  master: boolean;
};
export type Appointment = {
  id: string;
  barbershop_id: string;
  client_id: string;
  professional_id: string;
  date: string;
  start_minute: number;
  end_minute: number;
  status: Status;
  data: {
    serviceIds: string[];
    serviceNames: string[];
    duration: number;
    price: number;
    notes?: string;
    origin: string;
    discount?: number;
    extra?: number;
    paymentMethod?: string;
    total?: number;
    cancelReason?: string;
  };
  created_at: string;
  updated_at: string;
};
export const entities = [
  "professionals",
  "services",
  "clients",
  "business_hours",
  "professional_hours",
  "schedule_blocks",
  "closed_dates",
  "notifications",
  "reviews",
  "subscriptions",
  "payments",
  "commissions",
  "public_page_settings",
  "waitlist",
  "support_tickets",
] as const;
export type EntityName = (typeof entities)[number];
export type Snapshot = {
  subscription: import("./plans").Subscription;
  publicBookingUrl: string;
  user: User;
  shop: Shop;
  role: Role;
  mode: string;
  appointments: Appointment[];
  entities: Record<EntityName, Entity[]>;
};
export type PublicData = {
  waitlistEnabled?: boolean;
  shop: Shop;
  professionals: Entity[];
  services: Entity[];
  business_hours: Entity[];
  rating: number | null;
  reviewCount: number;
};
export const statusColors: Record<Status, string> = {
  pendente: "amber",
  confirmado: "green",
  aguardando: "gray",
  "em atendimento": "blue",
  concluído: "green",
  cancelado: "red",
  "não compareceu": "amber",
};
export const money = (n: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
    n / 100,
  );
export const time = (n: number) =>
  `${String(Math.floor(n / 60)).padStart(2, "0")}:${String(n % 60).padStart(2, "0")}`;
export const minute = (s: string) =>
  Number(s.split(":")[0]) * 60 + Number(s.split(":")[1]);
export const today = () =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
export function dayLabel(s: string, long = false) {
  return new Intl.DateTimeFormat("pt-BR", {
    timeZone: "UTC",
    day: "numeric",
    month: long ? "long" : "short",
    ...(long ? { weekday: "long" as const } : {}),
  }).format(new Date(s + "T12:00:00Z"));
}
export function addDays(s: string, n: number) {
  const d = new Date(s + "T12:00:00Z");
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
