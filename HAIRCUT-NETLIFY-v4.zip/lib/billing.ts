import { randomUUID } from "node:crypto";
import type { DB } from "./db";
import { AppError } from "./auth";
import { PLANS, defaultSubscription, hasPro, nextMonthlyDate, type PlanId, type Subscription } from "./plans";

export async function subscriptionFor(db: DB, tenant: string): Promise<Subscription> {
  const row = (await db.query<{id:string;data:Subscription}>("select id,data from subscriptions where barbershop_id=$1 order by created_at desc limit 1",[tenant])).rows[0];
  return row ? { ...defaultSubscription(), ...row.data, id: row.id } : defaultSubscription();
}
export async function writeSubscription(db: DB, tenant: string, data: Subscription) {
  const { id, ...fields } = data;
  if (id) await db.query("update subscriptions set data=$1,updated_at=now() where id=$2 and barbershop_id=$3",[JSON.stringify(fields),id,tenant]);
  else await db.query("insert into subscriptions(id,barbershop_id,data) values($1,$2,$3)",[randomUUID(),tenant,JSON.stringify(fields)]);
}
export async function assertProfessionalLimit(db: DB, tenant: string, excludeId?: string, plan?: PlanId) {
  const sub = await subscriptionFor(db,tenant);
  if (plan === "pro" || (!plan && hasPro(sub))) return;
  const result = await db.query<{count:string}>("select count(*) from professionals where barbershop_id=$1 and coalesce((data->>'active')::boolean,true) and ($2::uuid is null or id<>$2)",[tenant,excludeId || null]);
  if(Number(result.rows[0].count) >= PLANS.basico.professionalLimit) throw new AppError("O Básico permite até 3 profissionais ativos. Inative um profissional ou solicite o Pro.",403);
}
export async function requestPlan(db: DB, tenant: string, planId: PlanId) {
  const sub = await subscriptionFor(db,tenant);
  if(planId === "basico") {
    const rows = await db.query<{count:string}>("select count(*) from professionals where barbershop_id=$1 and coalesce((data->>'active')::boolean,true)",[tenant]);
    if(Number(rows.rows[0].count)>3) throw new AppError("Inative os profissionais excedentes antes de escolher o Básico.",409);
  }
  sub.requestedPlan = planId;
  sub.cancelAtPeriodEnd = false;
  await writeSubscription(db,tenant,sub);
  return sub;
}
export async function activateMonthly(db: DB, tenant: string, planId: PlanId, now = new Date()) {
  const sub = await subscriptionFor(db,tenant);
  if(planId === "basico") {
    const result=await db.query<{count:string}>("select count(*) from professionals where barbershop_id=$1 and coalesce((data->>'active')::boolean,true)",[tenant]);
    if(Number(result.rows[0].count)>3) throw new AppError("O Básico permite até 3 profissionais ativos.",409);
  }
  const sameActive = sub.planId === planId && sub.status === "active" && new Date(sub.currentPeriodEnd || 0) > now;
  const start = sameActive ? new Date(sub.currentPeriodEnd!) : now;
  const next: Subscription = { ...sub, planId, name: PLANS[planId].name, price: PLANS[planId].price, status: "active", currentPeriodStart: sameActive ? sub.currentPeriodStart : now.toISOString(), currentPeriodEnd: nextMonthlyDate(start).toISOString(), cancelAtPeriodEnd:false, activationSource:"manual", paymentStatus:"not_collected" };
  delete next.requestedPlan;
  await writeSubscription(db,tenant,next);
  return next;
}
export async function requirePro(db: DB, tenant: string) {
  if(!hasPro(await subscriptionFor(db,tenant))) throw new AppError("Este recurso está disponível no plano Pro.",403);
}
