import { PGlite } from "@electric-sql/pglite";
import { Pool } from "pg";
import fs from "node:fs/promises";
import path from "node:path";
export interface DB {
  query<T = Record<string, unknown>>(
    sql: string,
    args?: unknown[],
  ): Promise<{ rows: T[] }>;
}
type Engine = { db: DB; local?: PGlite; pool?: Pool };
const g = globalThis as typeof globalThis & { haircutEngine?: Promise<Engine> };
export const remote = () => process.env.HAIRCUT_MODE === "supabase";
export async function engine(): Promise<Engine> {
  if (!g.haircutEngine)
    g.haircutEngine = (async () => {
      if (remote()) {
        if (
          !process.env.DATABASE_URL ||
          !process.env.NEXT_PUBLIC_SUPABASE_URL ||
          !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
        )
          throw new Error(
            "Supabase incompleto: configure DATABASE_URL, URL e chave pública.",
          );
        const uri = new URL(process.env.DATABASE_URL);
        uri.searchParams.delete("sslmode");
        uri.searchParams.delete("sslrootcert");
        const ca = await fs.readFile(
          path.resolve(process.env.DATABASE_CA_PATH || "certs/supabase-ca.crt"),
          "utf8",
        );
        const pool = new Pool({
          connectionString: uri.toString(),
          max: 5,
          min: 1,
          idleTimeoutMillis: 60000,
          connectionTimeoutMillis: 12000,
          ssl: { ca, rejectUnauthorized: true },
        });
        return { db: pool as DB, pool };
      }
      const dir = path.resolve(
        process.env.HAIRCUT_DATA_DIR || ".data/postgres",
      );
      await fs.mkdir(dir, { recursive: true });
      const local = new PGlite(dir);
      await local.waitReady;
      await local.exec(
        await fs.readFile(
          path.join(process.cwd(), "supabase/migrations/001_haircut.sql"),
          "utf8",
        ),
      );
      return { db: local as DB, local };
    })();
  return g.haircutEngine;
}
export async function query<T = Record<string, unknown>>(
  sql: string,
  args: unknown[] = [],
) {
  return (await engine()).db.query<T>(sql, args);
}
export async function transaction<T>(fn: (db: DB) => Promise<T>): Promise<T> {
  const e = await engine();
  if (e.local) return e.local.transaction((tx) => fn(tx as DB));
  const c = await e.pool!.connect();
  let tail: Promise<void> = Promise.resolve();
  const scoped: DB = {
    query<R = Record<string, unknown>>(sql: string, args?: unknown[]) {
      const result = tail.then(
        () => c.query(sql, args) as unknown as Promise<{ rows: R[] }>,
      );
      tail = result.then(
        () => {},
        () => {},
      );
      return result;
    },
  };
  try {
    await c.query("BEGIN");
    const out = await fn(scoped);
    await c.query("COMMIT");
    return out;
  } catch (err) {
    await c.query("ROLLBACK");
    throw err;
  } finally {
    c.release();
  }
}
