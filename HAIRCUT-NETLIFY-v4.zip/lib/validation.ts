import { z } from "zod";
const text = z.string().trim().min(1).max(200);
const phone = z
  .string()
  .transform((v) => v.replace(/\D/g, ""))
  .pipe(z.string().min(10).max(15));
export const clientSchema = z.object({
  name: text,
  phone,
  whatsapp: z.string().max(20).optional(),
  email: z.union([z.email(), z.literal("")]).optional(),
  birthday: z.string().max(10).optional(),
  notes: z.string().max(4000).optional(),
  active: z.boolean().default(true),
  favorite: z.boolean().default(false),
  photo: z.string().max(1000).optional(),
});
export const serviceSchema = z.object({
  name: text,
  description: z.string().max(2000).default(""),
  price: z.number().int().min(0).max(10000000),
  duration: z.number().int().min(5).max(720),
  category: z.string().max(100).default(""),
  active: z.boolean().default(true),
  professionalIds: z.array(z.uuid()).max(100).refine(ids=>new Set(ids).size===ids.length,"Selecione profissionais distintos.").optional(),
});
export const professionalSchema = z.object({
  name: text,
  phone: z.string().max(20).default(""),
  email: z.union([z.email(), z.literal("")]).default(""),
  specialty: z.string().max(200).default("Barbeiro"),
  description: z.string().max(2000).default(""),
  photo: z.string().max(1000).default(""),
  active: z.boolean().default(true),
  commission: z.number().min(0).max(100).default(0),
  serviceIds: z.array(z.uuid()).refine(ids=>new Set(ids).size===ids.length,"Selecione serviços distintos.").default([]),
  userId: z.union([z.uuid(), z.literal("")]).default(""),
});
export const bookingSchema = z.object({
  serviceIds: z.array(z.uuid()).min(1).max(12).refine(ids => new Set(ids).size === ids.length, "Selecione serviços distintos."),
  professionalId: z.string().optional(),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  time: z.number().int().min(0).max(1439),
  clientId: z.uuid().optional(),
  client: clientSchema.optional(),
  notes: z.string().max(4000).default(""),
});
export const signupSchema = z.object({
  name: text,
  email: z.email(),
  phone,
  password: z.string().min(10).max(128),
  terms: z.literal(true),
});
