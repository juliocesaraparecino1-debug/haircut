import { Pool } from 'pg';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';

// Limited to the original demo tenant. Read-only unless --apply is passed.
const uri=new URL(process.env.DATABASE_URL);
uri.search='';
const pool=new Pool({connectionString:uri.toString(),ssl:{ca:await fs.readFile('certs/supabase-ca.crt','utf8'),rejectUnauthorized:true}});
const db=await pool.connect();
try {
  await db.query('begin');
  const owner=(await db.query('select id,name from users where email=$1',[process.env.HAIRCUT_DEMO_EMAIL])).rows[0];
  assert.ok(owner,'Configured account not found');
  const shops=(await db.query("select b.* from barbershops b join barbershop_members m on b.id=m.barbershop_id where m.user_id=$1 and m.role='OWNER'",[owner.id])).rows;
  assert.equal(shops.length,1,'Expected exactly one original demo tenant');
  const shop=shops[0];
  assert.ok(['bravus-barber','minha-barbearia'].includes(shop.slug),'Unexpected tenant; no deletion performed');
  await db.query('select id from barbershops where id=$1 for update',[shop.id]);
  const tables=['appointment_services','professional_services','appointments','payments','commissions','reviews','notifications','waitlist','support_tickets','schedule_blocks','closed_dates','professional_hours','business_hours','clients','professionals','services','subscriptions','public_page_settings','audit_logs'];
  const before={};
  for(const table of tables) before[table]=Number((await db.query(`select count(*) from ${table} where barbershop_id=$1`,[shop.id])).rows[0].count);
  console.log(JSON.stringify({tenant:shop.name,before}));
  if(process.argv.includes('--apply')) {
    for(const table of tables) await db.query(`delete from ${table} where barbershop_id=$1`,[shop.id]);
    if(shop.name==='Bravus Barber') await db.query("update barbershops set name='Minha barbearia',slug='minha-barbearia',data=$2,updated_at=now() where id=$1",[shop.id,JSON.stringify({timezone:'America/Sao_Paulo',notice:0,buffer:0,color:'#ff1426'})]);
    if(owner.name==='Júlio César') await db.query("update users set name='Administrador',phone='' where id=$1",[owner.id]);
    await db.query("delete from plans where (name='FREE' and price=0 and data->>'features'='Gestão básica') or (name='PRO' and price=7990 and data->>'features'='Gestão completa')");
    for(const table of tables) assert.equal(Number((await db.query(`select count(*) from ${table} where barbershop_id=$1`,[shop.id])).rows[0].count),0,table);
    await db.query('commit');
    console.log('Limpeza concluída. Conta, acesso master e vínculo da barbearia preservados. Todas as tabelas de dados demonstrativos do tenant estão vazias.');
  } else { await db.query('rollback'); console.log('Somente leitura: nenhuma alteração.'); }
} catch(error) { await db.query('rollback'); throw error; }
finally { db.release(); await pool.end(); }
