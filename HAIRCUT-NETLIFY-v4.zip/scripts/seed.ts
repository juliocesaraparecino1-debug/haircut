import { randomUUID } from "node:crypto";
import { engine, query, transaction } from "../lib/db";
import { passwordHash } from "../lib/auth";
import { save } from "../lib/repository";
import { today, addDays } from "../lib/types";
async function main() {
  if (process.env.HAIRCUT_MODE === "supabase")
    throw new Error("Seed de demonstração permitido somente no banco local.");
  if (
    (await query("select id from users where email='demo@haircut.local'")).rows
      .length
  ) {
    console.log("Seed já existente.");
    return;
  }
  const user = randomUUID(),
    shop = randomUUID();
  await transaction(async (db) => {
    await db.query(
      "insert into users(id,name,email,phone,password_hash) values($1,$2,$3,$4,$5)",
      [
        user,
        "Júlio César",
        "demo@haircut.local",
        "16991234567",
        passwordHash("HaircutLocal!2026"),
      ],
    );
    await db.query(
      "insert into barbershops(id,name,slug,data) values($1,$2,$3,$4)",
      [
        shop,
        "Bravus Barber",
        "bravus-barber",
        JSON.stringify({
          phone: "16991234567",
          whatsapp: "16991234567",
          address: "Ribeirão Preto, SP",
          description: "Estilo, precisão e cuidado em cada detalhe.",
          notice: 0,
          buffer: 0,
          color: "#ff1426",
          goal: 1000000,
          timezone: "America/Sao_Paulo",
        }),
      ],
    );
    await db.query(
      "insert into barbershop_members(id,barbershop_id,user_id,role) values($1,$2,$3,'OWNER')",
      [randomUUID(), shop, user],
    );
    const services = [];
    for (const [name, price, duration] of [
      ["Corte de Cabelo", 4000, 30],
      ["Barba", 3500, 30],
      ["Corte + Barba", 7000, 60],
      ["Pigmentação", 5500, 45],
      ["Sobrancelha", 1500, 15],
    ] as const)
      services.push(
        await save(db, "services", shop, {
          name,
          price,
          duration,
          description: "Acabamento e cuidado profissional.",
          category: "Barbearia",
          active: true,
        }),
      );
    const pros = [];
    for (const [i, name] of [
      "João",
      "Carlos",
      "Mateus",
      "Lucas",
      "Rafael",
      "Bruno",
    ].entries()) {
      const id = await save(db, "professionals", shop, {
        name,
        specialty: "Barbeiro",
        photo: "ref:" + i,
        active: true,
        commission: 50,
        serviceIds: services,
        userId: i === 0 ? user : "",
      });
      pros.push(id);
      for (const sid of services)
        await db.query("insert into professional_services values($1,$2,$3)", [
          shop,
          id,
          sid,
        ]);
    }
    for (let weekday = 0; weekday < 7; weekday++)
      await save(db, "business_hours", shop, {
        weekday,
        start: 540,
        end: 1140,
        closed: weekday === 0,
        breaks: [{ start: 720, end: 780 }],
      });
    const clients = [];
    for (const [i, name] of [
      "Carlos Silva",
      "André Lima",
      "Marcos Souza",
      "Felipe Costa",
      "Lucas Pereira",
      "Rafael Almeida",
      "Gabriel Santos",
      "Bruno Martins",
    ].entries())
      clients.push(
        await save(db, "clients", shop, {
          name,
          phone: "1699" + String(2600959 + i * 113).padStart(7, "0"),
          email:
            name
              .toLowerCase()
              .split(" ")[0]
              .normalize("NFD")
              .replace(/[\u0300-\u036f]/g, "") + "@example.com",
          photo: "ref:" + i,
          active: true,
          favorite: i < 3,
          notes: i === 0 ? "Prefere máquina 1 nas laterais." : "",
        }),
      );
    for (let i = 0; i < 8; i++) {
      const id = randomUUID(),
        sid = services[i % 3],
        duration = i % 3 === 2 ? 60 : 30,
        price = i % 3 === 2 ? 7000 : i % 3 === 1 ? 3500 : 4000,
        start = i < 4 ? 540 + i * 45 : 780 + (i - 4) * 60;
      const status =
        i === 1 ? "pendente" : i === 3 ? "em atendimento" : "confirmado";
      await db.query(
        "insert into appointments(id,barbershop_id,client_id,professional_id,date,start_minute,end_minute,status,data) values($1,$2,$3,$4,$5,$6,$7,$8,$9)",
        [
          id,
          shop,
          clients[i],
          pros[i % pros.length],
          today(),
          start,
          start + duration,
          status,
          JSON.stringify({
            serviceIds: [sid],
            serviceNames: [
              i % 3 === 2
                ? "Corte + Barba"
                : i % 3 === 1
                  ? "Barba"
                  : "Corte de Cabelo",
            ],
            duration,
            price,
            origin: "interno",
          }),
        ],
      );
      await db.query(
        "insert into appointment_services values($1,$2,$3,$4,$5)",
        [shop, id, sid, price, duration],
      );
    }
    for (let i = 1; i <= 12; i++) {
      const id = randomUUID(),
        date = addDays(today(), -i),
        price = i % 2 ? 4000 : 7000;
      await db.query(
        "insert into appointments(id,barbershop_id,client_id,professional_id,date,start_minute,end_minute,status,data) values($1,$2,$3,$4,$5,600,630,'concluído',$6)",
        [
          id,
          shop,
          clients[i % clients.length],
          pros[i % pros.length],
          date,
          JSON.stringify({
            serviceIds: [services[0]],
            serviceNames: ["Corte de Cabelo"],
            duration: 30,
            price,
            total: price,
            paymentMethod: "Pix",
            origin: "interno",
          }),
        ],
      );
      await save(db, "payments", shop, {
        appointmentId: id,
        clientId: clients[i % clients.length],
        professionalId: pros[i % pros.length],
        date,
        amount: price,
        method: "Pix",
        status: "pago",
      });
      await save(db, "commissions", shop, {
        appointmentId: id,
        professionalId: pros[i % pros.length],
        date,
        revenue: price,
        rate: 50,
        amount: price / 2,
        paid: false,
      });
    }
    await save(db, "subscriptions", shop, {
      name: "FREE",
      price: 0,
      status: "ativo",
    });
    await save(db, "notifications", shop, {
      name: "Bem-vindo ao HAIRCUT. Dados de demonstração carregados.",
      read: false,
    });
    for (const [name, price] of [
      ["FREE", 0],
      ["PRO", 7990],
    ] as const)
      await db.query(
        "insert into plans(id,name,price,data) values($1,$2,$3,$4) on conflict(name) do nothing",
        [
          randomUUID(),
          name,
          price,
          JSON.stringify({
            features: name === "FREE" ? "Gestão básica" : "Gestão completa",
            limit: 0,
          }),
        ],
      );
  });
  console.log("Demonstração local: demo@haircut.local / HaircutLocal!2026");
}
main()
  .then(async () => {
    const e = await engine();
    await e.local?.close();
    await e.pool?.end();
  })
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  });
