import { engine, query } from "../lib/db";
async function main() {
  const email = process.argv[2];
  if (!email?.includes("@"))
    throw new Error("Uso: npm run master -- email@dominio.com");
  const result = await query(
    "update users set master=true where lower(email)=$1 returning id",
    [email.toLowerCase()],
  );
  if (!result.rows.length)
    throw new Error("Crie a conta antes de conceder acesso master.");
  console.log("Acesso master concedido à conta especificada.");
  const e = await engine();
  await e.local?.close();
  await e.pool?.end();
}
main().catch((e) => {
  console.error(e.message);
  process.exitCode = 1;
});
