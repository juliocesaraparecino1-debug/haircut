import { engine, query, transaction } from "../lib/db";
import {
  save,
  book,
  schedule,
  appointment,
  reschedule,
} from "../lib/repository";
import { randomUUID } from "node:crypto";
import { availableSlots } from "../lib/availability";
import { addDays, today, type Shop } from "../lib/types";
async function main() {
  if (process.env.HAIRCUT_MODE !== "supabase")
    throw new Error("Execute com HAIRCUT_MODE=supabase");
  const role = (await query<{ current_user: string }>("select current_user"))
    .rows[0].current_user;
  let checks = 0;
  try {
    await transaction(async (db) => {
      const shop: Shop = {
        id: randomUUID(),
        name: "Teste de conexão temporário",
        slug: "teste-" + randomUUID(),
        data: { buffer: 5, notice: 0 },
        created_at: "",
      };
      await db.query(
        "insert into barbershops(id,name,slug,data) values($1,$2,$3,$4)",
        [shop.id, shop.name, shop.slug, JSON.stringify(shop.data)],
      );
      const sid = await save(db, "services", shop.id, {
        name: "Teste",
        price: 4000,
        duration: 30,
        active: true,
      });
      const pid = await save(db, "professionals", shop.id, {
        name: "Teste",
        serviceIds: [sid],
        active: true,
      });
      let date = addDays(today(), 2);
      while (new Date(date + "T12:00:00Z").getUTCDay() === 0)
        date = addDays(date, 1);
      for (let weekday = 0; weekday < 7; weekday++)
        await save(db, "business_hours", shop.id, {
          weekday,
          start: 540,
          end: 1140,
          closed: false,
          breaks: [],
        });
      const slots = availableSlots(await schedule(db, shop), date, [sid], pid);
      if (!slots.length) throw new Error("Sem disponibilidade");
      checks++;
      const r = await book(
        db,
        shop,
        {
          serviceIds: [sid],
          professionalId: pid,
          date,
          time: 540,
          client: { name: "Teste temporário", phone: "11999991111" },
        },
        "público",
        null,
      );
      if ((await appointment(db, shop.id, r.id)).data.price !== 4000)
        throw new Error("Preço inválido");
      checks++;
      await reschedule(
        db,
        shop,
        await appointment(db, shop.id, r.id),
        date,
        600,
        null,
      );
      checks++;
      if (!(await appointment(db, shop.id, r.id)).start_minute)
        throw new Error("Remarcação inválida");
      throw new Error("ROLLBACK_TESTE_OK");
    });
  } catch (e) {
    if ((e as Error).message !== "ROLLBACK_TESTE_OK") throw e;
  }
  console.log(
    JSON.stringify({
      connection: "Supabase PostgreSQL",
      role,
      tls: "certificado oficial validado",
      checks,
      temporaryData: "rollback concluído",
    }),
  );
  const e = await engine();
  await e.pool?.end();
}
main().catch((e) => {
  console.error(e.message);
  process.exitCode = 1;
});
