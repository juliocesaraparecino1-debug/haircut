import assert from "node:assert/strict";
const base = process.env.APP_URL || "http://127.0.0.1:3000";
const nonce = Date.now().toString();
let count = 0;
function client() {
  let cookie = "";
  return async (path, body, status = 200) => {
    const r = await fetch(base + path, {
      method: body ? "POST" : "GET",
      headers: {
        "Content-Type": "application/json",
        Origin: base,
        ...(cookie ? { Cookie: cookie } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    const set = r.headers.getSetCookie();
    if (set.length) cookie = set.map((s) => s.split(";")[0]).join("; ");
    const data = await r.json();
    assert.equal(r.status, status, `${path}: ${JSON.stringify(data)}`);
    count++;
    return data;
  };
}
const a = client(),
  b = client(),
  guest = client();
await guest("/api/data", undefined, 401);
for (const [i, c] of [a, b].entries()) {
  await c("/api/auth", {
    action: "signup",
    name: "Teste HTTP " + i,
    email: `teste-${nonce}-${i}@example.com`,
    phone: "1199999000" + i,
    password: "TesteHaircut!2026",
    terms: true,
  });
  await c("/api/data", {
    action: "onboard",
    name: "Teste isolado " + nonce + " " + i,
    phone: "1199999000" + i,
    address: "Endereço de teste local",
    logo: "",
    professional: "Profissional de teste",
    service: "Corte de teste",
    price: 4000,
    duration: 30,
    start: 540,
    end: 1140,
  });
}
let state = await a("/api/data");
const second = await b("/api/data");
assert.notEqual(state.shop.id, second.shop.id);
const created = await a("/api/data", {
  action: "save",
  table: "clients",
  data: {
    name: "Cliente de teste",
    phone: "11999991111",
    email: "cliente@example.com",
    active: true,
    favorite: false,
  },
});
await b(
  "/api/data",
  {
    action: "save",
    table: "clients",
    id: created.id,
    data: {
      name: "Tentativa cruzada",
      phone: "11999992222",
      active: true,
      favorite: false,
    },
  },
  404,
);
await b(
  "/api/data",
  { action: "delete", table: "clients", id: created.id },
  404,
);
const pub = await guest("/api/public?slug=" + state.shop.slug);
assert.equal(pub.professionals[0].email, undefined);
assert.equal(pub.professionals[0].userId, undefined);
let d = new Date();
d.setUTCDate(d.getUTCDate() + 2);
while (d.getUTCDay() === 0) d.setUTCDate(d.getUTCDate() + 1);
const date = d.toISOString().slice(0, 10),
  services = state.entities.services.map((s) => s.id),
  pro = state.entities.professionals[0].id;
const slots = await guest(
  "/api/public?" +
    new URLSearchParams({
      slug: state.shop.slug,
      slots: "1",
      date,
      services: services.join(","),
      professional: pro,
    }),
);
assert.ok(slots.length > 2);
const booking = await guest("/api/public", {
  slug: state.shop.slug,
  serviceIds: services,
  professionalId: pro,
  date,
  time: slots[0].time,
  price: 1,
  client: { name: "Visitante de teste", phone: "11988887777" },
});
assert.equal(booking.token.length, 43);
await guest(
  "/api/public",
  {
    slug: state.shop.slug,
    serviceIds: services,
    professionalId: pro,
    date,
    time: slots[0].time,
    client: { name: "Conflito teste", phone: "11988886666" },
  },
  409,
);
const detail = await guest("/api/public?token=" + booking.token);
assert.equal(detail.appointment.data.price, 4000);
assert.equal(detail.appointment.token_hash, undefined);
assert.equal(detail.client.phone, undefined);
await b(
  "/api/data",
  { action: "appointment", id: booking.id, status: "cancelado" },
  404,
);
await guest("/api/public", {
  token: booking.token,
  action: "reschedule",
  date,
  time: slots[3].time,
});
await a("/api/data", {
  action: "appointment",
  id: booking.id,
  status: "em atendimento",
});
await a("/api/data", {
  action: "appointment",
  id: booking.id,
  status: "concluído",
  discount: 500,
  extra: 1000,
  paymentMethod: "Pix",
});
await a(
  "/api/data",
  {
    action: "appointment",
    id: booking.id,
    status: "concluído",
    discount: 500,
    extra: 1000,
    paymentMethod: "Pix",
  },
  409,
);
await guest("/api/public", {
  token: booking.token,
  action: "review",
  rating: 5,
  comment: "Teste funcional concluído.",
});
await guest(
  "/api/public",
  { token: booking.token, action: "review", rating: 5, comment: "Duplicada" },
  409,
);
state = await a("/api/data");
assert.equal(state.entities.payments.length, 1);
assert.equal(state.entities.payments[0].amount, 4500);
assert.equal(state.entities.commissions.length, 1);
assert.equal(state.entities.reviews.length, 1);
const cancelled = await guest("/api/public", {
  slug: state.shop.slug,
  serviceIds: services,
  professionalId: pro,
  date,
  time: slots[0].time,
  client: { name: "Cancelamento teste", phone: "11977776666" },
});
await guest("/api/public", {
  token: cancelled.token,
  action: "cancel",
  reason: "Agendei errado",
});
const available = await guest(
  "/api/public?" +
    new URLSearchParams({
      slug: state.shop.slug,
      slots: "1",
      date,
      services: services.join(","),
      professional: pro,
    }),
);
assert.ok(available.some((s) => s.time === slots[0].time));
await a("/api/master", undefined, 403);
await a("/api/auth", { action: "logout" });
await a("/api/data", undefined, 401);
console.log(
  `PASSOU: ${count} requisições verificadas. Cadastro, onboarding, sessão, CRUD, isolamento, agenda pública, conflito, remarcação, atendimento, pagamentos, comissão, avaliação, cancelamento e master protegido.`,
);
