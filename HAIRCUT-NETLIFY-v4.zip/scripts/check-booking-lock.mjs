import fs from "node:fs/promises";
import { Pool } from "pg";

const uri = new URL(process.env.DATABASE_URL);
uri.search = "";
const pool = new Pool({
  connectionString: uri.toString(),
  ssl: { ca: await fs.readFile("certs/supabase-ca.crt", "utf8"), rejectUnauthorized: true },
});
try {
  const result = await pool.query("select tgname from pg_trigger where tgname='appointments_no_overlap' and tgenabled='O'");
  if (result.rowCount !== 1) throw new Error("A trava de conflito não está ativa.");
  console.log("Trava transacional de conflito de horários ativa.");
} finally {
  await pool.end();
}
