import { randomUUID } from "node:crypto";
import { engine, query } from "../lib/db";
import { passwordHash } from "../lib/auth";
async function main() {
if(process.env.HAIRCUT_MODE !== "local" || !process.env.HAIRCUT_DATA_DIR?.includes("qa")) throw new Error("QA requires its own local database.");
await query("insert into users(id,name,email,password_hash,master) values($1,$2,$3,$4,true) on conflict(email) do nothing",[randomUUID(),"Admin QA","qa-master@haircut.test",passwordHash("QaMaster!2026-OnlyLocal")]);
await (await engine()).local?.close();
console.log("Administrador de testes criado somente no banco local de QA.");
}
main().catch(error=>{console.error(error);process.exitCode=1;});
