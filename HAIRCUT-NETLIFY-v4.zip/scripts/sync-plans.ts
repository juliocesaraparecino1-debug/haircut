import { randomUUID } from "node:crypto";
import { engine, transaction } from "../lib/db";
import { PLANS } from "../lib/plans";
async function main() {
await transaction(async db=>{
  for(const plan of Object.values(PLANS)) await db.query("insert into plans(id,name,price,data) values($1,$2,$3,$4) on conflict(name) do update set price=excluded.price,data=excluded.data",[randomUUID(),plan.name,plan.price,JSON.stringify({planId:plan.id,interval:"month",currency:"BRL",professionalLimit:plan.professionalLimit,features:plan.features})]);
});
const db=await engine();await db.pool?.end();await db.local?.close();
console.log("Catálogo mensal sincronizado: Básico R$ 59,90 e Pro R$ 89,90. Nenhuma cobrança criada.");
}
main().catch(error=>{console.error(error);process.exitCode=1;});
