import assert from 'node:assert/strict';
const base = process.env.APP_URL || 'http://127.0.0.1:3000';
const login = await fetch(base + '/api/auth', {method:'POST', headers:{'Content-Type':'application/json',Origin:base},body:JSON.stringify({action:'login',identifier:process.env.HAIRCUT_DEMO_EMAIL,password:process.env.HAIRCUT_DEMO_PASSWORD})});
assert.equal(login.status,200,'Login');
const cookie = login.headers.getSetCookie().map(x=>x.split(';')[0]).join('; ');
for (const path of ['/api/data','/app/horarios','/api/data']) {
  const started=performance.now();
  const response=await fetch(base+path,{headers:{Cookie:cookie}});
  assert.equal(response.status,200,path);
  const text=await response.text();
  console.log(path,Math.round(performance.now()-started)+'ms',text.length+' bytes');
  if(path==='/api/data') {
    const data=JSON.parse(text);
    console.log(JSON.stringify({shop:data.shop.name,appointments:data.appointments.length,entities:Object.fromEntries(Object.entries(data.entities).map(([k,v])=>[k,v.length]))}));
  }
}
