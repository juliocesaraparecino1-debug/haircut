import assert from "node:assert/strict";
const base = process.env.APP_URL || "http://127.0.0.1:3000";
let count = 0;
const jar = new Map();
async function call(path, body, status = 200, auth = true) {
  const r = await fetch(base + path, {
    method: body ? "POST" : "GET",
    headers: {
      "Content-Type": "application/json",
      Origin: base,
      ...(auth
        ? { Cookie: [...jar].map(([k, v]) => k + "=" + v).join("; ") }
        : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (auth)
    for (const s of r.headers.getSetCookie()) {
      const [pair] = s.split(";");
      const i = pair.indexOf("=");
      jar.set(pair.slice(0, i), pair.slice(i + 1));
    }
  const data = await r.json();
  assert.equal(r.status, status, `${path}: ${JSON.stringify(data)}`);
  count++;
  return data;
}
await call("/api/auth", {
  action: "login",
  identifier: process.env.HAIRCUT_DEMO_EMAIL,
  password: process.env.HAIRCUT_DEMO_PASSWORD,
});
const state = await call("/api/data");
assert.equal(state.mode, "Supabase");
assert.equal(state.shop.slug, "bravus-barber");
assert.ok(state.entities.services.length >= 5);
let d = new Date();
d.setUTCDate(d.getUTCDate() + 4);
while (d.getUTCDay() === 0) d.setUTCDate(d.getUTCDate() + 1);
const date = d.toISOString().slice(0, 10),
  service = state.entities.services.find((s) => s.name === "Corte de Cabelo"),
  pro = state.entities.professionals.find((p) => p.name === "João");
const params = new URLSearchParams({
  slug: state.shop.slug,
  slots: "1",
  date,
  services: service.id,
  professional: pro.id,
});
const slots = await call("/api/public?" + params, undefined, 200, false);
assert.ok(slots.length > 4);
const body = {
  slug: state.shop.slug,
  serviceIds: [service.id],
  professionalId: pro.id,
  date,
  time: slots[0].time,
  client: { name: "Teste de conexão Supabase", phone: "11977770001" },
  notes: "Teste funcional de integração remota",
};
const booked = await call("/api/public", body, 200, false);
await call("/api/public", body, 409, false);
await call(
  "/api/public",
  { action: "reschedule", token: booked.token, date, time: slots[4].time },
  200,
  false,
);
await call("/api/data", {
  action: "appointment",
  id: booked.id,
  status: "em atendimento",
});
await call("/api/data", {
  action: "appointment",
  id: booked.id,
  status: "concluído",
  discount: 0,
  extra: 0,
  paymentMethod: "Pix",
});
await call(
  "/api/data",
  {
    action: "appointment",
    id: booked.id,
    status: "concluído",
    discount: 0,
    extra: 0,
    paymentMethod: "Pix",
  },
  409,
);
await call(
  "/api/public",
  {
    action: "review",
    token: booked.token,
    rating: 5,
    comment: "Teste do fluxo conectado ao Supabase.",
  },
  200,
  false,
);
const another = await call(
  "/api/public",
  { ...body, time: slots[0].time },
  200,
  false,
);
await call(
  "/api/public",
  { action: "cancel", token: another.token, reason: "Teste de cancelamento" },
  200,
  false,
);
const refreshed = await call("/api/data");
assert.ok(
  refreshed.entities.payments.some((p) => p.appointmentId === booked.id),
);
assert.ok(
  refreshed.entities.commissions.some((p) => p.appointmentId === booked.id),
);
assert.equal(
  refreshed.appointments.find((p) => p.id === another.id).status,
  "cancelado",
);
await call("/api/master", undefined, 403);
await call("/api/data", undefined, 401, false);
for (const table of ["users", "clients", "appointments", "barbershops"]) {
  const r = await fetch(
    process.env.NEXT_PUBLIC_SUPABASE_URL +
      "/rest/v1/" +
      table +
      "?select=*&limit=1",
    { headers: { apikey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY } },
  );
  assert.equal(r.status, 200);
  assert.deepEqual(await r.json(), []);
  count++;
}
console.log(
  `PASSOU: ${count} verificações em Supabase real, incluindo login, leitura persistente, disponibilidade, reserva pública, conflito, remarcação, atendimento, pagamento, comissão, avaliação, cancelamento, master protegido e RLS anônimo.`,
);
