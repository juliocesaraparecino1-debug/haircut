import fs from "node:fs/promises";
import { engine } from "../lib/db";
const e = await engine();
if (e.pool) {
  await e.pool.query(
    await fs.readFile("supabase/migrations/001_haircut.sql", "utf8"),
  );
  await e.pool.end();
} else await e.local?.close();
console.log("Migração concluída.");
