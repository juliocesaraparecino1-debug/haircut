import { PGlite } from "@electric-sql/pglite";
import { createClient } from "@supabase/supabase-js";
import { randomBytes } from "node:crypto";
import fs from "node:fs/promises";
import { Pool } from "pg";
import { entities } from "../lib/types";
async function main() {
  const adminKey = process.env.HAIRCUT_SETUP_KEY;
  if (!adminKey)
    throw new Error("Chave temporária de preparação não disponível.");
  const s = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, adminKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const email = "demonstracao@haircut.example",
    password = randomBytes(18).toString("base64url") + "!7a";
  const { data, error } = await s.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: { name: "Júlio César", phone: "16991234567" },
  });
  if (error) throw error;
  const userId = data.user.id;
  const local = new PGlite(".data/postgres");
  await local.waitReady;
  const u = new URL(process.env.DATABASE_URL!);
  u.search = "";
  const pool = new Pool({
    connectionString: u.toString(),
    ssl: {
      ca: await fs.readFile("certs/supabase-ca.crt", "utf8"),
      rejectUnauthorized: true,
    },
  });
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const owner = (
      await local.query<{ id: string; name: string; phone: string }>(
        "select * from users where email='demo@haircut.local'",
      )
    ).rows[0];
    const shop = (
      await local.query<{ id: string }>(
        "select * from barbershops where slug='bravus-barber'",
      )
    ).rows[0];
    if (!owner || !shop) throw new Error("Seed local não encontrado.");
    await client.query(
      "insert into public.users(id,name,email,phone) values($1,$2,$3,$4)",
      [userId, owner.name, email, owner.phone],
    );
    const tables = [
      "barbershops",
      "barbershop_members",
      ...entities,
      "professional_services",
      "appointments",
      "appointment_services",
      "plans",
      "audit_logs",
    ];
    for (const table of tables) {
      const where =
        table === "barbershops"
          ? "id"
          : table === "plans"
            ? null
            : "barbershop_id";
      const rows = await local.query<Record<string, unknown>>(
        `select * from ${table}${where ? " where " + where + "=$1" : ""}`,
        where ? [shop.id] : [],
      );
      for (const raw of rows.rows) {
        const row = { ...raw };
        if (row.user_id === owner.id) row.user_id = userId;
        if (
          row.data &&
          typeof row.data === "object" &&
          (row.data as Record<string, unknown>).userId === owner.id
        )
          row.data = { ...(row.data as Record<string, unknown>), userId };
        const keys = Object.keys(row);
        const values = keys.map((k) =>
          row[k] !== null &&
          typeof row[k] === "object" &&
          !(row[k] instanceof Date)
            ? JSON.stringify(row[k])
            : row[k],
        );
        await client.query(
          `insert into ${table}(${keys.join(",")}) values(${keys.map((_, i) => "$" + (i + 1)).join(",")}) on conflict do nothing`,
          values,
        );
      }
    }
    await client.query("COMMIT");
    const config = await fs.readFile(".env.local", "utf8");
    await fs.writeFile(
      ".env.local",
      config.replace("HAIRCUT_MODE=local", "HAIRCUT_MODE=supabase") +
        `\nHAIRCUT_DEMO_EMAIL=${email}\nHAIRCUT_DEMO_PASSWORD=${password}\n`,
    );
    await fs.writeFile(
      "ACESSO-DA-DEMONSTRACAO.txt",
      `HAIRCUT — demonstração conectada ao Supabase\n\nEndereço: http://127.0.0.1:3000/login\nE-mail: ${email}\nSenha: ${password}\n\nEsta conta acessa apenas a barbearia demonstrativa Bravus Barber.\nEla não tem acesso master. Crie sua própria conta para cadastrar uma barbearia real.\nEste arquivo contém uma senha: mantenha-o privado.\n`,
    );
    console.log(
      "Demonstração migrada. Conta Supabase criada sem enviar e-mail. Acesso salvo no arquivo local.",
    );
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
    await pool.end();
    await local.close();
  }
}
main().catch((e) => {
  console.error(e.message);
  process.exitCode = 1;
});
