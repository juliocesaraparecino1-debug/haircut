import { beforeAll, afterAll, describe, it, expect } from "vitest";
import { PGlite } from "@electric-sql/pglite";
import fs from "node:fs/promises";
import { randomUUID } from "node:crypto";
import type { DB } from "../lib/db";
import {
  save,
  book,
  appointment,
  reschedule,
  checkProfessional,
  records,
  snapshotEntities,
} from "../lib/repository";
import { passwordHash, passwordMatches, admin } from "../lib/auth";
import { availableSlots } from "../lib/availability";
import { schedule } from "../lib/repository";
import { addDays, today, type Shop, type Appointment } from "../lib/types";
const pg = new PGlite(),
  db = pg as DB;
let shop: Shop, other: Shop, pro: string, service: string;
let date = addDays(today(), 2);
while (new Date(date + "T12:00:00Z").getUTCDay() === 0) date = addDays(date, 1);
beforeAll(async () => {
  await pg.exec(
    await fs.readFile("supabase/migrations/001_haircut.sql", "utf8"),
  );
  shop = {
    id: randomUUID(),
    name: "A",
    slug: "a",
    data: { buffer: 0, notice: 0 },
    created_at: "",
  };
  other = { ...shop, id: randomUUID(), name: "B", slug: "b" };
  for (const s of [shop, other])
    await db.query(
      "insert into barbershops(id,name,slug,data) values($1,$2,$3,$4)",
      [s.id, s.name, s.slug, JSON.stringify(s.data)],
    );
  service = await save(db, "services", shop.id, {
    name: "Corte",
    duration: 30,
    price: 4000,
    active: true,
  });
  pro = await save(db, "professionals", shop.id, {
    name: "João",
    serviceIds: [service],
    active: true,
  });
  for (let weekday = 0; weekday < 7; weekday++)
    await save(db, "business_hours", shop.id, {
      weekday,
      start: 540,
      end: 1140,
      closed: false,
      breaks: [],
    });
}, 30000);
afterAll(() => pg.close());
describe("Persistência, transações e segurança", () => {
  it("snapshot em uma consulta mantém o isolamento e as tabelas vazias", async () => {
    const foreignId = await save(db, "services", other.id, { name: "Serviço de outra barbearia" });
    let queries = 0;
    const counted: DB = { query: (sql, args) => { queries++; return db.query(sql, args); } };
    const result = await snapshotEntities(counted, shop.id);
    expect(queries).toBe(1);
    expect(result.services.some((row) => row.id === service)).toBe(true);
    expect(result.services.some((row) => row.id === foreignId)).toBe(false);
    expect(result.clients).toEqual([]);
    expect(result.notifications).toEqual([]);
  });
  it("cria reserva persistente e impede duas reservas simultâneas", async () => {
    const body = {
      serviceIds: [service],
      professionalId: pro,
      date,
      time: 540,
      client: { name: "Carlos", phone: "16999990001" },
    };
    const result = await Promise.allSettled([
      pg.transaction((t) => book(t as DB, shop, body, "público", null)),
      pg.transaction((t) => book(t as DB, shop, body, "público", null)),
    ]);
    expect(result.filter((x) => x.status === "fulfilled")).toHaveLength(1);
    expect(result.filter((x) => x.status === "rejected")).toHaveLength(1);
    const persisted = (
      await db.query<Appointment>(
        "select * from appointments where barbershop_id=$1",
        [shop.id],
      )
    ).rows;
    expect(persisted).toHaveLength(1);
    expect(persisted[0].data.price).toBe(4000);
  });
  it("protege leitura, atualização e referência entre empresas", async () => {
    const c = await save(db, "clients", other.id, {
      name: "Outra empresa",
      phone: "11999887766",
    });
    await expect(
      save(db, "clients", shop.id, { name: "Intruso" }, c),
    ).rejects.toThrow("não encontrado");
    await expect(
      book(
        db,
        shop,
        {
          serviceIds: [service],
          professionalId: pro,
          date,
          time: 600,
          clientId: c,
        },
        "interno",
        null,
      ),
    ).rejects.toThrow("Cliente inválido");
    const own = await records(db, "clients", shop.id);
    expect(own.some((x) => x.id === c)).toBe(false);
    const a = (
      await db.query<Appointment>("select * from appointments limit 1")
    ).rows[0];
    await expect(appointment(db, other.id, a.id)).rejects.toThrow(
      "não encontrado",
    );
  });
  it("remarca atomicamente e cancelamento libera disponibilidade", async () => {
    const a = (
      await db.query<Appointment>(
        "select * from appointments where barbershop_id=$1 limit 1",
        [shop.id],
      )
    ).rows[0];
    await pg.transaction((t) => reschedule(t as DB, shop, a, date, 600, null));
    const changed = await appointment(db, shop.id, a.id);
    expect(changed.start_minute).toBe(600);
    await db.query("update appointments set status='cancelado' where id=$1", [
      a.id,
    ]);
    expect(
      availableSlots(await schedule(db, shop), date, [service], pro).some(
        (s) => s.time === 600,
      ),
    ).toBe(true);
    await expect(
      reschedule(
        db,
        shop,
        await appointment(db, shop.id, a.id),
        date,
        630,
        null,
      ),
    ).rejects.toThrow("não pode ser remarcado");
  });
  it("recusa dados inválidos e não aceita preço enviado pelo visitante", async () => {
    await expect(
      book(
        db,
        shop,
        {
          serviceIds: [service],
          date,
          time: 630,
          client: { name: "", phone: "1" },
        },
        "público",
        null,
      ),
    ).rejects.toThrow();
    const r = await book(
      db,
      shop,
      {
        serviceIds: [service],
        date,
        time: 630,
        price: 1,
        client: { name: "Teste preço", phone: "16999990002" },
      },
      "público",
      null,
    );
    expect((await appointment(db, shop.id, r.id)).data.price).toBe(4000);
    expect(r.token).toHaveLength(43);
  });
  it("aplica permissões de profissional e administrador", () => {
    expect(() => admin("PROFESSIONAL")).toThrow();
    expect(() => admin("CLIENT")).toThrow();
    expect(() => admin("OWNER")).not.toThrow();
    expect(() =>
      checkProfessional(
        "PROFESSIONAL",
        { id: pro, created_at: "", userId: "owner" },
        "intruder",
      ),
    ).toThrow();
    expect(() =>
      checkProfessional(
        "PROFESSIONAL",
        { id: pro, created_at: "", userId: "owner" },
        "owner",
      ),
    ).not.toThrow();
  });
  it("senhas têm salt e hash e comparação correta", () => {
    const hash = passwordHash("Haircut!12345");
    expect(hash).not.toContain("Haircut!12345");
    expect(passwordMatches("Haircut!12345", hash)).toBe(true);
    expect(passwordMatches("errada", hash)).toBe(false);
  });
  it("RLS impede leitura entre tenants e bloqueia escritas diretas", async () => {
    const user = randomUUID();
    await db.query("insert into users(id,name,email) values($1,$2,$3)", [
      user,
      "Usuário",
      "rls@test.local",
    ]);
    await db.query(
      "insert into barbershop_members(id,barbershop_id,user_id,role) values($1,$2,$3,'OWNER')",
      [randomUUID(), shop.id, user],
    );
    await pg.exec(
      "create role rls_tester; grant usage on schema public to rls_tester; grant select,insert,update,delete on all tables in schema public to rls_tester;",
    );
    await pg.transaction(async (t) => {
      await t.exec("set local role rls_tester");
      await t.query("select set_config('request.jwt.claim.sub',$1,true)", [
        user,
      ]);
      const result = await t.query<{ barbershop_id: string }>(
        "select barbershop_id from clients",
      );
      expect(result.rows.length).toBeGreaterThan(0);
      expect(result.rows.every((x) => x.barbershop_id === shop.id)).toBe(true);
      const sessions = await t.query("select * from sessions");
      expect(sessions.rows).toHaveLength(0);
    });
    await expect(
      pg.transaction(async (t) => {
        await t.exec("set local role rls_tester");
        await t.query("select set_config('request.jwt.claim.sub',$1,true)", [
          user,
        ]);
        await t.query(
          "insert into clients(id,barbershop_id,data) values($1,$2,$3)",
          [randomUUID(), other.id, "{}"],
        );
      }),
    ).rejects.toThrow();
  });
});
