import { beforeAll, afterAll, describe, expect, it } from "vitest";
import { PGlite } from "@electric-sql/pglite";
import fs from "node:fs/promises";
import { randomUUID } from "node:crypto";
import type { DB } from "../lib/db";
import { PLANS,hasPro,nextMonthlyDate } from "../lib/plans";
import { subscriptionFor,requestPlan,activateMonthly,assertProfessionalLimit,writeSubscription } from "../lib/billing";
import { slugFromName,availableShopSlug } from "../lib/shop-link";
import { clientsToRecover } from "../lib/retention";
import type { Appointment } from "../lib/types";
const pg=new PGlite(),db=pg as DB;
beforeAll(async()=>{await pg.exec(await fs.readFile("supabase/migrations/001_haircut.sql","utf8"));});
afterAll(async()=>{await pg.close();});
async function tenant(name="Barbearia São João") { const id=randomUUID(),slug=await availableShopSlug(db,name);await db.query("insert into barbershops(id,name,slug) values($1,$2,$3)",[id,name,slug]);return {id,slug}; }
describe("Links e assinaturas",()=>{
  it("gera link legível, trata acentos e reserva nomes repetidos",async()=>{
    expect(slugFromName("  Barbearia São João & Filhos  ")).toBe("barbearia-sao-joao-filhos");
    expect(slugFromName("💈💈")).toBe("barbearia");
    const first=await tenant();const second=await tenant();
    expect(first.slug).toBe("barbearia-sao-joao");expect(second.slug).toBe("barbearia-sao-joao-2");
    await db.query("update barbershops set data=$1 where id=$2",[JSON.stringify({slugAliases:["nome-antigo"]}),first.id]);
    expect(await availableShopSlug(db,"Nome antigo")).toBe("nome-antigo-2");
  });
  it("preços estão em centavos e o pedido do Pro não libera acesso sozinho",async()=>{
    const shop=await tenant("Planos");
    expect(PLANS.basico.price).toBe(5990);expect(PLANS.pro.price).toBe(8990);
    await requestPlan(db,shop.id,"pro");const sub=await subscriptionFor(db,shop.id);
    expect(sub.requestedPlan).toBe("pro");expect(hasPro(sub)).toBe(false);expect(sub.paymentStatus).toBe("not_collected");
  });
  it("ativação mensal, renovação e expiração preservam a ausência de cobrança",async()=>{
    const shop=await tenant("Ciclo");const now=new Date("2026-01-31T10:00:00Z");
    const sub=await activateMonthly(db,shop.id,"pro",now);
    expect(sub.currentPeriodEnd).toBe("2026-02-28T10:00:00.000Z");expect(hasPro(sub,now)).toBe(true);
    expect(hasPro(sub,new Date("2026-02-28T10:00:01Z"))).toBe(false);
    const renewed=await activateMonthly(db,shop.id,"pro",new Date("2026-02-15T10:00:00Z"));
    expect(renewed.currentPeriodEnd).toBe("2026-03-28T10:00:00.000Z");expect(renewed.paymentStatus).toBe("not_collected");
    expect(nextMonthlyDate(new Date("2028-01-31T10:00:00Z")).toISOString()).toBe("2028-02-29T10:00:00.000Z");
  });
  it("limite Básico no servidor e Pro liberado somente durante o período válido",async()=>{
    const shop=await tenant("Limites");const ids=[randomUUID(),randomUUID(),randomUUID()];
    for(const id of ids)await db.query("insert into professionals(id,barbershop_id,data) values($1,$2,$3)",[id,shop.id,JSON.stringify({active:true})]);
    await expect(assertProfessionalLimit(db,shop.id)).rejects.toThrow("3 profissionais");
    await expect(assertProfessionalLimit(db,shop.id,ids[0])).resolves.toBeUndefined();
    await activateMonthly(db,shop.id,"pro");await expect(assertProfessionalLimit(db,shop.id)).resolves.toBeUndefined();
    const sub=await subscriptionFor(db,shop.id);sub.currentPeriodEnd="2020-01-01T00:00:00Z";await writeSubscription(db,shop.id,sub);
    await expect(assertProfessionalLimit(db,shop.id)).rejects.toThrow("3 profissionais");
  });
  it("uma ativação Básica nova não duplica assinatura",async()=>{
    const shop=await tenant("Unicidade");await activateMonthly(db,shop.id,"basico");
    expect((await db.query("select id from subscriptions where barbershop_id=$1",[shop.id])).rows).toHaveLength(1);
  });
  it("recuperação ignora inativos e clientes que já têm reserva",()=>{
    const clients=[{id:"a",created_at:"",name:"Ana",active:true},{id:"b",created_at:"",active:false},{id:"c",created_at:"",active:true}];
    const appointment=(client:string,status:string,date:string)=>({client_id:client,status,date}) as Appointment;
    const result=clientsToRecover(clients,[appointment("a","concluído","2026-01-01"),appointment("b","concluído","2026-01-01"),appointment("c","concluído","2026-01-01"),appointment("c","confirmado","2026-05-01")],"2026-04-01");
    expect(result.map(row=>row.client.id)).toEqual(["a"]);expect(result[0].days).toBe(90);
  });
});
