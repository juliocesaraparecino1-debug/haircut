import { describe, it, expect } from "vitest";
import { availableSlots, overlaps, type Schedule } from "../lib/availability";
import type { Appointment } from "../lib/types";
const now = new Date("2030-01-07T08:00:00-03:00");
function fixture(): Schedule {
  return {
    shop: {
      id: "shop",
      name: "Test",
      slug: "test",
      created_at: "",
      data: { notice: 0, buffer: 0 },
    },
    professionals: [
      { id: "pro", created_at: "", active: true, serviceIds: ["cut", "beard"] },
    ],
    services: [
      { id: "cut", created_at: "", active: true, duration: 30, price: 4000 },
      { id: "beard", created_at: "", active: true, duration: 30, price: 3500 },
    ],
    business_hours: [
      {
        id: "hours",
        created_at: "",
        weekday: 1,
        start: 540,
        end: 720,
        closed: false,
        breaks: [],
      },
    ],
    professional_hours: [],
    schedule_blocks: [],
    closed_dates: [],
    appointments: [],
  };
}
const slots = (s: Schedule, ids = ["cut"]) =>
  availableSlots(s, "2030-01-07", ids, "pro", undefined, now);
describe("Disponibilidade centralizada", () => {
  it("considera limites e soma durações e valores", () => {
    const r = slots(fixture(), ["cut", "beard"]);
    expect(r[0]).toMatchObject({ time: 540, duration: 60, price: 7500 });
    expect(r.at(-1)?.time).toBe(660);
  });
  it("limites adjacentes não são conflitos", () => {
    expect(overlaps(540, 570, 570, 600)).toBe(false);
    expect(overlaps(540, 571, 570, 600)).toBe(true);
  });
  it("bloqueia colisões e libera cancelamento", () => {
    const s = fixture();
    s.appointments = [
      {
        id: "a",
        date: "2030-01-07",
        professional_id: "pro",
        start_minute: 570,
        end_minute: 600,
        status: "confirmado",
      } as Appointment,
    ];
    expect(slots(s).map((s) => s.time)).not.toContain(570);
    expect(slots(s).map((s) => s.time)).not.toContain(555);
    s.appointments[0].status = "cancelado";
    expect(slots(s).map((s) => s.time)).toContain(570);
  });
  it("combina expediente do profissional, pausas e bloqueios", () => {
    const s = fixture();
    s.professional_hours = [
      {
        id: "own",
        created_at: "",
        professionalId: "pro",
        weekday: 1,
        start: 600,
        end: 720,
        breaks: [{ start: 630, end: 660 }],
      },
    ];
    s.schedule_blocks = [
      {
        id: "b",
        created_at: "",
        professionalId: "pro",
        date: "2030-01-07",
        start: 660,
        end: 690,
      },
    ];
    expect(slots(s).map((x) => x.time)).toEqual([600, 690]);
  });
  it("respeita feriados e folgas", () => {
    const s = fixture();
    s.closed_dates = [{ id: "closed", created_at: "", date: "2030-01-07" }];
    expect(slots(s)).toEqual([]);
    s.closed_dates = [];
    s.professional_hours = [
      {
        id: "own",
        created_at: "",
        professionalId: "pro",
        weekday: 1,
        closed: true,
      },
    ];
    expect(slots(s)).toEqual([]);
  });
  it("respeita antecedência e intervalo inclusive final de expediente", () => {
    const s = fixture();
    s.shop.data.notice = 120;
    s.shop.data.buffer = 15;
    const result = slots(s);
    expect(result[0].time).toBe(600);
    expect(result.at(-1)?.time).toBe(675);
  });
  it("não reserva serviço incompatível ou inativo", () => {
    const s = fixture();
    s.professionals[0].serviceIds = ["cut"];
    expect(slots(s, ["beard"])).toEqual([]);
    s.services[0].active = false;
    expect(slots(s)).toEqual([]);
  });
  it("remarcação ignora somente o próprio atendimento", () => {
    const s = fixture();
    s.appointments = [
      {
        id: "a",
        date: "2030-01-07",
        professional_id: "pro",
        start_minute: 540,
        end_minute: 570,
        status: "confirmado",
      } as Appointment,
    ];
    expect(slots(s)[0].time).toBe(570);
    expect(
      availableSlots(s, "2030-01-07", ["cut"], "pro", "a", now)[0].time,
    ).toBe(540);
  });
  it("não permite datas inválidas, dia sem expediente ou profissional inexistente", () => {
    const s = fixture();
    expect(
      availableSlots(s, "2030-02-30", ["cut"], undefined, undefined, now),
    ).toEqual([]);
    expect(
      availableSlots(s, "2030-01-08", ["cut"], undefined, undefined, now),
    ).toEqual([]);
    expect(
      availableSlots(s, "2030-01-07", ["cut"], "unknown", undefined, now),
    ).toEqual([]);
  });
});
