import { afterEach, describe, expect, it, vi } from "vitest";
import { checkOrigin } from "../lib/auth";

afterEach(() => vi.unstubAllEnvs());
describe("Proteção de origem no acesso pelo celular", () => {
  it("permite somente o endereço local explicitamente configurado", () => {
    vi.stubEnv("APP_URL", "http://127.0.0.1:3000");
    vi.stubEnv("HAIRCUT_ALLOWED_ORIGINS", "http://192.168.3.96:3000");
    const request = (origin: string) => new Request("http://0.0.0.0:3000/api/auth", { method: "POST", headers: { origin } });
    expect(() => checkOrigin(request("http://192.168.3.96:3000"))).not.toThrow();
    expect(() => checkOrigin(request("http://127.0.0.1:3000"))).not.toThrow();
    expect(() => checkOrigin(request("https://unexpected.example"))).toThrow("Origem não permitida");
    expect(() => checkOrigin(request("http://192.168.3.96:3001"))).toThrow("Origem não permitida");
  });
});
