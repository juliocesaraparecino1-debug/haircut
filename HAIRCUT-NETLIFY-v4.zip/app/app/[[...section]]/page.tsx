// The persistent dashboard layout renders the screen selected by usePathname.
export default function DashboardPage() {
  return null;
}
