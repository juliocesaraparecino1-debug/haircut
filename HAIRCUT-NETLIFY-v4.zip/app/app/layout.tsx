import { redirect } from "next/navigation";
import { sessionUser } from "@/lib/auth";
import { query } from "@/lib/db";
import { Panel } from "@/components/panel";

export const dynamic = "force-dynamic";

export default async function PanelLayout({ children }: { children: React.ReactNode }) {
  const user = await sessionUser();
  if (!user) redirect("/login");
  const membership = await query("select id from barbershop_members where user_id=$1 limit 1", [user.id]);
  if (!membership.rows.length) redirect("/primeiro-acesso");
  return <><Panel />{children}</>;
}
