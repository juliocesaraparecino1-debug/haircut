import { NextResponse } from "next/server";
import { supabase, sessionUser, siteOrigin } from "@/lib/auth";
export async function GET(req: Request) {
  const u = new URL(req.url),
    code = u.searchParams.get("code");
  if (code) {
    const { error } = await (
      await supabase()
    ).auth.exchangeCodeForSession(code);
    if (!error) {
      const user=await sessionUser();
      return NextResponse.redirect(
        new URL(
          u.searchParams.get("next") === "/nova-senha" ? "/nova-senha" : user?.master ? "/master" : user ? "/app" : "/verificar-mfa",
          siteOrigin(req),
        ),
      );
    }
  }
  return NextResponse.redirect(new URL("/login?error=callback", siteOrigin(req)));
}
