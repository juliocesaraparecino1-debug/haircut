import { NextResponse } from "next/server";
import { z } from "zod";
import { AppError, checkOrigin, sessionUser } from "@/lib/auth";
import { query } from "@/lib/db";
import { tenantTx } from "@/lib/auth";
import { activateMonthly } from "@/lib/billing";
import { audit } from "@/lib/repository";
async function guard() {
  const u = await sessionUser();
  if (!u?.master)
    throw new AppError("Área exclusiva da administração HAIRCUT.", 403);
  return u;
}
export async function GET() {
  try {
    await guard();
    const [shops, users, subs, plans, tickets, counts] = await Promise.all([
      query(
        "select b.*,count(a.id)::int as appointments from barbershops b left join appointments a on a.barbershop_id=b.id group by b.id order by b.created_at desc",
      ),
      query(
        "select id,name,email,created_at from users order by created_at desc",
      ),
      query(
        "select s.*,b.name as shop_name from subscriptions s join barbershops b on b.id=s.barbershop_id",
      ),
      query("select * from plans order by price"),
      query(
        "select s.*,b.name as shop_name from support_tickets s join barbershops b on b.id=s.barbershop_id",
      ),
      query("select count(*)::int as count from appointments"),
    ]);
    return NextResponse.json({
      shops: shops.rows,
      users: users.rows,
      subscriptions: subs.rows,
      plans: plans.rows,
      tickets: tickets.rows,
      appointments: counts.rows[0].count,
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Erro" },
      { status: 403 },
    );
  }
}
export async function POST(req: Request) {
  try {
    checkOrigin(req);
    const user=await guard();
    const b = await req.json();
    if(b.action === "activate-subscription") {
      const tenant=z.uuid().parse(b.barbershopId), planId=z.enum(["basico","pro"]).parse(b.planId);
      await tenantTx(tenant,async db=>{
        if(!(await db.query("select id from barbershops where id=$1",[tenant])).rows.length) throw new AppError("Barbearia não encontrada.",404);
        await activateMonthly(db,tenant,planId);
        await audit(db,tenant,user.id,"assinatura.ativacao-manual-sem-cobranca",tenant);
      });
      return NextResponse.json({message:"Acesso liberado por um mês. Nenhum pagamento foi registrado."});
    }
    if (b.action === "ticket") {
      await query(
        "update support_tickets set data=data||$1::jsonb,updated_at=now() where id=$2",
        [
          JSON.stringify({
            status: z
              .enum(["aberto", "em andamento", "resolvido"])
              .parse(b.status),
          }),
          z.uuid().parse(b.id),
        ],
      );
    } else throw new AppError("Ação inválida.");
    return NextResponse.json({ message: "Atualizado." });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Erro" },
      { status: e instanceof AppError ? e.status : 400 },
    );
  }
}
