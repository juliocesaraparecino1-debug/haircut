import { NextResponse } from "next/server";
import { z } from "zod";
import { engine, query } from "@/lib/db";
import { AppError, checkOrigin, hash, rateLimit, tenantTx } from "@/lib/auth";
import {
  audit,
  book,
  notify,
  publicData,
  publicShop,
  records,
  reschedule,
  save,
  schedule,
} from "@/lib/repository";
import { availableSlots } from "@/lib/availability";
import type { Appointment, Shop } from "@/lib/types";
import { requirePro } from "@/lib/billing";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
async function tokenAppointment(token: string) {
  if (!/^[\w-]{43}$/.test(token)) throw new AppError("Link inválido.", 404);
  const row = (
    await query<Appointment>("select * from appointments where token_hash=$1", [
      hash(token),
    ])
  ).rows[0];
  if (!row) throw new AppError("Link inválido.", 404);
  const shop = (
    await query<Shop>("select * from barbershops where id=$1", [
      row.barbershop_id,
    ])
  ).rows[0];
  return { a: row, shop };
}
function fail(e: unknown) {
  return NextResponse.json(
    {
      error: e instanceof AppError ? e.message : "Confira os dados informados.",
    },
    { status: e instanceof AppError ? e.status : 400 },
  );
}
export async function GET(req: Request) {
  try {
    const u = new URL(req.url),
      db = (await engine()).db;
    if (u.searchParams.has("token")) {
      const { a, shop } = await tokenAppointment(u.searchParams.get("token")!);
      const pub = await publicData(db, shop);
      if (u.searchParams.has("slots"))
        return NextResponse.json(
          availableSlots(
            await schedule(db, shop),
            u.searchParams.get("date") || "",
            a.data.serviceIds,
            a.professional_id,
            a.id,
          ),
        );
      const client = (await records(db, "clients", shop.id)).find(
        (x) => x.id === a.client_id,
      );
      return NextResponse.json(
        {
          appointment: {
            ...a,
            token_hash: undefined,
            data: { ...a.data, notes: undefined },
          },
          shop: pub.shop,
          professional: pub.professionals.find(
            (x) => x.id === a.professional_id,
          ),
          client: { name: client?.name },
          reviewed: (await records(db, "reviews", shop.id)).some(
            (x) => x.appointmentId === a.id,
          ),
        },
        { headers: { "Cache-Control": "no-store" } },
      );
    }
    const shop = await publicShop(u.searchParams.get("slug") || "");
    if (u.searchParams.has("slots"))
      return NextResponse.json(
        availableSlots(
          await schedule(db, shop),
          u.searchParams.get("date") || "",
          (u.searchParams.get("services") || "").split(","),
          u.searchParams.get("professional") || undefined,
        ),
      );
    return NextResponse.json(await publicData(db, shop));
  } catch (e) {
    return fail(e);
  }
}
export async function POST(req: Request) {
  try {
    checkOrigin(req);
    const b = await req.json();
    if (b.token) {
      const { a, shop } = await tokenAppointment(String(b.token));
      await rateLimit("token:" + a.id, 50);
      const result = await tenantTx(shop.id, async (db) => {
        const current = (
          await db.query<Appointment>(
            "select * from appointments where id=$1 and barbershop_id=$2",
            [a.id, shop.id],
          )
        ).rows[0];
        if (b.action === "cancel") {
          if (
            !["confirmado", "pendente", "aguardando"].includes(current.status)
          )
            throw new AppError("Este atendimento não pode ser cancelado.", 409);
          await db.query(
            "update appointments set status='cancelado',data=data||$1::jsonb,updated_at=now() where id=$2 and barbershop_id=$3",
            [
              JSON.stringify({
                cancelReason: String(b.reason || "").slice(0, 1000),
              }),
              a.id,
              shop.id,
            ],
          );
          await notify(db, shop.id, "Cliente cancelou um agendamento", a.id);
          await audit(db, shop.id, null, "cliente.cancelamento", a.id);
          return { message: "Agendamento cancelado." };
        }
        if (b.action === "reschedule") {
          if (
            !["confirmado", "pendente", "aguardando"].includes(current.status)
          )
            throw new AppError("Remarcação indisponível.", 409);
          await reschedule(
            db,
            shop,
            current,
            z
              .string()
              .regex(/^\d{4}-\d{2}-\d{2}$/)
              .parse(b.date),
            z.number().int().parse(b.time),
            null,
          );
          return { message: "Agendamento remarcado." };
        }
        if (b.action === "review") {
          if (current.status !== "concluído")
            throw new AppError(
              "A avaliação estará disponível após o atendimento.",
            );
          if (
            (await records(db, "reviews", shop.id)).some(
              (x) => x.appointmentId === a.id,
            )
          )
            throw new AppError("Você já avaliou este atendimento.", 409);
          await save(db, "reviews", shop.id, {
            appointmentId: a.id,
            professionalId: a.professional_id,
            rating: z.number().int().min(1).max(5).parse(b.rating),
            comment: z
              .string()
              .max(2000)
              .parse(b.comment || ""),
          });
          await notify(db, shop.id, "Nova avaliação recebida", a.id);
          return { message: "Obrigado pela avaliação!" };
        }
        throw new AppError("Ação inválida.");
      });
      return NextResponse.json(result);
    }
    const shop = await publicShop(z.string().max(150).parse(b.slug));
    await rateLimit(
      "public:" +
        shop.id +
        ":" +
        String(b.client?.phone || b.phone || "").replace(/\D/g, ""),
      12,
    );
    if (b.action === "waitlist") {
      await requirePro((await engine()).db,shop.id);
      const v = z
        .object({
          name: z.string().min(2).max(200),
          phone: z.string().min(10).max(20),
          date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
          period: z.enum(["manhã", "tarde", "qualquer"]),
          professionalId: z.string().max(40),
        })
        .parse(b);
      const parsedDate = new Date(v.date + "T12:00:00Z");
      if(Number.isNaN(parsedDate.getTime()) || parsedDate.toISOString().slice(0,10)!==v.date) throw new AppError("Data inválida.");
      if(v.professionalId && !(await records((await engine()).db,"professionals",shop.id)).some(p=>p.id===v.professionalId && p.active!==false)) throw new AppError("Profissional inválido.");
      await tenantTx(shop.id,async db=>{
        const phone=v.phone.replace(/\D/g,"");
        if(phone.length<10 || phone.length>15) throw new AppError("Telefone inválido.");
        const found=(await db.query("select id from waitlist where barbershop_id=$1 and data->>'phone'=$2 and data->>'date'=$3",[shop.id,phone,v.date])).rows[0];
        if(found) throw new AppError("Você já está na lista de espera deste dia.",409);
        await save(db,"waitlist",shop.id,{...v,phone});
      });
      return NextResponse.json({
        message:
          "Você entrou na lista de espera. A barbearia poderá entrar em contato.",
      });
    }
    const result = await tenantTx(shop.id, (db) =>
      book(db, shop, b, "público", null),
    );
    return NextResponse.json(result);
  } catch (e) {
    return fail(e);
  }
}
