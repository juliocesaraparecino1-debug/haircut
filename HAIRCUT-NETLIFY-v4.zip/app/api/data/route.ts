import { NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import { z, ZodError } from "zod";
import { engine, query, remote, transaction } from "@/lib/db";
import {
  AppError,
  admin,
  checkOrigin,
  context,
  sessionUser,
  tenantTx,
} from "@/lib/auth";
import {
  appointment,
  audit,
  book,
  checkProfessional,
  notify,
  records,
  reschedule,
  save,
  schedule,
  snapshotEntities,
} from "@/lib/repository";
import { availableSlots } from "@/lib/availability";
import {
  clientSchema,
  professionalSchema,
  serviceSchema,
} from "@/lib/validation";
import { entities, type EntityName, type Appointment } from "@/lib/types";
import { assertProfessionalLimit, subscriptionFor, requestPlan, writeSubscription, requirePro } from "@/lib/billing";
import { defaultSubscription, hasPro } from "@/lib/plans";
import { availableShopSlug } from "@/lib/shop-link";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function fail(e: unknown) {
  return NextResponse.json(
    {
      error:
        e instanceof ZodError
          ? e.issues[0].message
          : e instanceof AppError
            ? e.message
            : "Não foi possível salvar. Confira os dados e tente novamente.",
    },
    { status: e instanceof AppError ? e.status : 400 },
  );
}
export async function GET(req: Request) {
  try {
    const c = await context(),
      db = (await engine()).db;
    const url = new URL(req.url);
    if (url.searchParams.get("slots")) {
      const s = await schedule(db, c.shop);
      return NextResponse.json(
        availableSlots(
          s,
          url.searchParams.get("date") || "",
          (url.searchParams.get("services") || "").split(","),
          url.searchParams.get("professional") || undefined,
          url.searchParams.get("ignore") || undefined,
        ),
      );
    }
    if (url.searchParams.get("sessions")) {
      return NextResponse.json(
        remote()
          ? { remote: true, sessions: [] }
          : {
              sessions: (
                await query(
                  "select id,agent,created_at,expires_at from sessions where user_id=$1 and expires_at>now()",
                  [c.user.id],
                )
              ).rows,
            },
      );
    }
    const data = await snapshotEntities(db, c.shop.id);
    const subscription = { ...defaultSubscription(), ...data.subscriptions[0] };
    let appts = (
      await query<Appointment>(
        "select * from appointments where barbershop_id=$1 order by date desc,start_minute",
        [c.shop.id],
      )
    ).rows;
    if (c.role === "CLIENT")
      throw new AppError("Use o seu link público de agendamento.", 403);
    if (c.role === "PROFESSIONAL") {
      const pro = data.professionals.find((p) => p.userId === c.user.id);
      appts = appts.filter((a) => a.professional_id === pro?.id);
      data.clients = data.clients.filter((x) =>
        appts.some((a) => a.client_id === x.id),
      );
      for (const table of [
        "payments",
        "commissions",
        "subscriptions",
        "support_tickets",
        "notifications",
      ] as EntityName[])
        data[table] = [];
    }
    if (!hasPro(subscription)) { data.commissions = []; data.waitlist = []; }
    return NextResponse.json(
      {
        ...c,
        subscription,
        publicBookingUrl: `${process.env.HAIRCUT_PUBLIC_URL || process.env.APP_URL || new URL(req.url).origin}/agendar/${c.shop.slug}`,
        mode: remote() ? "Supabase" : "Local • banco persistente",
        appointments: appts,
        entities: data,
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (e) {
    return fail(e);
  }
}
export async function POST(req: Request) {
  try {
    checkOrigin(req);
    const b = await req.json();
    if (b.action === "onboard") {
      const user = await sessionUser();
      if (!user) throw new AppError("Entre na sua conta.", 401);
      const input = z
        .object({
          name: z.string().trim().min(2).max(100),
          phone: z.string().min(10).max(20),
          address: z.string().max(500),
          logo: z.string().max(2_500_000).refine(v => !v || v.startsWith("data:image/"), "Envie o logo pelo campo de upload.").default(""),
          professional: z.string().min(2).max(100),
          service: z.string().min(2).max(100),
          price: z.number().int().min(0),
          duration: z.number().int().min(5).max(720),
          start: z.number().int().min(0),
          end: z.number().int().max(1440),
        })
        .parse(b);
      if (input.end <= input.start)
        throw new AppError("Horário final deve ser após o inicial.");
      const id = randomUUID();
      await transaction(async (db) => {
        await db.query("select id from users where id=$1 for update", [
          user.id,
        ]);
        if (
          (
            await db.query(
              "select id from barbershop_members where user_id=$1",
              [user.id],
            )
          ).rows.length
        )
          throw new AppError("Sua barbearia já foi cadastrada.");
        const slug = await availableShopSlug(db,input.name);
        await db.query(
          "insert into barbershops(id,name,slug,data) values($1,$2,$3,$4)",
          [
            id,
            input.name,
            slug,
            JSON.stringify({
              phone: input.phone,
              whatsapp: input.phone,
              address: input.address,
              logo: input.logo,
              notice: 30,
              buffer: 0,
              timezone: "America/Sao_Paulo",
            }),
          ],
        );
        await db.query(
          "insert into barbershop_members(id,barbershop_id,user_id,role) values($1,$2,$3,'OWNER')",
          [randomUUID(), id, user.id],
        );
        const sid = await save(db, "services", id, {
          name: input.service,
          price: input.price,
          duration: input.duration,
          active: true,
        });
        const pid = await save(db, "professionals", id, {
          name: input.professional,
          specialty: "Barbeiro",
          active: true,
          serviceIds: [sid],
          commission: 0,
          userId: user.id,
        });
        await db.query("insert into professional_services values($1,$2,$3)", [
          id,
          pid,
          sid,
        ]);
        for (let weekday = 0; weekday < 7; weekday++)
          await save(db, "business_hours", id, {
            weekday,
            start: input.start,
            end: input.end,
            closed: weekday === 0,
            breaks: [],
          });
        await writeSubscription(db,id,defaultSubscription());
        await notify(
          db,
          id,
          "Bem-vindo ao HAIRCUT. Sua barbearia está pronta.",
        );
      });
      return NextResponse.json({ redirect: "/app" });
    }
    const c = await context();
    if (b.action === "book") {
      admin(c.role);
      const result = await tenantTx(c.shop.id, (db) =>
        book(db, c.shop, b, "interno", c.user.id),
      );
      return NextResponse.json(result);
    }
    if (b.action === "appointment") {
      if (c.role === "CLIENT") throw new AppError("Acesso negado.", 403);
      await tenantTx(c.shop.id, async (db) => {
        const a = await appointment(db, c.shop.id, z.uuid().parse(b.id));
        const pros = await records(db, "professionals", c.shop.id);
        checkProfessional(
          c.role,
          pros.find((x) => x.id === a.professional_id),
          c.user.id,
        );
        if (b.operation === "reschedule") {
          await reschedule(
            db,
            c.shop,
            a,
            z
              .string()
              .regex(/^\d{4}-\d{2}-\d{2}$/)
              .parse(b.date),
            z.number().int().parse(b.time),
            c.user.id,
          );
          return;
        }
        if (b.operation === "notes") {
          await db.query(
            "update appointments set data=data||$1::jsonb,updated_at=now() where id=$2 and barbershop_id=$3",
            [
              JSON.stringify({ notes: z.string().max(4000).parse(b.notes) }),
              a.id,
              c.shop.id,
            ],
          );
          return;
        }
        const status = z
          .enum([
            "confirmado",
            "aguardando",
            "em atendimento",
            "concluído",
            "cancelado",
            "não compareceu",
          ])
          .parse(b.status);
        const next: Record<string, string[]> = {
          pendente: ["confirmado", "cancelado", "não compareceu"],
          confirmado: [
            "aguardando",
            "em atendimento",
            "cancelado",
            "não compareceu",
          ],
          aguardando: ["em atendimento", "cancelado", "não compareceu"],
          "em atendimento": ["concluído", "cancelado"],
        };
        if (!next[a.status]?.includes(status))
          throw new AppError("Esta mudança de status não é permitida.", 409);
        const data = { ...a.data };
        if (status === "concluído") {
          const discount = z
              .number()
              .int()
              .min(0)
              .max(a.data.price)
              .parse(b.discount || 0),
            extra = z
              .number()
              .int()
              .min(0)
              .max(10000000)
              .parse(b.extra || 0);
          const paymentMethod = z
            .enum(["dinheiro", "Pix", "débito", "crédito", "outro"])
            .parse(b.paymentMethod);
          const total = a.data.price - discount + extra;
          Object.assign(data, { discount, extra, total, paymentMethod });
          await save(db, "payments", c.shop.id, {
            appointmentId: a.id,
            clientId: a.client_id,
            professionalId: a.professional_id,
            date: a.date,
            amount: total,
            method: paymentMethod,
            status: "pago",
          });
          const rate = Number(
            pros.find((x) => x.id === a.professional_id)?.commission || 0,
          );
          await save(db, "commissions", c.shop.id, {
            appointmentId: a.id,
            professionalId: a.professional_id,
            date: a.date,
            revenue: total,
            rate,
            amount: Math.round((total * rate) / 100),
            paid: false,
          });
        }
        if (status === "cancelado")
          data.cancelReason = String(b.reason || "").slice(0, 1000);
        await db.query(
          "update appointments set status=$1,data=$2,updated_at=now() where id=$3 and barbershop_id=$4",
          [status, JSON.stringify(data), a.id, c.shop.id],
        );
        await notify(db, c.shop.id, `Atendimento ${status}`, a.id);
        await audit(db, c.shop.id, c.user.id, "agendamento." + status, a.id);
      });
      return NextResponse.json({ message: "Agendamento atualizado." });
    }
    admin(c.role);
    if (b.action === "subscription") {
      const operation = z.enum(["select", "cancel", "resume"]).parse(b.operation);
      await tenantTx(c.shop.id, async db => {
        if(operation === "select") await requestPlan(db,c.shop.id,z.enum(["basico","pro"]).parse(b.planId));
        else {
          const sub=await subscriptionFor(db,c.shop.id);
          sub.cancelAtPeriodEnd=operation === "cancel";
          if(operation === "cancel") {
            delete sub.requestedPlan;
            if(sub.status !== "active") sub.status="canceled";
          }
          await writeSubscription(db,c.shop.id,sub);
        }
        await audit(db,c.shop.id,c.user.id,"assinatura."+operation,c.shop.id);
      });
      return NextResponse.json({message: operation === "select" ? "Plano solicitado. A administração poderá liberar o acesso; nenhuma cobrança foi realizada." : operation === "cancel" ? "Renovação cancelada. O acesso ativo continua até o final do período." : "Solicitação de cancelamento removida."});
    }
    if (b.action === "shop") {
      const name = z.string().trim().min(2).max(100).parse(b.name);
      const d = z
        .object({
          phone: z.string().max(20),
          whatsapp: z.string().max(20),
          address: z.string().max(500),
          description: z.string().max(2000),
          instagram: z.string().max(100),
          logo: z.string().max(2_500_000).refine(v => !v || v.startsWith("data:image/"), "Envie o logo pelo campo de upload."),
          banner: z.string().max(2_500_000).refine(v => !v || v.startsWith("data:image/"), "Envie a capa pelo campo de upload."),
          color: z.string().regex(/^#[0-9a-fA-F]{6}$/),
          notice: z.number().int().min(0).max(10080),
          buffer: z.number().int().min(0).max(120),
          goal: z.number().int().min(0).optional(),
        })
        .parse(b.data);
      await tenantTx(c.shop.id, async db => {
        const current=(await db.query<{slug:string;name:string;data:Record<string,unknown>}>("select name,slug,data from barbershops where id=$1",[c.shop.id])).rows[0];
        const slug = current.name === name ? current.slug : await availableShopSlug(db,name,c.shop.id);
        const aliases=[...new Set([...(current.data.slugAliases as string[] || []), ...(slug!==current.slug ? [current.slug] : [])])].filter(value=>value!==slug);
        await db.query("update barbershops set name=$1,slug=$2,data=data||$3::jsonb,updated_at=now() where id=$4",[name,slug,JSON.stringify({...d,slugAliases:aliases}),c.shop.id]);
      });
      return NextResponse.json({ message: "Barbearia atualizada." });
    }
    if (b.action === "save") {
      const table = z.enum(entities).parse(b.table);
      if (
        ["reviews", "payments", "commissions", "subscriptions"].includes(table)
      )
        throw new AppError(
          "Este registro é gerado pela operação correspondente.",
          403,
        );
      const id = b.id ? z.uuid().parse(b.id) : undefined;
      let data: Record<string, unknown>;
      if (table === "clients") data = clientSchema.parse(b.data);
      else if (table === "services") data = serviceSchema.parse(b.data);
      else if (table === "professionals")
        data = professionalSchema.parse(b.data);
      else if (table === "business_hours" || table === "professional_hours") {
        data = z
          .object({
            weekday: z.number().int().min(0).max(6),
            start: z.number().int().min(0).max(1439),
            end: z.number().int().min(1).max(1440),
            closed: z.boolean(),
            professionalId: z.uuid().optional(),
            breaks: z
              .array(
                z.object({
                  start: z.number().min(0).max(1439),
                  end: z.number().min(1).max(1440),
                }),
              )
              .max(6),
          })
          .parse(b.data);
        if (
          Number(data.end) <= Number(data.start) ||
          (data.breaks as { start: number; end: number }[]).some(
            (x) => x.end <= x.start,
          )
        )
          throw new AppError("Intervalo de horário inválido.");
        if (table === "professional_hours" && !data.professionalId)
          throw new AppError("Selecione o profissional.");
      } else if (table === "schedule_blocks") {
        data = z
          .object({
            name: z.string().max(200),
            date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
            professionalId: z.string(),
            start: z.number().int().min(0),
            end: z.number().int().max(1440),
          })
          .parse(b.data);
        if (Number(data.end) <= Number(data.start))
          throw new AppError("Intervalo inválido.");
      } else if (table === "closed_dates")
        data = z
          .object({
            name: z.string().min(1).max(100),
            date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
          })
          .parse(b.data);
      else if (table === "notifications")
        data = z
          .object({
            name: z.string().max(500),
            read: z.boolean(),
            appointmentId: z.string().optional(),
          })
          .parse(b.data);
      else if (table === "public_page_settings")
        data = z
          .object({
            name: z.string().max(100).default("Preferências"),
            events: z.array(z.string().max(30)).max(10),
            reminders: z.array(z.number()).max(4),
          })
          .parse(b.data);
      else if (table === "support_tickets")
        data = z
          .object({
            name: z.string().min(3).max(200),
            message: z.string().min(5).max(5000),
            status: z.literal("aberto").default("aberto"),
          })
          .parse(b.data);
      else throw new AppError("Operação indisponível para este cadastro.");
      const key = await tenantTx(c.shop.id, async (db) => {
        if(table === "professionals" && data.active !== false) await assertProfessionalLimit(db,c.shop.id,id);
        if(table === "business_hours" || table === "professional_hours") {
          const duplicate=(await db.query<{id:string}>(`select id from ${table} where barbershop_id=$1 and data->>'weekday'=$2 and coalesce(data->>'professionalId','')=$3 and ($4::uuid is null or id<>$4)`,[c.shop.id,String(data.weekday),String(data.professionalId || ""),id || null])).rows[0];
          if(duplicate) throw new AppError("Já existe um horário para este dia. Edite o horário cadastrado.",409);
        }
        if (data.professionalId) {
          if (
            !(await records(db, "professionals", c.shop.id)).some(
              (x) => x.id === data.professionalId,
            )
          )
            throw new AppError("Profissional inválido.");
        }
        if (table === "professionals") {
          const serviceIds = data.serviceIds as string[];
          const services = await records(db, "services", c.shop.id);
          if (!serviceIds.every((s) => services.some((x) => x.id === s)))
            throw new AppError("Serviço inválido.");
          if (data.userId) {
            const member = (
              await db.query(
                "select id from barbershop_members where barbershop_id=$1 and user_id=$2",
                [c.shop.id, data.userId],
              )
            ).rows[0];
            if (!member)
              throw new AppError(
                "O usuário precisa ser membro desta barbearia.",
              );
          }
        }
        const key = await save(db, table, c.shop.id, data, id);
        if (table === "services" && data.professionalIds) {
          const selected = data.professionalIds as string[];
          const professionals = await records(db,"professionals",c.shop.id);
          if (!selected.every(pid=>professionals.some(p=>p.id===pid))) throw new AppError("Profissional inválido.");
          await db.query("delete from professional_services where barbershop_id=$1 and service_id=$2",[c.shop.id,key]);
          for (const professional of professionals) {
            const serviceIds=((professional.serviceIds||[]) as string[]).filter(sid=>sid!==key);
            if(selected.includes(professional.id)) {
              serviceIds.push(key);
              await db.query("insert into professional_services values($1,$2,$3)",[c.shop.id,professional.id,key]);
            }
            const {id:pid,created_at:created,updated_at:updated,...fields}=professional;
            void created; void updated;
            await save(db,"professionals",c.shop.id,{...fields,serviceIds},pid);
          }
        }
        if (table === "professionals") {
          await db.query(
            "delete from professional_services where barbershop_id=$1 and professional_id=$2",
            [c.shop.id, key],
          );
          for (const s of data.serviceIds as string[])
            await db.query(
              "insert into professional_services values($1,$2,$3)",
              [c.shop.id, key, s],
            );
        }
        await audit(db, c.shop.id, c.user.id, table + ".salvo", key);
        return key;
      });
      return NextResponse.json({ id: key, message: "Salvo com sucesso." });
    }
    if (b.action === "delete") {
      const table = z
          .enum([
            "clients",
            "services",
            "professionals",
            "schedule_blocks",
            "closed_dates",
            "professional_hours",
          ])
          .parse(b.table),
        id = z.uuid().parse(b.id);
      await tenantTx(c.shop.id, async (db) => {
        if (["clients", "services", "professionals"].includes(table)) {
          const all = (
            await db.query<Appointment>(
              "select * from appointments where barbershop_id=$1",
              [c.shop.id],
            )
          ).rows;
          if (
            all.some(
              (a) =>
                a.client_id === id ||
                a.professional_id === id ||
                a.data.serviceIds.includes(id),
            )
          )
            throw new AppError(
              "Este cadastro possui histórico. Inative-o para preservar os atendimentos.",
              409,
            );
          if (table === "services")
            await db.query(
              "delete from professional_services where barbershop_id=$1 and service_id=$2",
              [c.shop.id, id],
            );
          if(table === "services") await db.query("update professionals set data=jsonb_set(data,'{serviceIds}',coalesce((select jsonb_agg(value) from jsonb_array_elements(coalesce(data->'serviceIds','[]'::jsonb)) where value<>to_jsonb($2::text)),'[]'::jsonb)),updated_at=now() where barbershop_id=$1",[c.shop.id,id]);
          if (table === "professionals")
            await db.query(
              "delete from professional_services where barbershop_id=$1 and professional_id=$2",
              [c.shop.id, id],
            );
        }
        const result = await db.query(
          `delete from ${table} where id=$1 and barbershop_id=$2 returning id`,
          [id, c.shop.id],
        );
        if (!result.rows.length)
          throw new AppError("Registro não encontrado.", 404);
        await audit(db, c.shop.id, c.user.id, table + ".excluido", id);
      });
      return NextResponse.json({ message: "Registro excluído." });
    }
    if (b.action === "member") {
      await requirePro((await engine()).db,c.shop.id);
      const email = z.email().parse(b.email),
        role = z.enum(["ADMIN", "PROFESSIONAL"]).parse(b.role);
      const u = (
        await query<{ id: string }>(
          "select id from users where lower(email)=$1",
          [email.toLowerCase()],
        )
      ).rows[0];
      if (!u)
        throw new AppError(
          "Peça ao profissional para criar uma conta antes de vinculá-la.",
        );
      if (
        (
          await query("select id from barbershop_members where user_id=$1", [
            u.id,
          ])
        ).rows.length
      )
        throw new AppError("Este usuário já está associado a uma barbearia.");
      await query(
        "insert into barbershop_members(id,barbershop_id,user_id,role) values($1,$2,$3,$4)",
        [randomUUID(), c.shop.id, u.id, role],
      );
      return NextResponse.json({ message: "Membro adicionado.", userId: u.id });
    }
    throw new AppError("Ação inválida.");
  } catch (e) {
    return fail(e);
  }
}
