import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { randomUUID } from "node:crypto";
import { query, remote } from "@/lib/db";
import {
  AppError,
  checkOrigin,
  createSession,
  hash,
  passwordHash,
  passwordMatches,
  rateLimit,
  sessionUser,
  supabase,
  siteOrigin,
} from "@/lib/auth";
import { signupSchema } from "@/lib/validation";
import { ZodError } from "zod";
export const runtime = "nodejs";
async function providerEnabled(provider: string) {
  const result = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_URL}/auth/v1/settings`, {
    headers: { apikey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY! },
    next: { revalidate: 60 },
  });
  if (!result.ok) throw new AppError("Não foi possível consultar a autenticação.", 503);
  const settings = await result.json();
  return Boolean(settings.external?.[provider]);
}
export async function POST(req: Request) {
  try {
    checkOrigin(req);
    const b = await req.json();
    const action = String(b.action || "");
    const sessionKey=(await cookies()).getAll().filter(c=>c.name==='haircut_session'||c.name.startsWith('sb-')).map(c=>c.value).join('');
    await rateLimit(
      "auth:" + String(b.email || b.identifier || hash(sessionKey||'anonymous')).toLowerCase(),
      30,
    );
    if (action === "signup") {
      const v = signupSchema.parse(b);
      if (remote()) {
        const s = await supabase();
        const { data, error } = await s.auth.signUp({
          email: v.email,
          password: v.password,
          options: {
            data: { name: v.name, phone: v.phone },
            emailRedirectTo: `${siteOrigin(req)}/auth/callback`,
          },
        });
        if (error) throw new AppError(error.message);
        return NextResponse.json({
          redirect: data.session ? "/primeiro-acesso" : "/verificar",
          message: "Confira seu e-mail para verificar a conta.",
        });
      }
      const id = randomUUID();
      await query(
        "insert into users(id,name,email,phone,password_hash) values($1,$2,$3,$4,$5)",
        [id, v.name, v.email.toLowerCase(), v.phone, passwordHash(v.password)],
      );
      await createSession(id);
      return NextResponse.json({ redirect: "/primeiro-acesso" });
    }
    if (action === "login") {
      const identifier = String(b.identifier || "").trim();
      const password = String(b.password || "");
      if (password.length > 128)
        throw new AppError("Credenciais inválidas.", 401);
      if (remote()) {
        if (!identifier.includes("@") && !(await providerEnabled("phone")))
          throw new AppError("Login por telefone ainda não está habilitado. Use seu e-mail.", 503);
        const s = await supabase();
        const credentials = identifier.includes("@")
          ? { email: identifier, password }
          : { phone: identifier.replace(/[^\d+]/g, ""), password };
        const { error } = await s.auth.signInWithPassword(credentials);
        if (error)
          throw new AppError("E-mail/telefone ou senha inválidos.", 401);
      } else {
        const u = (
          await query<{ id: string; password_hash: string }>(
            "select id,password_hash from users where lower(email)=$1 or phone=$2",
            [identifier.toLowerCase(), identifier.replace(/\D/g, "")],
          )
        ).rows[0];
        if (!u?.password_hash || !passwordMatches(password, u.password_hash))
          throw new AppError("E-mail/telefone ou senha inválidos.", 401);
        await createSession(u.id);
      }
      if (remote()) {
        const { data: assurance } = await (
          await supabase()
        ).auth.mfa.getAuthenticatorAssuranceLevel();
        if (
          assurance?.nextLevel === "aal2" &&
          assurance.currentLevel !== "aal2"
        )
          return NextResponse.json({ redirect: "/verificar-mfa" });
      }
      const u = await sessionUser();
      if (!u) throw new AppError("Não foi possível validar a sessão.", 401);
      const m = (
        await query("select id from barbershop_members where user_id=$1", [
          u.id,
        ])
      ).rows;
      return NextResponse.json({
        redirect: u.master ? "/master" : m.length ? "/app" : "/primeiro-acesso",
      });
    }
    if (action === "google") {
      if (!remote())
        throw new AppError(
          "Google requer um projeto Supabase com OAuth configurado.",
          503,
        );
      if (!(await providerEnabled("google")))
        throw new AppError("O login com Google ainda não foi habilitado pela administração. Entre com e-mail e senha.", 503);
      const s = await supabase();
      const { data, error } = await s.auth.signInWithOAuth({
        provider: "google",
        options: { redirectTo: `${siteOrigin(req)}/auth/callback`, scopes: "openid email profile", queryParams: { prompt: "select_account" } },
      });
      if (error) throw new AppError(error.message);
      return NextResponse.json({ redirect: data.url });
    }
    if (action === "recover") {
      if (!remote())
        throw new AppError(
          "Envio de e-mail/SMS não configurado no modo local. Configure Supabase Auth para recuperar por código.",
          503,
        );
      const s = await supabase();
      const identifier = String(b.identifier || "");
      if (!identifier.includes("@"))
        throw new AppError(
          "Recuperação por SMS exige configuração do provedor. Use o e-mail da conta.",
          503,
        );
      const {error} = await s.auth.resetPasswordForEmail(identifier, {
        redirectTo: `${siteOrigin(req)}/auth/callback?next=/nova-senha`,
      });
      if (error) throw new AppError("O provedor não conseguiu enviar a recuperação. Verifique o serviço de e-mail ou tente novamente mais tarde.", 503);
      return NextResponse.json({
        message: "Se a conta existir, você receberá as instruções por e-mail.",
        redirect: "/verificar?recovery=1",
      });
    }
    if (action === "verify") {
      if (!remote())
        throw new AppError("Verificação remota não configurada.", 503);
      const s = await supabase();
      const { error } = await s.auth.verifyOtp({
        email: String(b.email),
        token: String(b.code),
        type: b.recovery ? "recovery" : "signup",
      });
      if (error) throw new AppError("Código inválido ou expirado.");
      return NextResponse.json({
        redirect: b.recovery ? "/nova-senha" : "/primeiro-acesso",
      });
    }
    if (action === "mfa-login") {
      if (!remote()) throw new AppError("Supabase não configurado.", 503);
      const s = await supabase();
      const {
        data: { user },
      } = await s.auth.getUser();
      if (!user) throw new AppError("Faça login novamente.", 401);
      const { data: factors } = await s.auth.mfa.listFactors();
      const factor = factors?.totp.find((f) => f.status === "verified");
      if (!factor) throw new AppError("Autenticador não encontrado.");
      const { error } = await s.auth.mfa.challengeAndVerify({
        factorId: factor.id,
        code: String(b.code),
      });
      if (error) throw new AppError("Código inválido.");
      const signedIn=await sessionUser();
      return NextResponse.json({ redirect: signedIn?.master ? "/master" : "/app" });
    }
    const user = await sessionUser();
    if (!user) throw new AppError("Sessão encerrada.", 401);
    if (action === "logout") {
      if (remote())
        await (
          await supabase()
        ).auth.signOut({ scope: b.all ? "global" : "local" });
      else {
        const token = (await cookies()).get("haircut_session")?.value;
        await query(
          b.all
            ? "delete from sessions where user_id=$1"
            : "delete from sessions where id=$1",
          [b.all ? user.id : hash(token || "")],
        );
        (await cookies()).delete("haircut_session");
      }
      return NextResponse.json({ redirect: "/login" });
    }
    if (action === "password") {
      const p = String(b.password || "");
      if (p.length < 10 || p.length > 128)
        throw new AppError("Use de 10 a 128 caracteres.");
      if (remote()) {
        const { error } = await (
          await supabase()
        ).auth.updateUser({ password: p });
        if (error) throw new AppError(error.message);
      } else {
        const row = (
          await query<{ password_hash: string }>(
            "select password_hash from users where id=$1",
            [user.id],
          )
        ).rows[0];
        if (!passwordMatches(String(b.current || ""), row.password_hash))
          throw new AppError("Senha atual incorreta.");
        await query("update users set password_hash=$1 where id=$2", [
          passwordHash(p),
          user.id,
        ]);
        await query("delete from sessions where user_id=$1", [user.id]);
        await createSession(user.id);
      }
      return NextResponse.json({ message: "Senha alterada." });
    }
    if (action === "profile") {
      const name = String(b.name || "").trim();
      if (!name || name.length > 200) throw new AppError("Nome inválido.");
      await query("update users set name=$1,phone=$2 where id=$3", [
        name,
        String(b.phone || "")
          .replace(/\D/g, "")
          .slice(0, 15),
        user.id,
      ]);
      return NextResponse.json({ message: "Perfil atualizado." });
    }
    if (action === "mfa-enroll") {
      if (!remote())
        throw new AppError(
          "Duas etapas requer Supabase Auth configurado.",
          503,
        );
      const { data, error } = await (
        await supabase()
      ).auth.mfa.enroll({ factorType: "totp", friendlyName: "HAIRCUT" });
      if (error) throw new AppError(error.message);
      return NextResponse.json(data);
    }
    if (action === "mfa-verify") {
      const s = await supabase();
      const { error } = await s.auth.mfa.challengeAndVerify({
        factorId: String(b.factorId),
        code: String(b.code),
      });
      if (error) throw new AppError("Código inválido.");
      return NextResponse.json({ message: "Verificação concluída." });
    }
    throw new AppError("Ação inválida.");
  } catch (e) {
    const message =
      e instanceof ZodError
        ? e.issues[0].message
        : e instanceof Error
          ? e.message
          : "Não foi possível concluir.";
    return NextResponse.json(
      {
        error: message.includes("duplicate key")
          ? "E-mail já cadastrado."
          : message,
      },
      { status: e instanceof AppError ? e.status : 400 },
    );
  }
}
