import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "HAIRCUT — Sistema de agendamento",
  description: "Gestão da barbearia, agenda e agendamento online.",
  robots: { index: false, follow: false },
};
export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
