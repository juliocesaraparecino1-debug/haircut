import Link from "next/link";
export default function NotFound() {
  return (
    <main className="loading">
      <h1>Página não encontrada</h1>
      <Link className="primary" href="/app">
        Voltar ao início
      </Link>
    </main>
  );
}
