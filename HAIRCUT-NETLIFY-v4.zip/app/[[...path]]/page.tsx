import { redirect, notFound } from "next/navigation";
import { sessionUser } from "@/lib/auth";
import { AuthScreen, Onboarding } from "@/components/auth-screen";
import { PublicBooking, PublicAppointment } from "@/components/public";
import { Master } from "@/components/master";
import { MFAScreen } from "@/components/mfa-screen";
export const dynamic = "force-dynamic";
export default async function Page({
  params,
}: {
  params: Promise<{ path?: string[] }>;
}) {
  const { path = [] } = await params;
  const [root, sub] = path;
  if (!root) redirect("/login");
  if (root === "verificar-mfa") return <MFAScreen />;
  if (
    [
      "login",
      "cadastro",
      "recuperar-senha",
      "verificar",
      "nova-senha",
    ].includes(root)
  )
    return <AuthScreen screen={root} />;
  if (root === "agendar" && sub) return <PublicBooking slug={sub} />;
  if (root === "a" && sub) return <PublicAppointment token={sub} />;
  const user = await sessionUser();
  if (!user) redirect("/login");
  if (root === "primeiro-acesso") return <Onboarding />;
  if (root === "master") {
    if (!user.master) redirect("/app");
    return <Master section={sub || "inicio"} />;
  }
  notFound();
}
