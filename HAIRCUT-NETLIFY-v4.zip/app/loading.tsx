export default function Loading() {
  return (
    <main className="loading">
      <div
        className="logo"
        role="img"
        aria-label="HAIRCUT — Sistema de agendamento"
      />
      <div className="skeleton" />
      <div className="skeleton" />
      <p>Carregando sua barbearia…</p>
    </main>
  );
}
