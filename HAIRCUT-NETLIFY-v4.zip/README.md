# HAIRCUT

Sistema de agendamento para barbearias. A aplicação está conectada ao Supabase e executa em modo de produção, sem compilar telas durante o uso.

No computador: [abrir HAIRCUT](http://127.0.0.1:3000/login). No celular conectado à mesma rede: [abrir HAIRCUT pelo Wi-Fi](http://192.168.3.96:3000/login). O computador deve permanecer ligado e o servidor em execução. Esse endereço é da rede local; não funciona pelo 4G/5G ou por outra rede. Se o IP do computador mudar, atualize o endereço e `HAIRCUT_ALLOWED_ORIGINS` em `.env.local`.

## Acesso

- Conta da barbearia: veja `ACESSO-DO-SISTEMA.txt`.
- Administração da plataforma: veja `ACESSO-MASTER.txt`.

Esses arquivos contêm senhas e ficam fora do controle de versão. A conta da barbearia não administra a plataforma; a conta master é separada. Os dados de demonstração foram removidos. Configure os dados reais da barbearia, profissionais, serviços e horários antes de receber reservas. Guarde as credenciais em local privado e associe a conta a um e-mail sob seu controle antes do uso comercial.

## Executar

Requer Node.js compatível com Next.js 16. Na pasta deste projeto:

```sh
npm install
npm run build
npm start
```

O arquivo `.env.local` já contém a conexão privada com o Supabase deste ambiente. Não o compartilhe nem o publique. `.env.example` descreve as variáveis para outra instalação. A conexão PostgreSQL do servidor usa TLS com verificação do certificado; as credenciais de banco não são enviadas ao navegador.

Para usar apenas o banco local persistente, configure `HAIRCUT_MODE=local` e `HAIRCUT_DATA_DIR=.data/postgres` em `.env.local`, sem as credenciais remotas. Esse modo serve para desenvolvimento e testes; a instalação atual está no modo Supabase.

## O que está funcionando

Cadastro e entrada por e-mail, autenticação Supabase, criação de barbearia, profissionais, serviços, clientes, agenda com bloqueio de conflitos, reserva pública sem cadastro, remarcação/cancelamento por link, registro de atendimento, pagamentos e comissões, relatórios, configurações, planos e painel master. Os dados são persistidos no Supabase; há políticas RLS por barbearia e validação adicional no servidor.

O banco está limpo de clientes, agendamentos, profissionais, serviços, horários, pagamentos, comissões, avaliações e notificações de teste. Foram mantidos os acessos e o vínculo da conta com “Minha barbearia”. A migração inicial está em `supabase/migrations/001_haircut.sql`; a complementar está em `supabase/migrations/002_backend_access.sql`. Elas já foram aplicadas. Não execute `db:migrate` contra esse banco com o usuário `haircut_server`: ele possui acesso de dados, sem privilégios de alteração de estrutura.

A navegação do painel mantém a interface e seus dados em memória enquanto a sessão está aberta; a API continua validando a autenticação e as permissões em cada requisição. Há atualização periódica e após gravações. As transições de tela e os botões respeitam a preferência de movimento reduzido. A logo transparente está em `public/haircut-logo.png`; veja `docs/logo.md` para sua origem.

O login Google está habilitado no Supabase e foi validado até a tela de primeiro acesso com a conta do proprietário em 03/10/2026. A credencial secreta está no provedor Supabase, sem inclusão no código. O aplicativo Google permanece em modo de testes; a conta do proprietário está cadastrada para teste. A publicação pública está pendente dos endereços de site, privacidade e termos. A autenticação por telefone/SMS não está habilitada. Recuperação por e-mail depende do envio de e-mails do projeto. Mensagens automáticas de WhatsApp e cobrança online dependem de provedores externos; a aplicação registra preferências, agendamentos e pagamentos, mas não envia mensagens nem processa cobranças por conta própria. O aplicativo está executando localmente; ainda não há uma URL pública de produção.

## Planos mensais e link da barbearia

Básico: R$ 59,90/mês, até 3 profissionais ativos, clientes e agendamentos ilimitados, agenda, serviços, histórico, resumo diário, link com o nome da barbearia e QR Code. Pro: R$ 89,90/mês, profissionais ilimitados, relatórios e CSV, comissões, lista de espera, acesso da equipe e identificação de clientes sem retorno para contato manual por WhatsApp.

A seleção de plano registra uma solicitação. Até integrar o gateway, o master libera manualmente um mês; essa liberação não registra pagamento recebido. Cancelamento impede a intenção de renovação e preserva o período já liberado. Não há cobrança automática. As regras de preço, limite e acesso Pro são verificadas no servidor.

O endereço segue `/agendar/nome-da-barbearia`, resolve nomes repetidos com um sufixo e preserva links anteriores quando a barbearia muda de nome. `HAIRCUT_PUBLIC_URL` define a base do endereço compartilhado; atualmente é o IP da rede local. Ao publicar, substitua pela URL HTTPS real e atualize os retornos de autenticação no Supabase.

## Verificação

```sh
npm run lint
npm run typecheck
npm test
npm run build
```

O teste `scripts/remote-http-smoke.mjs` foi executado contra o Supabase real e cobre entrada, leitura e gravação persistentes, reserva pública, conflito, remarcação, atendimento, pagamento, comissão, avaliação, cancelamento, proteção master e RLS anônimo. Ele cria dados de teste e não deve ser repetido sem limpar ou alterar os identificadores usados no teste.
